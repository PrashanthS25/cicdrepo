
export const inputBigData =[ 

    {   
        "totalAmount":103.08590572086537,
        "tokenList":
        [
            {
                "coinName": "Ether",
                "coinAddress": "Ethereum",
                "coinSymbol": "ETH",
                "coinDecimal": 18,
                "coinPrice": 1222.19,
                "coinQuantity": 0.07731675650956295,
                "coinValue": 94.49576663842274,
                "coinPerc": 91.66700915864979
            },
            {
                "coinName": "Chain Link",
                "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                "coinSymbol": "LINK",
                "coinQuantity": "0.754390953116979898",
                "coinDecimal": 18,
                "coinPrice": 6.21712,
                "coinValue": 4.690139082442639,
                "coinPerc": 4.549738443529356
            },
            {
                "coinName": "DAI",
                "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                "coinSymbol": "DAI",
                "coinQuantity": "3.900000000000001195",
                "coinDecimal": 18,
                "coinPrice": 1,
                "coinValue": 3.9000000000000012,
                "coinPerc": 3.7832523978208705
            },
            {
                "coinId": 10,
                "coinName": "Wrapped Bitcoin",
                "coinAddress": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
                "coinSymbol": "WBTC",
                "coinDecimalPlaces": 8,
                "coinPrice": 16740.5,
                "coinLogoUrl": "sevenbits.in",
                "coinABI": {
                    "function1": "defination",
                    "function2": "defination2"
                },
                "coinChainID": "1",
                "coinType": "ERC20",
                "coinStatus": true,
                "coinCMC_Id": 3717,
                "total_supply": 236372,
                "max_supply": null,
                "volume_24h": 141245000,
                "volume_change_24h": 8.9142,
                "volume_7d": 786829000,
                "volume_30d": 3944200000,
                "fully_diluted_market_cap": 3960860000,
                "percent_change_1h": 0.0984974,
                "percent_change_24h": 1.84594,
                "percent_change_7d": -3.79933,
                "percent_change_30d": -12.7242,
                "percent_change_60d": -10.7878,
                "percent_change_90d": -21.1269,
                "market_cap_dominance": 0.4727,
                "market_cap": 3960860000,
                "createdBy": "ashish@sevenbits.in",
                "modifiedBy": "ashish@sevenbits.in",
                "createdAt": "2022-11-15T06:25:31.000Z",
                "updatedAt": "2022-11-18T13:38:18.000Z",
                "coinQuantity": 0,
                "coinPerc": 5,
                "coinValue": 5,
                "isNewlyAdded": true
            },
            {
                "coinId": 18,
                "coinName": "Compound Ether",
                "coinAddress": "0x4ddc2d193948926d02f9b1fe9e1daa0718270ed5",
                "coinSymbol": "cETH",
                "coinDecimalPlaces": 8,
                "coinPrice": 24.3445,
                "coinLogoUrl": "sevenbits.in",
                "coinABI": {
                    "function1": "defination",
                    "function2": "defination2"
                },
                "coinChainID": "1",
                "coinType": "ERC20",
                "coinStatus": true,
                "coinCMC_Id": 5636,
                "total_supply": 0,
                "max_supply": null,
                "volume_24h": 0,
                "volume_change_24h": 0,
                "volume_7d": 0,
                "volume_30d": 0,
                "fully_diluted_market_cap": 0,
                "percent_change_1h": -0.487344,
                "percent_change_24h": 7.00398,
                "percent_change_7d": 9.68295,
                "percent_change_30d": 28.529,
                "percent_change_60d": 23.2289,
                "percent_change_90d": 80.4289,
                "market_cap_dominance": 0,
                "market_cap": 0,
                "createdBy": "ashish@sevenbits.in",
                "modifiedBy": "krunal@sevenbits.in",
                "createdAt": "2022-11-15T06:27:58.000Z",
                "updatedAt": "2022-11-18T13:38:19.000Z",
                "coinQuantity": 0,
                "coinPerc": 5,
                "coinValue": 5,
                "isNewlyAdded": true
            }
        ],
        "tempTokenList":
        [
    
            {
                "coinAddress": "Ethereum",
                "coinValue": 89.34147135237947,
                "coinPerc": 86.66700915864979,
                "exactCoinPerc": 91.66700915864979
            },
            {
                "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                "coinValue": 1.5975619108166783,
                "coinPerc": 1.549738443529356,
                "exactCoinPerc": 4.549738443529356
            },
            {
                "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                "coinValue": 1.8382818855826937,
                "coinPerc": 1.7832523978208705,
                "exactCoinPerc": 3.7832523978208705
            },
            {
                "coinAddress": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
                "coinValue": 5,
                "coinPerc": 5,
                "exactCoinPerc": 5
            },
            {
                "coinAddress": "0x4ddc2d193948926d02f9b1fe9e1daa0718270ed5",
                "coinValue": 5,
                "coinPerc": 5,
                "exactCoinPerc": 5
            }
        ]
    },
    {
        "totalAmount":102.6062575067239,
        "tokenList":
        [
            {
                "coinName": "Ether",
                "coinAddress": "Ethereum",
                "coinSymbol": "ETH",
                "coinDecimal": 18,
                "coinPrice": 1217.23,
                "coinQuantity": 0.0772834161481733,
                "coinValue": 94.07169263804099,
                "coinPerc": 91.63258736135654
            },
            {
                "coinName": "Chain Link",
                "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                "coinSymbol": "LINK",
                "coinQuantity": "0.754390953116979898",
                "coinDecimal": 18,
                "coinPrice": 6.21712,
                "coinValue": 4.690139082442639,
                "coinPerc": 4.568532436877257
            },
            {
                "coinName": "DAI",
                "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                "coinSymbol": "DAI",
                "coinQuantity": "3.900000000000001195",
                "coinDecimal": 18,
                "coinPrice": 1,
                "coinValue": 3.9000000000000012,
                "coinPerc": 3.7988802017662158
            },
            {
                "coinId": 10,
                "coinName": "Wrapped Bitcoin",
                "coinAddress": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
                "coinSymbol": "WBTC",
                "coinDecimalPlaces": 8,
                "coinPrice": 16681.2,
                "coinLogoUrl": "sevenbits.in",
                "coinABI": {
                    "function1": "defination",
                    "function2": "defination2"
                },
                "coinChainID": "1",
                "coinType": "ERC20",
                "coinStatus": true,
                "coinCMC_Id": 3717,
                "total_supply": 236372,
                "max_supply": null,
                "volume_24h": 136340000,
                "volume_change_24h": 3.6614,
                "volume_7d": 1031470000,
                "volume_30d": 2597950000,
                "fully_diluted_market_cap": 3954770000,
                "percent_change_1h": -0.0710385,
                "percent_change_24h": 1.78207,
                "percent_change_7d": -2.38629,
                "percent_change_30d": -12.5869,
                "percent_change_60d": -12.0975,
                "percent_change_90d": -21.4867,
                "market_cap_dominance": 0.4727,
                "market_cap": 3954770000,
                "createdBy": "ashish@sevenbits.in",
                "modifiedBy": "ashish@sevenbits.in",
                "createdAt": "2022-11-15T06:25:31.000Z",
                "updatedAt": "2022-11-18T14:06:00.000Z",
                "coinQuantity": 0,
                "coinPerc": 100,
                "coinValue": 102,
                "isNewlyAdded": true
            }
        ],
        "tempTokenList":
        [
            {
                "coinAddress": "Ethereum",
                "coinValue": 0,
                "coinPerc": 0,
                "exactCoinPerc": 91.63258736135654
            },
            {
                "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                "coinValue": 0,
                "coinPerc": 0,
                "exactCoinPerc": 4.568532436877257
            },
            {
                "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                "coinValue": 0,
                "coinPerc": 0,
                "exactCoinPerc": 3.7988802017662158
            },
            {
                "coinAddress": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
                "coinValue": 102,
                "coinPerc": 100,
                "exactCoinPerc": 100
            }
        ]
    },
    {
    "totalAmount":102.6062575067239,
    "tokenList":
    [
        {
            "coinName": "Ether",
            "coinAddress": "Ethereum",
            "coinSymbol": "ETH",
            "coinDecimal": 18,
            "coinPrice": 1213.88,
            "coinQuantity": 0.07726074380515578,
            "coinValue": 93.7852716902025,
            "coinPerc": 91.60917742101218
        },
        {
            "coinName": "Chain Link",
            "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
            "coinSymbol": "LINK",
            "coinQuantity": "0.754390953116979898",
            "coinDecimal": 18,
            "coinPrice": 6.21712,
            "coinValue": 4.690139082442639,
            "coinPerc": 4.58131405485491
        },
        {
            "coinName": "DAI",
            "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
            "coinSymbol": "DAI",
            "coinQuantity": "3.900000000000001195",
            "coinDecimal": 18,
            "coinPrice": 1,
            "coinValue": 3.9000000000000012,
            "coinPerc": 3.809508524132913
        }
    ],
    "tempTokenList":
    [
        {
            "coinName": "Ether",
            "coinAddress": "Ethereum",
            "coinSymbol": "ETH",
            "coinDecimal": 18,
            "coinPrice": 1213.88,
            "coinQuantity": 0.07726074380515578,
            "coinValue": 93.7852716902025,
            "coinPerc": 91.60917742101218
        },
        {
            "coinName": "Chain Link",
            "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
            "coinSymbol": "LINK",
            "coinQuantity": "0.754390953116979898",
            "coinDecimal": 18,
            "coinPrice": 6.21712,
            "coinValue": 4.690139082442639,
            "coinPerc": 4.58131405485491
        },
        {
            "coinName": "DAI",
            "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
            "coinSymbol": "DAI",
            "coinQuantity": "3.900000000000001195",
            "coinDecimal": 18,
            "coinPrice": 1,
            "coinValue": 3.9000000000000012,
            "coinPerc": 3.809508524132913
        }
    ]
    }    
     
    ]
    
    export const outputBigData = [
        {
            "increasedCoins": [
                {
                    "coinAddress": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
                    "coinName": "Wrapped Bitcoin",
                    "requiredCoinQuantity": 0.0003078937478595782,
                    "changedPerc": 5,
                    "usedPrice": 5.1542952860432685,
                    "coinSymbol": "WBTC",
                    "buyToken": "WBTC",
                    "totalAmount": 0.0003078937478595782,
                    "buyAmount": 30789.374785957818
                },
                {
                    "coinAddress": "0x4ddc2d193948926d02f9b1fe9e1daa0718270ed5",
                    "coinName": "Compound Ether",
                    "requiredCoinQuantity": 0.2117231935773283,
                    "changedPerc": 5,
                    "usedPrice": 5.1542952860432685,
                    "coinSymbol": "cETH",
                    "buyToken": "cETH",
                    "totalAmount": 0.2117231935773283,
                    "buyAmount": 21172319.35773283
                }
            ],
            "reducedCoins": [
                {
                    "coinAddress": "Ethereum",
                    "coinName": "Ether",
                    "requiredCoinQuantity": 0.0041329166335204864,
                    "changedPerc": 5,
                    "usedPrice": 5.051209380322403,
                    "coinPrice": 1222.19,
                    "coinDecimal": 18,
                    "sellToken": "ETH",
                    "buyToken": "Wei",
                    "sellAmount": 4132916633520486.5,
                    "feeQuantity": 84345237418785.44,
                    "totalAmount": 0.004217261870939272
                },
                {
                    "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                    "coinName": "Chain Link",
                    "requiredCoinQuantity": 0.48748063865478575,
                    "changedPerc": 3,
                    "usedPrice": 3.0307256281934416,
                    "coinPrice": 6.21712,
                    "coinDecimal": 18,
                    "sellToken": "LINK",
                    "buyToken": "Wei",
                    "sellAmount": 487480638654785700,
                    "feeQuantity": 9948584462342566,
                    "totalAmount": 0.49742922311712834
                },
                {
                    "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                    "coinName": "DAI",
                    "requiredCoinQuantity": 2.0204837521289614,
                    "changedPerc": 2,
                    "usedPrice": 2.0204837521289614,
                    "coinPrice": 1,
                    "coinDecimal": 18,
                    "sellToken": "DAI",
                    "buyToken": "Wei",
                    "sellAmount": 2020483752128961300,
                    "feeQuantity": 41234362288346150,
                    "totalAmount": 2.0617181144173076
                }
            ]
        },
        {
            "increasedCoins": [
                {
                    "coinAddress": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
                    "coinName": "Wrapped Bitcoin",
                    "requiredCoinQuantity": 0.00615434331585759,
                    "changedPerc": 100,
                    "usedPrice": 102.66183172048363,
                    "coinSymbol": "WBTC",
                    "buyToken": "WBTC",
                    "totalAmount": 0.00615434331585759,
                    "buyAmount": 615434.331585759
                }
            ],
            "reducedCoins": [
                {
                    "coinAddress": "Ethereum",
                    "coinName": "Ether",
                    "requiredCoinQuantity": 0.07573774782520984,
                    "changedPerc": 91.63258736135654,
                    "usedPrice": 92.19025878528018,
                    "coinPrice": 1217.23,
                    "coinDecimal": 18,
                    "sellToken": "ETH",
                    "buyToken": "Wei",
                    "sellAmount": 75737747825209840,
                    "feeQuantity": 1545668322963466,
                    "totalAmount": 0.0772834161481733
                },
                {
                    "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                    "coinName": "Chain Link",
                    "requiredCoinQuantity": 0.7393031340546403,
                    "changedPerc": 4.568532436877257,
                    "usedPrice": 4.596336300793785,
                    "coinPrice": 6.21712,
                    "coinDecimal": 18,
                    "sellToken": "LINK",
                    "buyToken": "Wei",
                    "sellAmount": 739303134054640400,
                    "feeQuantity": 15087819062339598,
                    "totalAmount": 0.7543909531169799
                },
                {
                    "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                    "coinName": "DAI",
                    "requiredCoinQuantity": 3.8220000000000014,
                    "changedPerc": 3.7988802017662158,
                    "usedPrice": 3.8220000000000014,
                    "coinPrice": 1,
                    "coinDecimal": 18,
                    "sellToken": "DAI",
                    "buyToken": "Wei",
                    "sellAmount": 3822000000000001500,
                    "feeQuantity": 78000000000000030,
                    "totalAmount": 3.9000000000000012
                }
            ]
        },
        {
            "increasedCoins": [
                {
                    "coinAddress": "Ethereum",
                    "coinName": "Ether",
                    "requiredCoinQuantity": 0.0070765966013466245,
                    "changedPerc": 8.390822578987823,
                    "usedPrice": 8.59013908244264,
                    "coinSymbol": "ETH",
                    "buyAmount": 6902384561067647,
                    "coinDecimal": 18
                }
            ],
            "reducedCoins": [
                {
                    "coinAddress": "0x514910771af9ca656af840dff83e8264ecf986ca",
                    "coinName": "Chain Link",
                    "requiredCoinQuantity": 0.7393031340546403,
                    "changedPerc": 4.58131405485491,
                    "usedPrice": 4.596336300793785,
                    "coinPrice": 6.21712,
                    "coinDecimal": 18,
                    "sellToken": "LINK",
                    "buyToken": "Wei",
                    "sellAmount": 739303134054640400,
                    "feeQuantity": 15087819062339598,
                    "totalAmount": 0.7543909531169799
                },
                {
                    "coinAddress": "0x6b175474e89094c44da98b954eedeac495271d0f",
                    "coinName": "DAI",
                    "requiredCoinQuantity": 3.8220000000000014,
                    "changedPerc": 3.809508524132913,
                    "usedPrice": 3.8220000000000014,
                    "coinPrice": 1,
                    "coinDecimal": 18,
                    "sellToken": "DAI",
                    "buyToken": "Wei",
                    "sellAmount": 3822000000000001500,
                    "feeQuantity": 78000000000000030,
                    "totalAmount": 3.9000000000000012
                }
            ]
        }
    ]