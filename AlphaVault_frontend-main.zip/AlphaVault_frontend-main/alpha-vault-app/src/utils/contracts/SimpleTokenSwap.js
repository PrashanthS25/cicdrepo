export const abiObj =  {
    "contractName": "SimpleTokenSwap",
    "abi": [
      {
        "inputs": [
          {
            "internalType": "contract IWETH",
            "name": "weth",
            "type": "address"
          }
        ],
        "stateMutability": "nonpayable",
        "type": "constructor"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "wethBal_",
            "type": "uint256"
          },
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "reqAmount_",
            "type": "uint256"
          }
        ],
        "name": "BadRequest",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "wethBal_",
            "type": "uint256"
          }
        ],
        "name": "EtherBalanceChange",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": true,
            "internalType": "address",
            "name": "previousOwner",
            "type": "address"
          },
          {
            "indexed": true,
            "internalType": "address",
            "name": "newOwner",
            "type": "address"
          }
        ],
        "name": "OwnershipTransferred",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": true,
            "internalType": "address",
            "name": "from_",
            "type": "address"
          },
          {
            "indexed": true,
            "internalType": "address",
            "name": "to_",
            "type": "address"
          },
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "amount_",
            "type": "uint256"
          }
        ],
        "name": "TransferFailed",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": true,
            "internalType": "address",
            "name": "from_",
            "type": "address"
          },
          {
            "indexed": true,
            "internalType": "address",
            "name": "to_",
            "type": "address"
          },
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "amount_",
            "type": "uint256"
          }
        ],
        "name": "TransferSuccessful",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "contract IERC20",
            "name": "buyToken",
            "type": "address"
          },
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "boughtAmount_",
            "type": "uint256"
          }
        ],
        "name": "WithdrawTokens",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "bool",
            "name": "status",
            "type": "bool"
          },
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "initialBuyTokenBalance",
            "type": "uint256"
          }
        ],
        "name": "ZeroXCallSuccess",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "buTokenAmount",
            "type": "uint256"
          }
        ],
        "name": "buyTokenBought",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "feePercentage",
            "type": "uint256"
          }
        ],
        "name": "feePercentageChange",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "contract IERC20",
            "name": "sellToken",
            "type": "address"
          },
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "allowance",
            "type": "uint256"
          }
        ],
        "name": "maxAllowanceGiven",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": false,
            "internalType": "uint256",
            "name": "maxTransactions",
            "type": "uint256"
          }
        ],
        "name": "maxTransactionsChange",
        "type": "event"
      },
      {
        "stateMutability": "payable",
        "type": "fallback"
      },
      {
        "inputs": [],
        "name": "WETH",
        "outputs": [
          {
            "internalType": "contract IWETH",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "feePercentage",
        "outputs": [
          {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "maxTransactions",
        "outputs": [
          {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "contract IERC20[]",
            "name": "sellToken",
            "type": "address[]"
          },
          {
            "internalType": "contract IERC20[]",
            "name": "buyToken",
            "type": "address[]"
          },
          {
            "internalType": "address[]",
            "name": "spender",
            "type": "address[]"
          },
          {
            "internalType": "address payable[]",
            "name": "swapTarget",
            "type": "address[]"
          },
          {
            "internalType": "bytes[]",
            "name": "swapCallData",
            "type": "bytes[]"
          },
          {
            "internalType": "uint256[]",
            "name": "amount",
            "type": "uint256[]"
          }
        ],
        "name": "multiSwap",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "owner",
        "outputs": [
          {
            "internalType": "address",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "renounceOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "uint256",
            "name": "num",
            "type": "uint256"
          }
        ],
        "name": "setMaxTransactionLimit",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "uint256",
            "name": "num",
            "type": "uint256"
          }
        ],
        "name": "setfeePercentage",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "newOwner",
            "type": "address"
          }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
          }
        ],
        "name": "withdrawETH",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "contract IERC20",
            "name": "token",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
          }
        ],
        "name": "withdrawFee",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "stateMutability": "payable",
        "type": "receive"
      }
    ]
  }