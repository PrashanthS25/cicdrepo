import React, { useState,useEffect } from 'react';
import {Alert,Button} from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import  comingsoon from "../assets/images/coming.png";
import {Link} from "react-router-dom";

export default function ErrorComponent(props) {
    const [error,showError] = useState(null)
    const [show, setShow] = useState(true);

    useEffect(()=>{
        if(props.error){
            showError(true)
        }
    },[props.error])

    const clickedCLose = () =>{
      showError(false)
      props.setError(null)
    }
    // const [show, setShow] = useState(false);
    const handleClose = () => {
      setShow(false)
      props.setError(null)
    }  
    const handleShow = () => setShow(true);

    return (
      <>  
      {
        console.log("props.error",props.error)
      }
      {
        console.log("props.error.message", props.error.message)
      }
      { 
        show?
        <>
        <div className='error-section'>
        {/* <button type="button" onClick={handleShow} className="btn btn-light btn-sm section1-button">modal</button> */}
         
               <Modal show={show} onHide={handleClose} className="coming-soon-modal">
                 <Modal.Header closeButton className="coming-soon-modal-bg">
                    <Modal.Title>
                        <h4 className="coming-soon-title"> Error </h4>
                    </Modal.Title>
                 </Modal.Header>
                 <Modal.Body className="coming-soon-modal-bg text-center">
                   <img className="coming-soon-img" src={comingsoon} alt="" />
                   {
                    console.log("errorStatement",typeof (props.error))
                   }
                   {
                    props.error!=="NoWalletConnection"? 
                      props.error.message==="Cannot read properties of undefined (reading 'provider')"?
                      <h4 className="coming-soon-text mt-3">"User rejected connection or please try again!"</h4>
                      :
                      <h4 className="coming-soon-text mt-3">{props.error}</h4>
                    :
                    <h3>Please Connect Your Wallet First. <Link to='/connectWallet'>Click To Connect</Link></h3>
                   }
                   
                   <p className="coming-soon-p mb-0">
                      
                   </p>
                 </Modal.Body>
                 {/* <Modal.Footer className="coming-soon-modal-bg">
                    <div className="coming-soon-content-box">
                      <h5>What to expect:</h5>
                      <ol type="1">
                        <li>We are introducing exclusive projects.</li>
                        <li>Commit to projects based on your tier level.</li>
                        <li>Go into each project details and read about their team, etc.</li>
                        <li>Invest freely in project you like.</li>
                      </ol>  
                    </div>
                 </Modal.Footer> */}
               </Modal>
        </div>
        </>
        :
        <></>
      }   
      </> 
    )
}