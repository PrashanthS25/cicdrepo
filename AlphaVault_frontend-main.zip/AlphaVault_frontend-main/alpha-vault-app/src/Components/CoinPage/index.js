/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useEffect,useState} from 'react'
import {connect} from 'react-redux'
import { useSearchParams, useNavigate } from 'react-router-dom'
import '../../App.css'
import '../CoinPage/CoinPage.css'
import '../../mobileApp.css';
import {MdArrowBackIosNew } from "react-icons/md";
import  coineth from "../../assets/images/coin-d-img.svg";
import  graph from "../../assets/images/graph.png";
import { Link } from 'react-router-dom';
import TradingViewChart from '../Home/TradingViewChart';
import API from '../../utils/Api'
import {initWallet} from '../../redux/index'
import Loader from '../Loader';
import { formatValue } from '../../Helper/helperFunctions'

 function CoinPage(props){
   const [searchParams, setSearchParams] = useSearchParams()
   const [requiredCoin,setRequiredCoin] = useState(null)
   const [isLoading,setLoading] = useState(false)
   const [activeTimeFilter3,setActiveTimeFilter3] = useState("1h")
   let navigate = useNavigate();
   useEffect(()=>{
      window.scrollTo(0, 0)
      let queryParams = searchParams.get('coinAddress')
      // console.log("queryParams",queryParams,props)
      setLoading(true)
      //console.log("here58")
      getCoinInfo(queryParams)   
   },[]) 

   const getTimeFilterClass3 = (currValue) =>{
      if(activeTimeFilter3 === currValue){
         return 'btn btn-primary section-g-button1 active'
      }  
      else{
         return 'btn btn-primary section-g-button1'
      }
   }

   const getCoinInfo = async(queryCoinAddress) =>{
      try{
      let requiredChainId 
      if(props.chain?.networkId && props.isWalletConnected){
         requiredChainId = props.chain.networkId
      }
      else{
         requiredChainId = 1
      }   
         
      let _coinInfo= await API.post('coin/info?coinChainID='+requiredChainId,{coinAddress:queryCoinAddress})  
      // console.log("_coinInfo",_coinInfo)
      if(_coinInfo.status===200){
         setRequiredCoin(_coinInfo.data.data)
        } 
        setLoading(false)  
      }
      catch(error){
         console.log("error",error)
         setLoading(false)
      }
   }

   return(
      <>
      {
      (isLoading||(!requiredCoin))?
      <Loader/>
      :
      <div className='section coinpage-section'>
          <section className='coins-details'>
            <div className='container'>
           
            <div className='section-top-heading-naviagte'>
              <button className='navigate-btn'onClick={()=>{navigate(-1)}}><MdArrowBackIosNew className='naviagte-arrow-icon'/></button>
                 <div className="section-heading ">
                       <h3 className="section-title">Coin Details</h3>
                 </div>
              </div>
              <div className='alphavault-sec-box coinpage-box'>
                <div className='coins-details-contents-box'>
                    <div className="coins-details-contents-left">
                         <img src={requiredCoin.coinLogoUrl} alt="" className="me-2 me-sm-3 coin-details-image" />
                       <div className="coins-details-content">
                        <h5 className="coin-details-text text-capitalize mb-0">{requiredCoin.coinName}<span className='ms-2 text-uppercase grey'>({requiredCoin.coinSymbol})</span></h5>
                       </div>
                    </div>
                  
                  {
                     requiredCoin.percent_change_24h?
                    <div className='coins-details-contents-right'>
                        <p className={requiredCoin.percent_change_24h>0?'coin-d-percent-green font-styl':'coin-d-percent-red font-styl'}>{formatValue(parseFloat(requiredCoin.percent_change_24h),2)}%</p>
                    </div>
                    :
                    null
                  }                       
                </div>
                <div className='coin-details-btm-info'>
                  <h5 className='coin-details-dollar font-styl'>${requiredCoin.coinPrice.toFixed(2)}</h5>
                   {/* <p className='coin-details-rank '>Rank # 2</p> */}
                </div>
                <div className='text-center'>
                <div className="btn-group section-grey-btn-bg mt-4">
                       <Link  className={getTimeFilterClass3("1h")} onClick={()=>setActiveTimeFilter3("1h")} aria-current="page">1hr</Link>
                       <Link    className={getTimeFilterClass3("1d")} onClick={()=>setActiveTimeFilter3("1d")}>1D</Link>
                       <Link    className={getTimeFilterClass3("7d")} onClick={()=>setActiveTimeFilter3("7d")}>1W</Link>
                       <Link    className={getTimeFilterClass3("1m")} onClick={()=>setActiveTimeFilter3("1m")}>1M</Link>
                       <Link    className={getTimeFilterClass3("3m")} onClick={()=>setActiveTimeFilter3("3m")}>3M</Link>
                       <Link    className={getTimeFilterClass3("1y")} onClick={()=>setActiveTimeFilter3("1y")}>1Y</Link>
                     </div>
                  </div>
                  {
                    props.chain?.networkId? 
                  <div className='graph-img mt-5'>
                  <TradingViewChart graphInterval={activeTimeFilter3} coinAddress={requiredCoin.coinAddress} coinChainID={props.chain?.networkId}/>
                  </div>
                  :
                  null
                  }
              </div>
            </div>
         </section>

         <section className='coin-page-about'>
            <div className='container'>
            <h5 className="alphavault-sub-title mb-2 mb-sm-4">About {requiredCoin.coinName}</h5>
              <div className='alphavault-sec-box coinpage-about-p'>
                 <p className='coin-page-about-p grey mb-0'>{requiredCoin.description}</p>
              </div>
            </div>
         </section>
         <section className='coinpage-market'>
          <div className='container'>
             <h5 className="alphavault-sub-title mb-2 mb-sm-4">Market</h5>
             <div className='alphavault-sec-box coinmarket-box'>
              {
               requiredCoin.market_cap ?
               <>
               <div className='details-content'>
                  <p className='details-c-left mb-0'>Market Cap</p>
                  <p className='details-c-right mb-0'>${requiredCoin.market_cap.toLocaleString()}</p>
               </div>
               <hr className='section-border-color' />
               </>
               :
               null
              }
              {
               requiredCoin.volume_24h ?
               <>
               <div className='details-content'>
                  <p className='details-c-left mb-0'>Volume (24)</p>
                  <p className='details-c-right mb-0'>${requiredCoin.volume_24h.toLocaleString()}</p>
               </div>
               <hr className='section-border-color' />
               </>
               :
               null
              }
              {
               requiredCoin.fully_diluted_market_cap?
               <>
               <div className='details-content'>
                  <p className='details-c-left mb-0'>Fully Diluted Market Cap</p>
                  <p className='details-c-right mb-0'>${requiredCoin.fully_diluted_market_cap.toLocaleString()}</p>
               </div>
               <hr  className='section-border-color' />
               </>
               :
               null
              }
               {/* <div className='details-content'>
                  <p className='details-c-left mb-0'>Circulating Supply</p>
                  <p className='details-c-right mb-0'>NA</p>
               </div>
               <hr  className='section-border-color' /> */}
               {
                 requiredCoin.total_supply? 
               <div className='details-content'>
                  <p className='details-c-left mb-0'>Total Supply</p>
                  <p className='details-c-right mb-0'>{(requiredCoin.total_supply).toLocaleString()} {requiredCoin.coinSymbol}</p>
               </div>
               :
               null
               }
               {
                requiredCoin.max_supply?  
                <>
               <hr  className='section-border-color' />
               <div className='details-content'>
                  <p className='details-c-left mb-0'>Max Supply</p>
                  <p className='details-c-right mb-0'>{requiredCoin.max_supply.toLocaleString()} {requiredCoin.coinSymbol}</p>
               </div>
               </>
               :
               null
               }
              </div>
          </div>
         </section>
         <section className='coinpage-social-links mt-5'>
          <div className='container'>
             <h5 className="alphavault-sub-title mb-2 mb-sm-4">Links</h5>
             <div className='alphavault-sec-box coinpage-social-links-box'>
               <div className='coinpage-social-links-tags'>
                {
                  requiredCoin.website?
                  <>
                  <a href={requiredCoin.website} target="_blank" rel="noopener noreferrer" className='coinpage-social-links-line'><p className='coinpage-social-links-p mb-0'>Website</p></a>
                  <hr className='section-border-color' />
                  </>   
                  :
                 null
                }
               </div>
               
               {/* <div className='coinpage-social-links-tags'>
                 <Link  className='coinpage-social-links-line'><p className='coinpage-social-links-p mb-0'>Twitter</p></Link>
               </div> */}
               {/* <hr className='section-border-color' /> */}
               <div className='coinpage-social-links-tags'>
                 {
                  requiredCoin.telegram && !requiredCoin.telegram.includes("NULL") && !requiredCoin.telegram.includes("null")?
                  <>
                 <a href={requiredCoin.telegram} target="_blank" rel="noopener noreferrer" className='coinpage-social-links-line'><p className='coinpage-social-links-p mb-0'>Telegram</p></a>
                 <hr className='section-border-color' />
                 </>
                 :
                 null
                }
               </div>
               
               {/* <div className='coinpage-social-links-tags'>
                 <Link  className='coinpage-social-links-line'><p className='coinpage-social-links-p mb-0'>Reddit</p></Link>
               </div>
               <hr className='section-border-color' />
               <div className='coinpage-social-links-tags'>
                 <Link  className='coinpage-social-links-line'><p className='coinpage-social-links-p mb-0'>Chat</p></Link>
               </div> */}
               {/* <hr className='section-border-color' /> */}
               <div className='coinpage-social-links-tags'>
               {
                  requiredCoin.explorer?
                 <a href={requiredCoin.explorer} className='coinpage-social-links-line' target="_blank" rel="noopener noreferrer"><p className='coinpage-social-links-p mb-0'>Explorer</p></a>
                 :
                 null
               }
               </div>
              </div>
          </div>
         </section>
      </div>
    }
      </>
   )
}

const mapStateToProps =(state)=>{
   return {
     chain: state.wallet.chain,
     isWalletConnected: state.wallet.isWalletConnected,
   }
 }
 
 const mapStateToDispatch = (dispatch)=>{
   return{
     initWallet: (walletInfo) => dispatch(initWallet(walletInfo)), 
   }
 }
 
 export default connect(mapStateToProps,mapStateToDispatch)(CoinPage)