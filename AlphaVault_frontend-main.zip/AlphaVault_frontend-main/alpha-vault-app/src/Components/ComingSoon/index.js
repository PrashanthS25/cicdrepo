import React,{useState} from "react";
import '../../App.css'
import '../../mobileApp.css';
import '../ComingSoon/ComingSoon.css';
import Modal from 'react-bootstrap/Modal';
import  comingsoon from "../../assets/images/coming.png";

export default function ComingSoon() {

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  return (
      <>
          <button type="button" onClick={handleShow} className="btn btn-light btn-sm section1-button">ComingSoon</button>
          
          <Modal show={show} onHide={handleClose} className="coming-soon-modal" centered>
            <Modal.Header closeButton className="coming-soon-modal-bg">
               <Modal.Title>
                   <h4 className="coming-soon-title"> Page Name</h4>
               </Modal.Title>
            </Modal.Header>
            <Modal.Body className="coming-soon-modal-bg text-center">
              <img className="coming-soon-img" src={comingsoon} alt="" />
              <h4 className="coming-soon-text mt-3">Coming Soon!</h4>
              <p className="coming-soon-p mb-0">
                 We are working hard to bring this page soon to our users.
              </p>
            </Modal.Body>
            <Modal.Footer className="coming-soon-modal-bg">
               <div className="coming-soon-content-box">
                 <h5>What to expect:</h5>
                 <ol type="1" className="coming-soon-ol mb-0">
                   <li>We are introducing exclusive projects.</li>
                   <li>Commit to projects based on your tier level.</li>
                   <li>Go into each project details and read about their team, etc.</li>
                   <li>Invest freely in project you like.</li>
                 </ol>  
               </div>
            </Modal.Footer>
          </Modal>
       </>
  )
}