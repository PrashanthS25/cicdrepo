import React, { useEffect, useState } from 'react'
import '../SupportedCoins/SupportedCoins.css'
import '../../App.css'
import '../../mobileApp.css';
import Pagination from '@mui/material/Pagination';
import Loader from "../Loader"
import Stack from '@mui/material/Stack';
import HomeWalletInfo from '../../MobileComponents/HomeWalletInfo';
import API from '../../utils/Api'
import {formatValue} from '../../Helper/helperFunctions'
import { useNavigate } from 'react-router-dom';
import { connect } from 'react-redux'

function SupportedCoins(props) {


  let [coinList, setCoinList] = useState(null)
  let [page, setPage] = useState(1);
  let [totals, setTotals] = useState({});
  let [isLoading, setLoading] = useState(false)
  let navigate = useNavigate()

  useEffect(() => {
    window.scrollTo(0, 0)
    setLoading(true);
    getCoinList()
  }, [page])

  const getCoinList = async () => {
    let coinresponse = await API.get(
      "/coin/list?coinChainID="+props.chain.networkId+"&page="+page
    );
    console.log("coinList:**", coinresponse.data.data)
    setCoinList(coinresponse.data.data)
    console.log("COUNT!!!!!!=-----", coinresponse.data.count)
    setTotals({
      ...totals,
      totalPages: Math.ceil(coinresponse.data.count / 5),
      totalCount: parseInt(coinresponse.data.count)
    });
    setLoading(false);
  }

  const navigateToCoin = (coinAddress) => {
    navigate("/coinpage?coinAddress=" + coinAddress)
  }

  const handlePage = (event, value) => {
    setPage(value)
    console.log(value)
  }



  return (
    <>
      <section className='section'>
        <div className='container'>
          <HomeWalletInfo />
          {coinList === null || isLoading ? <Loader /> :
            <div className="home-sections-box supported-coin-page-mob">
              <div className="supported-tokens-top-section">
                <h5 className="alphavault-sub-title">supported Tokens</h5>
                <h5 className="supported-balance">Total: <span>{totals.totalCount} Tokens</span></h5>
              </div>
              <div className="supported-tokens-details mt-1">


                {coinList.map((coin) => {
                  return (
                    <div className="supported-tokens-box">
                      <div className="supported-tokens-box-left">
                        <img src={coin.coinLogoUrl} alt="" className="me-3 exploreVaultTableImage" />
                        <div className="supported-tokens-box-text">
                          <button className="select-token-d-btn d-flex text-capitalize" onClick={() => navigateToCoin(coin.coinAddress)}>{coin.coinName}</button>
                          <h6 className="mb-0 grey text-uppercase supported-t-sn">{coin.coinSymbol}</h6>
                        </div>
                      </div>
                      <div className="supported-tokens-box-right">
                        <h5 className="font-styl supported-t-dollar">{formatValue(coin.coinPrice,2).toLocaleString()}</h5>
                        <h6 className={parseFloat(coin.percent_change_1h) >= 0 ?'mb-0 green supported-t-prcnt':'mb-0 red supported-t-prcnt'}>{formatValue(coin.percent_change_1h,4).toLocaleString()}%</h6>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className='mt-4'>
                <Stack spacing={2}>
                  <Pagination defaultPage={page} count={totals.totalPages} siblingCount={0} className='pagination-btn' onChange={handlePage} />
                </Stack>
              </div>
            </div>
          }
        </div>
      </section>
    </>
  )
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance
  }
}

const mapStateToDispatch = (dispatch) => {
  return {
  }
}

export default connect(mapStateToProps, mapStateToDispatch)(SupportedCoins)