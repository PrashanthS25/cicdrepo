/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React from "react";
import { ThreeDots } from  'react-loader-spinner'

export default function Loader() {

    return(
    <>  
    {/* {
      console.log("here1")
    } */}
     <div className="section d-flex justify-content-center threedots">
     <ThreeDots 
        height="80" 
        width="80" 
        radius="9"
        color="#4fa94d" 
        ariaLabel="three-dots-loading"
        wrapperStyle={{}}
        wrapperClassName=""
        visible={true}
     />
     </div>
  </>
    )
}
// import {Spinner} from 'react-bootstrap';

// function Loader() {
//   return (
//     <Spinner animation="border" role="status">
//       <span className="visually-hidden">Loading...</span>
//     </Spinner>
//   );
// }

// export default Loader;
