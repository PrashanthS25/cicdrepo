import React from 'react';
import '../../App.css'
import '../../mobileApp.css';
import '../Settings/Settings.css'
import { MdArrowBackIosNew } from "react-icons/md";
import { BsCheck2 } from "react-icons/bs";
import {
   NavLink
 } from "react-router-dom";

 
export default function Language(){

   return(
      <>
      <section className='section setting-sec'>
         <div className='container'>
           <div className='section-top-heading-naviagte mt-4 mt-lg-0 mb-5 mb-lg-4'>
               <button className='navigate-btn'><NavLink to='/settings'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button> 
               <div className="section-heading naviagte-hidden">
                     <h3 className="section-title setting-section-heading">Language</h3>
               </div>
            </div>
            <div className="alphavault-sec-box px-5 py-3 py-sm-4 settings-currency-box">
               <div className='d-flex justify-content-between'>
                  <p className='mb-0 language-name'>English</p>
                   <BsCheck2 className='setting-lang-image purple' />
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between'>
                  <p className='mb-0 language-name'>Chinese</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between'>
                  <p className='mb-0 language-name'>Spanish</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between'>
                  <p className='mb-0 language-name'>French</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between'>
                  <p className='mb-0 language-name'>French</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between'>
                  <p className='mb-0 language-name'>French</p>
                   {/* <BsCheck2 className='setting-lang-image purple' /> */}
               </div>
            </div>
         </div>
      </section>
      </>
   )
}