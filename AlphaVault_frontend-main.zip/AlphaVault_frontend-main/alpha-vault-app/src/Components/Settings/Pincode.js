import React, { useState } from "react";

import '../../App.css'
import '../../mobileApp.css';
import '../Settings/Settings.css'
import { MdArrowBackIosNew } from "react-icons/md";
import {
   NavLink
 } from "react-router-dom";

 
export default function Pincode(){

  

   return(
      <>
      <section className='section setting-sec'>
         <div className='container'>
           <div className='section-top-heading-naviagte mt-4 mt-lg-0 mb-5 mb-lg-4'>
               <button className='navigate-btn'><NavLink to='/settings'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button> 
               <div className="section-heading naviagte-hidden">
                     <h3 className="section-title setting-section-heading">Setup a PIN Code</h3>
                     {/* <h3 className="section-title setting-section-heading">Change PIN Code</h3> */}
               </div>
            </div>

           <div className='pincode-info'> 
              <h5 className='pincode-title'>Enter a 6 Digits PIN Code.</h5>
              {/* <h5 className='pincode-title'>Enter Your Old PIN Code</h5> */}
                <div class="d-flex flex-row justify-content-center pincode-input-box">
                   <input className="m-2 text-center form-control pincode-input" type="password" id="first" maxlength="1" /> 
                   <input className="m-2 text-center form-control pincode-input" type="password" id="second" maxlength="1" /> 
                   <input className="m-2 text-center form-control pincode-input" type="password" id="third" maxlength="1" />
                   <input className="m-2 text-center form-control pincode-input" type="password" id="fourth" maxlength="1" /> 
                   <input className="m-2 text-center form-control pincode-input" type="password" id="fifth" maxlength="1" />
                   <input className="m-2 text-center form-control pincode-input" type="password" id="sixth" maxlength="1" /> 
                </div> 
            
              <p className='pincode-msg mt-4'>PINs don't match</p>
           </div>
         </div>
       </section>
      </>
   )
}