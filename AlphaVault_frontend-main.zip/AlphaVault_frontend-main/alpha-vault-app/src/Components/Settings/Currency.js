import React from 'react';
import '../../App.css'
import '../../mobileApp.css';
import '../Settings/Settings.css'
import { MdArrowBackIosNew } from "react-icons/md";
import { BsCheck2 } from "react-icons/bs";
import {
   NavLink
 } from "react-router-dom";
 import { IoSearchOutline } from "react-icons/io5";
 
export default function Currency(){

   return(
      <>
      <section className='section setting-sec'>
         <div className='container'>
           <div className='section-top-heading-naviagte mt-4 mt-lg-0 mb-5 mb-lg-4'>
               <button className='navigate-btn'><NavLink to='/settings'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button> 
               <div className="section-heading naviagte-hidden">
                     <h3 className="section-title setting-section-heading">Default Currency</h3>
               </div>
            </div>
            <div className='currency-setting-search mt-4 mb-4'>
                <form className="select-token-search-box">
                   <IoSearchOutline className="currency-search-alpha" />
                   <input className="form-control currency-search-plchldr" type="search" placeholder="Search currency by name or symbol" aria-label="Search" />
                </form>
            </div>
            <div className="alphavault-sec-box px-5 py-3 py-sm-4 settings-currency-box">
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>United States Dollar (USD)</p>
                  <div>
                   <BsCheck2 className='setting-lang-image purple' />
                   </div>
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>Lebanese Pound (LB)</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>Euro (EUR)</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>Chinese Yuan (CNY)</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>Indian Rupees (INR)</p>
                   {/* <BsCheck2 className='setting-lang-image  purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>Japanese Yen (JPY)</p>
                   {/* <BsCheck2 className='setting-lang-image purple' /> */}
               </div>
               <hr className='section-border-color' />
               <div className='d-flex justify-content-between align-items-center'>
                  <p className='mb-0 currency-text'>Korean Won (KRW)</p>
                   {/* <BsCheck2 className='setting-lang-image purple' /> */}
               </div>
            </div>
         </div>
      </section>
      </>
   )
}