import React,{useState} from 'react';
import '../../App.css'
import '../../mobileApp.css';
import '../Settings/Settings.css'
import { MdArrowBackIosNew } from "react-icons/md";
import { AiOutlineEye, AiOutlineEyeInvisible } from "react-icons/ai";

import {
   NavLink
 } from "react-router-dom";
 import Button from 'react-bootstrap/Button';
 import Form from 'react-bootstrap/Form';
 
export default function CreatePassword(){

   const [type,setType] = useState("password");

   return(
      <>
      <section className='section setting-sec'>
         <div className='container'>
           <div className='section-top-heading-naviagte mt-4 mt-lg-0 mb-5 mb-lg-4'>
               <button className='navigate-btn'><NavLink to='/settings'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button> 
               <div className="section-heading naviagte-hidden">
                     <h3 className="section-title setting-section-heading">Create Password</h3>
               </div>
            </div>
            <div className='create-password-form'>
            <Form   >
              <Form.Group className="mb-3 create-password-block" controlId="formBasicPassword1">
                <Form.Control  placeholder="Enter password" className='create-password-input' id="password" name="password" max={50}   />
                    
              <div className="create-password-eye" 
                   onClick={() => setType(type === "text" ? "password" : "text")} >
                  {type === "password" ? (
                    <AiOutlineEye size={33} className='eye-icon' />
                  ) : (
                    <AiOutlineEyeInvisible size={33} className='eye-icon' />
                  )}
                </div>

              </Form.Group>
              <Form.Group className="mb-3 create-password-block" controlId="formBasicPassword">
                <Form.Control type="password" placeholder="Confirm password" className='create-password-input mb-3' />
                <div className="create-password-eye" 
                  onClick={() => setType(type === "text" ? "password" : "text")} >
                  {type === "password" ? (
                    <AiOutlineEye size={33} className='eye-icon' />
                  ) : (
                    <AiOutlineEyeInvisible size={33} className='eye-icon' />
                  )}
                </div>
                <Form.Text className="text-muted create-password-msg">
                Passwords don't match, or any error text here
                </Form.Text>
              </Form.Group>
              {/* <Form.Group className="mb-3 create-password-block" controlId="formBasicPassword">
                <Form.Control type="password" placeholder="New password" className='create-password-input mb-3' />
                <div className="create-password-eye" 
                  onClick={() => setType(type === "text" ? "password" : "text")} >
                  {type === "password" ? (
                    <AiOutlineEye size={33} className='eye-icon' />
                  ) : (
                    <AiOutlineEyeInvisible size={33} className='eye-icon' />
                  )}
                </div>
                <Form.Text className="text-muted create-password-msg">
                Passwords don't match, or any error text here
                </Form.Text>
              </Form.Group> */}
              {/* <Form.Group className="mb-3 create-password-block" controlId="formBasicPassword">
                <Form.Control type="password" placeholder="Confirm New password" className='create-password-input mb-3' />
                <div className="create-password-eye" 
                  onClick={() => setType(type === "text" ? "password" : "text")} >
                  {type === "password" ? (
                    <AiOutlineEye size={33} className='eye-icon' />
                  ) : (
                    <AiOutlineEyeInvisible size={33} className='eye-icon' />
                  )}
                </div>
                <Form.Text className="text-muted create-password-msg">
                Passwords don't match, or any error text here
                </Form.Text>
              </Form.Group> */}
              <Button variant="secondary" type="submit" className='create-password-btn'>
                 Create Password
              </Button>
              {/* <Button variant="secondary" type="submit" className='create-password-btn new-password-btn'>
                 Update Password
              </Button> */}
            </Form>
      
            </div>
         </div>
      </section>
      </>
   )
}