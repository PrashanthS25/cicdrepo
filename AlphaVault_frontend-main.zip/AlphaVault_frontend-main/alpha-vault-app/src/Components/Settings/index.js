/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useEffect} from 'react';
import {
  NavLink
} from "react-router-dom";

import '../../App.css'
import '../../mobileApp.css';
import '../Settings/Settings.css'
import { BsGlobe } from "react-icons/bs";
import { MdArrowForwardIos } from "react-icons/md";
import  currency from "../../assets/images/currency.svg";
import  bell from "../../assets/images/bell.svg";
import  wallet from "../../assets/images/Wallet.svg";
import  lock from "../../assets/images/lock.png";
import  sheild from "../../assets/images/security.png";
import  biometric from "../../assets/images/biometric.svg";



export default function Settings(){
  useEffect(() =>{
    window.scrollTo(0, 0)
  },[])

   return(
      <>
     
      <section className='section setting-sec'>
        <div className="container">
            <div className="section-heading">
                <h3 className="section-title mb-4">settings</h3>
            </div>
            <div className='general-setting'>
                <h5 className='mb-0'>General</h5>
                <div className='settings-box'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <BsGlobe className='globe'/>
                          <p className='mb-0 ms-3'>Language</p>
                        </div>
                        <div className='setting-box-right-info d-flex align-items-center'>
                          <p className='mb-0 me-2 purple font-styl'>English</p>
                            <NavLink to='/settings/language'> <MdArrowForwardIos className='purple setting-right-arrow'/></NavLink>
                        </div>
                    </div>
                </div>
                <div className='settings-box'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <img src={currency}  className="setting-image" alt="" />
                          <p className='mb-0 ms-3'>Default Currency</p>
                        </div>
                        <div className='setting-box-right-info d-flex align-items-center'>
                          <p className='mb-0 me-2 purple font-styl'>USD</p>
                            <NavLink to='/settings/currency'> <MdArrowForwardIos className='purple setting-right-arrow'/></NavLink>
                        </div>
                    </div>
                </div>
                <div className='settings-box'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <img src={bell}  className="setting-bell-image" alt="" />
                          <p className='mb-0 ms-3'>Push Notifications</p>
                        </div>
                        <div className='setting-box-right-info'>
                        <div className="form-check form-switch d-flex" >
                           <input className="form-check-input seting-toggle" type="checkbox" id="flexSwitchCheckChecked"  />
                           {/* <label className="form-check-label" for="flexSwitchCheckChecked"></label> */} 
                         </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='wallet-setting mt-5'>
                <h5 className='mb-0'>Wallet</h5>
                <div className='settings-box'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <img src={wallet}  className="setting-image" alt="" />
                          <p className='mb-0 ms-3'>Connect Wallet</p>
                        </div>
                        <div className='setting-box-right-info'>
                          <NavLink to='/connectWallet'> <MdArrowForwardIos className='purple setting-right-arrow'/></NavLink>
                        </div>
                    </div>
                </div>
            </div>
            <div className='security-setting mt-5'>
                <h5 className='mb-0'>Security</h5>
                <div className='settings-box'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <img src={lock} className="setting-lock-image" alt="" />
                          <p className='mb-0 ms-3'>Password</p>
                        </div>
                        <div className='setting-box-right-info'>
                          <NavLink to='/settings/createpassword'> <MdArrowForwardIos className='purple setting-right-arrow'/></NavLink>
                        </div>
                    </div>
                </div>
                <div className='settings-box bio-metric'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <img src={biometric}  className="biometric-image" alt="" />
                          <p className='mb-0 ms-3'>Biometric authentication</p>
                        </div>
                        <div className='setting-box-right-info'>
                         <div className="form-check form-switch d-flex" >
                           <input className="form-check-input seting-toggle" type="checkbox" id="flexSwitchCheckChecked"/>
                         </div>
                        </div>
                    </div>
                </div>
                <div className='settings-box'>
                    <div className='settings-box-content'>
                        <div className='setting-box-left-info d-flex align-items-center'>
                          <img src={sheild}  className="setting-lock-image" alt="" />
                          {/* <RiShieldCheckLine/> */}
                          <p className='mb-0 ms-3'>PIN code</p>
                        </div>
                        <div className='setting-box-right-info'>
                          <NavLink to='/settings/pincode'> <MdArrowForwardIos className='purple setting-right-arrow'/></NavLink>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </section>
      </>
   )
}