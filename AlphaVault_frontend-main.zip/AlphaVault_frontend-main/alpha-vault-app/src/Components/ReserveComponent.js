import React,{useEffect,useState} from 'react'
import {connect} from 'react-redux'
import ProgressBar from 'react-bootstrap/ProgressBar';
import './ConnectWallet/ConnectWallet.css'
import {initWallet} from '../redux/index'
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Popover from 'react-bootstrap/Popover';
import Button from 'react-bootstrap/Button';


function ReserveComponent(props) {
 
    return(
        <>
        {props.serverResponse?
        <div className='reserve-tokens-section'>
           <div className='container'>
            <div className='alphavault-sec-box py-4 reserve-tokens-box'>
            <div className='iReserveInfo'>
                          
                          {['top'].map((placement) => (
                        <OverlayTrigger
                          
                          key={placement}
                          placement={placement}
                          overlay={
                            <Popover id={`popover-positioned-${placement}`}>
                              <Popover.Body>
                                <p>-Reserve tokens acts like reserve fuel in fuel tank.</p>
                                <p>-Ethereum of amount $15 is reserved ,for making future transaction smooth if remaining 90% ethers are completely sold. </p> 
                                <p>-$15 of reserved Ethereum is not included in the Current Wallet Balance.</p>
                              </Popover.Body>
                            </Popover>
                          }
                        >
                           <Button variant="secondary" className='stake-i-button ms-2'>!</Button>
                        </OverlayTrigger>
                      ))}
                  </div>
              <h4 className='text-center reserve-tokens-title'>Reserve Tokens</h4>
              <p className='ms-0 ms-sm-3 text-center'>Total Reserve Amount: {props.serverResponse.reserveObj.reserveQuantity}$</p>
              <div className='prog-bar p-0 reserve-tokens-prog-bar'>
                  <ProgressBar  now={props.serverResponse.reserveObj.reservePerc} label={`${props.serverResponse.reserveObj.reservePerc}%`}  />
              </div>
            </div>
           </div>
        </div>
        :
        null
        }
        </>

    )
}

const mapStateToProps =(state)=>{
    return {
      walletAddress: state.wallet.walletAddress,
      chain: state.wallet.chain,
      isWalletConnected: state.wallet.isWalletConnected,
      isPolicyAccepted: state.wallet.isPolicyAccepted,
      assets: state.wallet.assets,
      loader: state.wallet.loader,
      serverResponse: state.wallet.serverResponse,
      web3InStance:state.wallet.web3InStance,
      error: state.wallet.error,
    }
  }
  
  const mapStateToDispatch = (dispatch)=>{
    return{
      initWallet: (walletInfo) => dispatch(initWallet(walletInfo))
    }
  }
  
  export default connect(mapStateToProps,mapStateToDispatch)(ReserveComponent)

