/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useState,useEffect} from 'react'
import {wethAbi} from '../../Helper/contractAbi/wethContractAbi'
import BigNumber from 'bignumber.js';

export default function WethExchange(props) {
    const [nativeContractInstance, setNativeContractInstance] = useState(null)
    const [exchangeQuant,setExchangeQuant] = useState(null)
    useEffect(()=>{
        setNativeContractInstance(new props.web3Instance.eth.Contract(wethAbi, props.network.baseCurrencyAddress))
    },[])

    const exchangEthToWeth = async () =>{
    try{
      if(!exchangeQuant){
        throw new Error('Please Enter valid amount to exchange Ether with Weth.');
      }     
      let exchangeValue= (new BigNumber(exchangeQuant).dividedBy(new BigNumber(10).pow(new BigNumber(18)))).toNumber()
      await nativeContractInstance.methods.deposit().send({ from: props.walletAddress, value: exchangeValue})
    }
    catch(error){
      console.log(error)
    }
    }

    return(
       <>
         <p>In Weth Exchange</p>
         <div>
            <input type='number' onChange={(e)=>setExchangeQuant(e.target.value)}/>
            <button onClick={exchangEthToWeth}>Exhange</button>
         </div>
       </> 
    )
}

