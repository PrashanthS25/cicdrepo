/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useState, useEffect, useRef } from "react";
import Table from "react-bootstrap/Table";
import { connect } from "react-redux";
import { initWallet, fetchWalletResponse } from "../../redux/index";
import Emitter from "../../Helper/emitter";
import { formatValue } from "../../Helper/helperFunctions";
import { MdDeleteForever } from "react-icons/md";
import "../../mobileApp.css";
function EditVault(props) {
  const [percentageMode, setPercentageMode] = useState(true);
  const [removedValue, setRemovedValue] = useState(false);
  const ipRef = useRef();

  useEffect(() => {
    Emitter.on("setLoading", (data) => {
      // console.log("hereFit123", data.isLoading);
      props.setLoading(data.isLoading);
    });
  }, [percentageMode,props.chain?.networkId,props.serverResponse?.totalBal]);

  const formatPrice = (coinPerc, totalBal) => {
    return Math.floor(
      (parseFloat(coinPerc).toFixed(2) * Math.floor(+totalBal)) / 100
    );
  };

  const changePercMode = () => {
    let _percentageMode = percentageMode;
    _percentageMode = !_percentageMode;
    // console.log("mode", _percentageMode);
    setPercentageMode(_percentageMode);
  };

  const removeNewElement = (index) => {
    setRemovedValue(true);
    // props.setElementRemoved(true)
    // console.log("intoHere1", index);

    let _tokenList = props.tokenList;
    let _tempTokenList = props.tempTokenList;

    _tokenList.splice(index, 1);
    _tempTokenList.splice(index, 1);
    // console.log("nt63", _tokenList, _tempTokenList);
    props.setTempTokenList(_tempTokenList);
    props.setTokenList(_tokenList);
    props.sumPerc(_tempTokenList);

    setRemovedValue(false);
    props.setEditLength(_tokenList.length);
    props.setElementRemoved(!props.elementRemoved);
  };

  return (
    <>
      <div className="container">
        <div className="edit-vault-body-sec">
          <Table>
            <thead className="edit-vault-tbl-head">
              <tr>
                <th>
                  <label className="switch">
                    <input type="checkbox" onClick={(e) => changePercMode()} />
                    <span className="slider round">
                      <p>% </p>
                      <p>$</p>
                    </span>
                  </label>
                </th>
                <th className="text-end">Current</th>
                {/* {console.log("percentageMode", percentageMode)} */}
                <th className="text-end">New</th>
              </tr>
            </thead>
            <hr className="section-border-color edit-vault-border" />
            <tbody className="edit-vault-body position-relative">
              
              {props.tokenList.length && props.tempTokenList.length ? (
                props.tokenList.map((e, i) => {
                  return (
                    <>
                      
                      <tr>
                        <td className="edit-vault-width">

                          {e.isNewlyAdded ? (
                            <button
                              className="btn edit-vault-btn-dlt"
                              onClick={() => removeNewElement(i)}
                            >
                              <MdDeleteForever className="edit-vault-delete-btn" />
                            </button>
                          ) : (
                            <></>
                          )}
                          <div className="d-flex align-items-center">
                            <img
                              src={e.coinLogo?e.coinLogo:e.coinLogoUrl}
                              alt=""
                              className="me-3 mobile-v-hp-image exploreVaultTableImage"
                            />
                            <h6 className="text-capitalize mb-0 edit-vault-coin-n">
                              {e.coinName}
                            </h6>
                          </div>

                          {e.isNewlyAdded ? (
                            <div className="edit-vault-add-bottom-coin-text">
                              <p className="new-coin-add text-uppercase">new</p>
                            </div>
                          ) : (
                            <h6 className="edit-vault-quant">
                              {parseFloat(e.coinQuantity).toFixed(8)}
                            </h6>
                          )}
                        </td>
                        <td className="text-end edit-vault-body-d">
                          <div className="edit-vault-right-prcnt">
                            <h6>
                              {e.isNewlyAdded
                                ? percentageMode
                                  ? 0 + "%"
                                  : "~$" + 0
                                : percentageMode
                                ? +formatValue(
                                    props.tempTokenList[i].exactCoinPerc,
                                    2
                                  ) + "%"
                                : "~$" +
                                  formatPrice(
                                    e.coinPerc,
                                    props.serverResponse.totalBal
                                  )}{" "}
                            </h6>
                          </div>
                          
                          <div>
                            <h6 className="edit-vault-td-dollar">
                              {e.isNewlyAdded
                                ? percentageMode
                                  ? "~$" + 0
                                  : 0 + "%"
                                : percentageMode
                                ? "~$" +
                                  formatPrice(
                                    e.coinPerc,
                                    props.serverResponse.totalBal
                                  )
                                : formatValue(+e.coinPerc, 2) + "%"}
                            </h6>
                          </div>
                        </td>
                        <td className="text-end edit-vault-body-d">
                          {percentageMode ? (
                            <div id="t1" className="edit-vault-td-percent-box">
                              <input
                                className="edit-vault-body-input active"
                                type="text"
                                id="n1"
                                defaultValue={
                                  formatValue(
                                    +props.tempTokenList[i].coinPerc,
                                    2
                                  ) + "%"
                                }
                                onChange={(e) =>
                                  props.changeperc(
                                    e.target.value,
                                    i,
                                    percentageMode
                                  )
                                }
                              />
                            </div>
                          ) : null}
                          {!percentageMode ? (
                            <div id="t2" className="edit-vault-td-percent-box">
                              <input
                                className="edit-vault-body-input active"
                                id="n2"
                                type="text"
                                defaultValue={
                                  "~$" +
                                  formatPrice(
                                    props.tempTokenList[i].coinPerc,
                                    props.serverResponse.totalBal
                                  )
                                }
                                onChange={(e) =>
                                  props.changeperc(
                                    e.target.value,
                                    i,
                                    percentageMode
                                  )
                                }
                              />
                            </div>
                          ) : null}
                          <div>
                            <h6 className="me-2 edit-vault-td-dollar active">
                              {percentageMode
                                ? "~$" +
                                  formatPrice(
                                    props.tempTokenList[i].coinPerc,
                                    props.serverResponse.totalBal
                                  )
                                : +props.tempTokenList[i].coinPerc + "%"}
                            </h6>
                          </div>
                        </td>
                      </tr>
                      {i == props.tokenList.length - 1 ? (
                        <>
                          <hr className="section-border-color edit-vault-border" />
                          <tr className="edit-vault-body-tbl-last-row">
                            <td colSpan={2} className="py-4">
                              {" "}
                              <h5 className="edit-vault-body-tbl-last">
                                {props.sum == 100 || props.sum > 100
                                  ? 0
                                  : formatValue(100 - +props.sum, 2)}
                                %&nbsp;&nbsp;<span className="grey">Left</span>
                              </h5>
                            </td>
                            {props.tempTokenList && props.sum == 100 ? (
                              <td className="text-end">
                                <h5 className="edit-vault-body-tbl-total">
                                  Total:
                                  <green_color className="green_color">
                                    {" "}
                                    ~{props.sum}%
                                  </green_color>
                                </h5>
                              </td>
                            ) : (
                              <td className="text-end">
                                <h5 className="edit-vault-body-tbl-total">
                                  Total:<span> ~{props.sum}%</span>
                                </h5>
                              </td>
                            )}
                          </tr>
                        </>
                      ) : null}
                    </>
                  );
                })
              ) : (
                <></>
              )}
            </tbody>
          </Table>
        </div>
      </div>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(EditVault);
