import react,{useState,useEffect} from "react";
import {Modal} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import Emitter from '../../Helper/emitter';
import ProgressBar from 'react-bootstrap/ProgressBar';
import '../../mobileApp.css';

export default function TxSuccessModal(props){
  const [progressPerc,setProgressperc] = useState(0)

  useEffect(()=>{
    Emitter.on("txStatus",(data)=>{
      // console.log.log("statusPerc",data,data.statusPerc)
      setProgressperc(data.statusPerc)
    })
  },[])

    const handleCloseToEdit = () =>{
      // setShow1(false)
      props.setShowSuccessModal(false)     
    } 
    const handleCloseToWallet = () =>{
      // setShow1(false);
      // props.setShowSuccessModal(false)      
      // props.setEditVaultMode(false)
      window.location.reload()
    } 

    return(
        <>
        <Button variant="primary" className='btn-sm section1-button txsuccessfull-btn' onClick={handleCloseToEdit}>popup</Button>

                 <Modal show={props.showSuccessModal} onHide={handleCloseToEdit}  aria-labelledby="contained-modal-title-vcenter"
                 centered backdrop="static">
                   <Modal.Header closeButton className="tx-successfull-header">  
                   {
                    progressPerc===100?
                     <Modal.Title className='generic-popup-title'>Successful Transaction</Modal.Title>
                     :
                     <Modal.Title className='generic-popup-title'>Transaction Progress</Modal.Title>
                   }
                   </Modal.Header>
                   <Modal.Body className='generic-popup-body'>
                   {
                    progressPerc===100?
                    <><p className="generic-p">You have successfully bought/sold the following:</p></>
                    :
                    null
                   } 
                   <div className='generic-bought'>
                    <p>Bought</p>
                    {
                        props.changedCoins.increasedCoins.map((token,i)=>{
                            return(
                                <>
                                {
                                  // console.log.log("inCoin",token)
                                }
                            <div className='generic-popup-body-details d-flex justify-content-between ' key={token.coinAddress}>
                                <div className="d-flex align-items-center">
                                <img src={token.coinLogoUrl} alt="" className="me-2 me-sm-4 exploreVaultTableCoinImage" />
                                <h6 className="text-capitalize mb-0">{token.coinName}</h6>
                            </div>
                                <div className="d-flex align-items-center">
                                <h6 className='me-2 me-sm-3 mb-0 generic-popup-p'>~{token.requiredCoinQuantity}</h6>
                                <h6 className='grey  mb-0 text-uppercase'>{token.coinSymbol}</h6>
                            </div>
                     
                             </div>

                             {
                                (props.changedCoins.increasedCoins.length-1> i)?
                                <hr  className='section-border-color' />      
                                :
                                null
                             }   

                                </>
                            )
                        })
                    }
                   
                   </div>
                   {
                    // console.log.log("changedCoinInModal",props.changedCoins)
                   }
                   <div className='generic-sold'>
                    <p>sold</p>
                    {
                        props.changedCoins.reducedCoins.map((token,i)=>{
                            return(
                                <>
                                {
                                  // console.log.log("sellToken",token,token.sellToken)
                                }
                            <div className='generic-popup-body-details d-flex justify-content-between ' key={token.coinAddress}>
                                <div className="d-flex align-items-center">
                                <img src={token.coinLogoUrl} alt="" className="me-2 me-sm-4 exploreVaultTableCoinImage" />
                                <h6 className="text-capitalize mb-0">{token.coinName}</h6>
                            </div>
                                <div className="d-flex align-items-center">
                                <h6 className='me-2 me-sm-3  mb-0 generic-popup-p'>{token.requiredCoinQuantity}</h6>
                                <h6 className='grey  mb-0 text-uppercase'>{token.sellToken}</h6>
                            </div>
                     
                             </div>

                             {
                                (props.changedCoins.reducedCoins.length-1> i)?
                                <hr  className='section-border-color' />      
                                :
                                null
                             }   

                                </>
                            )
                        })
                    }
                 
                   </div>
                   </Modal.Body>
                   <Modal.Footer>
                    <>
                    {
                    progressPerc===100?
                    <>
                    <Button variant="secondary"  className='section-button mb-3  modal-button mt-4' onClick={handleCloseToWallet}>
                     Continue
                     </Button>
                     {/* <Button variant="primary" className='modal-close-btn' onClick={handleCloseToWallet}>
                     Go to My Wallet
                     </Button> */}
                     </> 
                    :
                      <div className='prog-bar'>
                        <ProgressBar animated now={progressPerc} label={`${progressPerc}%`}  />
                      </div>
                    }           
                    </>
                     
                   </Modal.Footer>
                 </Modal> 
                 </>    
    )
}