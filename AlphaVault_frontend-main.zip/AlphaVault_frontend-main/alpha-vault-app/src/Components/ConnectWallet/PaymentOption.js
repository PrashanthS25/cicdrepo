import React,{useEffect,useState} from 'react';
import '../../App.css'
import '../ConnectWallet/ConnectWallet.css'
import '../../mobileApp.css';
import { MdArrowBackIosNew } from "react-icons/md";
import {
   NavLink
 } from "react-router-dom";
 import { Link } from "react-router-dom";
 import  moonpay from "../../assets/images/moonpay.svg";
 import  gempay from "../../assets/images/gempay.svg";
import ErrorComponent from '../ErrorComponent'
 

export default function PaymentOption(){

    const [error,setError] = useState(null)

    useEffect(()=>{
        setError('Currently "Payment Options" functionality is inactive.')
    },[])

   return(
      <>
       <section className='section option-connect-wallet'>
         <div className='container'>
         {
             error ?
                <ErrorComponent setError={setError} error={error} />
            :
            null  
         }
            <div className='section-top-heading-naviagte payment-option-navigate mb-4 s-token-mobile-n'>
               <button className='navigate-btn'><NavLink to='/connectWallet'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button> 
               <div className="section-heading">
                    <h3 className="section-title">Payment Options</h3>
               </div>
            </div>
       
         <div className="alphavault-sec-box pt-4 pb-3 px-5 mt-3">
            <div className='row'>
                <div className='col-2 p-0 text-center'>
                    <img src={moonpay} alt="" className='payment-opt-img' />
                </div>
                <div className='col-10'>
                    <Link className='payment-opt-heading' to='/connectWallet'>MoonPay</Link>
                    <p className='payment-opt-heading-2 mb-1'>Debit and Credit Card</p>
                    <p className='grey payment-opt-info mb-1'>Max: 10,000 USD / Day</p>
                    <p className='grey payment-opt-info mb-1'>Settlement: 0-48 hours</p>
                </div>
            </div>
           </div>
           <div className="alphavault-sec-box pt-4 pb-3 px-5 mt-3">
            <div className='row'>
                <div className='col-2 p-0 text-center'>
                    <img src={gempay} alt="" className='gempay-img' />
                </div>
                <div className='col-10'>
                    <Link className='payment-opt-heading' to='/connectWallet'>GEMPAY</Link>
                    <p className='payment-opt-heading-2 mb-1'>Bank, Debit and Credit Card</p>
                    <p className='grey payment-opt-info mb-1'>Max: 20,000 USD / Day</p>
                    <p className='grey payment-opt-info mb-1'>Settlement: 0-48 hours</p>
                </div>
            </div>
           </div>
         </div>
       </section>
      </>
   )
}