import React,{useState,useEffect} from 'react'
import {Modal} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import Emitter from '../../Helper/emitter';
import '../../mobileApp.css';
export default function PermissionModal(props){

    const useEffect =(()=>{
      Emitter.on('test123',(data)=>{
        // console.log.log("shock",data)
      })
    },[])

    return(
        <> 
      <Modal show={props.show} onHide={props.handleClose} 
       size="md"
       centered className='mt-5' >
  <Modal.Header >
    <Modal.Title className='wallet-c-modal-title'>Warning!</Modal.Title>
  </Modal.Header>
  <Modal.Body className='pb-3 wallet-c-body'>
    <div className='text-center  wallet-scroll'>
      <h6 className='wallet-c-modal-h6'>Acknowledgement</h6>
    <p className='wallet-c-modal-p'> You accept that the use of the Alpha Vault Protocol is entirely at your own risk, 
      and that doing so could lead to partial or full loss of deposits.You take full responsibility for your use of the Alpha 
      Vault Protocol, and acknowledge that you use it on the basis of your own enquiry (as defined in the Terms of Use).</p>

      <h6 className='wallet-c-modal-h6'>Citizenship amendment</h6>
    <p className='wallet-c-modal-p'> The Alpha Vault governance is not available for US citizen or national, or if you act for a company 
      that is domiciled in the US or majority owned by US citizens or US companies.The same applies to citizens or companies that 
      are subject to further sanctions, e.g. from the Russian Federation or Belarus.</p> 

    </div>
    {
      // console.log.log("policyConfirmations",props.policyConfirmation1,props.policyConfirmation2)
    }
    <hr className='modal-b-l' />
    <div className="form-check connect-wallet-form-check mb-3 ">
    <input className="form-check-input modal-check" type="checkbox" value="a" id="flexCheckDefault1" checked={props.policyConfirmation1} onClick={(e)=>props.setConfirmations1(e.target.checked)}/>
    <label className="form-check-label  modal-check-labl" for="flexCheckDefault1" >
        You accept that the use of the Stake Alpha Vault Protocol is entirely at your own risk
    </label>
  </div>
  <div className="form-check connect-wallet-form-check ">
    <input className="form-check-input modal-check" type="checkbox" value="a" id="flexCheckChecked" checked={props.policyConfirmation2} onClick={(e)=>props.setConfirmations2(e.target.checked)}/>
    <label className="form-check-label modal-check-labl" for="flexCheckChecked">
        I confirm that i don't fall under any of these exclusion
    </label>
  </div>
  
  </Modal.Body>
  <Modal.Footer>
    {
      // console.log.log("policy90",props.policyConfirmation1&&props.policyConfirmation2)
    }
    <Button variant="secondary" className='section-button mb-3  modal-button' disabled={(props.policyConfirmation1&&props.policyConfirmation2)? false:true} onClick={props.handleConfirm}>
      Enter App
    </Button>
    <Button variant="primary" className='modal-btn' onClick={props.handleClose}>
      Cancel
    </Button>
  </Modal.Footer>
</Modal>
        </>  
    )
}