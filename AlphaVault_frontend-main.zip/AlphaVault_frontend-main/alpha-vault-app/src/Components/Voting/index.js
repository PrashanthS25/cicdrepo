import React, { useState,useEffect } from 'react';
import '../../App.css'
import '../../mobileApp.css';
import '../Voting/Voting.css'
import Modal from 'react-bootstrap/Modal';
import  thank from "../../assets/images/thankyou.svg";
export default function Voting(){

   const [show, setShow] = useState(false);

   const handleClose = () => setShow(false);
   const handleShow = () => setShow(true);

   useEffect(()=>{
      window.scrollTo(0, 0)
   },[]) 

   return(
      <>
      {/* <div className='section voting-section'>
         <section className='voting-sec'>
            <div className='container'>
               <div className="section-heading">
                   <h3 className="section-title mb-4">voting</h3>
               </div>
               <div className="alphavault-sec-box p-4 p-sm-5">
                  <h5 className='voting-title text-center'>Please provide your Feedback/voting</h5>

                  <form action="/" className='voting-form mt-4 mt-sm-5'>
                     <p className='voting-radio-title mb-2'>What new vaults would we include?</p>
                     <div className="form-check mb-2 ms-4">
                       <input className="form-check-input voting-input" type="radio" name="flexRadioDefault5" id="flexRadioDefault1"  />
                       <label className="form-check-label form-voting-label" for="flexRadioDefault1">
                          Metaverse
                       </label>
                     </div>
                     <div className="form-check mb-2 ms-4">
                       <input className="form-check-input voting-input" type="radio" name="flexRadioDefault5" id="flexRadioDefault2" />
                       <label className="form-check-label form-voting-label" for="flexRadioDefault2">
                          NFTs
                       </label>
                     </div>
                     <div className="form-check mb-2 ms-4">
                       <input className="form-check-input voting-input" type="radio" name="flexRadioDefault5" id="flexRadioDefault3" />
                       <label className="form-check-label form-voting-label" for="flexRadioDefault3">
                          Others
                       </label>
                     </div>
      
                     <p className='voting-radio-title mt-4 mb-2'>Should we partner with ABC team</p>
                     <div className="form-check mb-2 ms-4">
                       <input className="form-check-input voting-input" type="radio" name="flexRadioDefault" id="flexRadioDefault4" />
                       <label className="form-check-label form-voting-label" for="flexRadioDefault4">
                          Yes
                       </label>
                     </div>
                     <div className="form-check mb-2 ms-4">
                       <input className="form-check-input voting-input" type="radio" name="flexRadioDefault" id="flexRadioDefault5" />
                       <label className="form-check-label form-voting-label" for="flexRadioDefault5">
                          No
                       </label>
                     </div>
                     <div className="form-check ms-4">
                       <input className="form-check-input voting-input" type="radio" name="flexRadioDefault" id="flexRadioDefault6"/>
                       <label className="form-check-label form-voting-label" for="flexRadioDefault6">
                           Whatever
                       </label>
                     </div>

                     <div className="mb-4 mt-5">
                       <label for="exampleFormControlTextarea1" className="form-label form-voting-label">Tell us your opinion</label>
                       <textarea className="form-control voting-textarea" id="exampleFormControlTextarea1" placeholder='Give as many details as possible…' rows="5"></textarea>
                     </div>
                  </form>

                  <div className='section-btn text-center'>
                   <button type="button" onClick={handleShow} className="btn btn-light section-button">SEND FEEDBACK</button >
                  </div>

                     <Modal show={show} onHide={handleClose} className="voting-popup">
                       <Modal.Header closeButton className='thank-header'>
                       </Modal.Header>

                       <Modal.Body className='thank-body text-center'>
                       <img src={thank} className="thank-img" alt="" />
                       <h2>Thank you!</h2>
                       <p>Lorem Ipsum is simply dummy text of the printing and ypesetting industry.</p> 

                       </Modal.Body>
                     </Modal>
               </div>
            </div>
         </section>
      </div> */}
      </>
   )
}