/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
/* eslint-disable no-undef */
import React, { useEffect } from "react";
import API from "../../utils/Api";
import { useApiContract } from "react-moralis";
import { applyMiddleware } from "redux";
import "../Home/Home.css";
import "../../mobileApp.css";
import "../../App.css";
import axios from "axios";
export default function TradingViewChart({
  graphInterval,
  setChartLoader,
  coinAddress,
  coinChainID,
  coinMarketCapId,
}) {
  // console.log("graphInterval", graphInterval);
  // console.log("coinAddress", coinAddress);
  // console.log("coinChainID", coinChainID);
  // console.log("coinMarketCapId", coinMarketCapId);

  useEffect(() => {
    const chartCall = () => {
      // setChartLoader(true)
      // const log = console.log;

      const chartProperties = {
        width: 650,
        font: { size: 10 },
        height: 400,
        timeScale: {
          timeVisible: true,
          secondsVisible: false,
        },
      };
      let domElement, chart, candleSeries;
      // if(graphInterval === "1m"){
      //   domElement = document.getElementById('tvchart');
      //   chart = LightweightCharts.createChart(domElement,chartProperties);
      //   candleSeries = chart.addLineSeries({ color: '#800080', lineWidth: 2 });
      // }
      // console.log("graphProps",graphInterval,setChartLoader,coinAddress,coinChainID)
      // if(graphInterval === "1h")
      // {
      //   domElement = document.getElementById('tvchart1');
      //   chart = LightweightCharts.createChart(domElement,chartProperties);
      //   candleSeries = chart.addLineSeries({ color: '#800080', lineWidth: 2 });
      // }
      // else{
      //   domElement = document.getElementById('tvchart2');
      //   chart = LightweightCharts.createChart(domElement,chartProperties);
      //   candleSeries = chart.addLineSeries({ color: '#800080', lineWidth: 2 });
      // }

      switch (graphInterval) {
        case "1h":
          domElement = document.getElementById("tvchart1");
          break;
        case "1d":
          domElement = document.getElementById("tvchart2");
          break;
        case "7d":
          domElement = document.getElementById("tvchart3");
          break;
        case "1m":
          domElement = document.getElementById("tvchart4");
          break;
        case "3m":
          domElement = document.getElementById("tvchart5");
          break;
        case "1y":
          domElement = document.getElementById("tvchart6");
          break;
        default:
          domElement = document.getElementById("tvchart1");
          break;
      }
      chart = LightweightCharts.createChart(domElement, chartProperties);
      candleSeries = chart.addLineSeries({ color: "#800080", lineWidth: 2 });

      if (graphInterval !== "1h") { 
        API.get(`/trading-view?id=${coinMarketCapId}&interval=` + graphInterval)
          .then((res) => {
            // console.log("graphRes",res.data.data.chartCoordinates)
            let timeArray = [];
            let value = [];
            res.data.chart.map((item) => {
              timeArray.push(item.x);
              value.push(item.y);
            });

            // return res.data
            // console.log("graphData",timeArray,value)
            const cdata = [];

            timeArray.map((element, index) => {
              // console.log("graphLog2",element,value[index])
              // console.log("graphLog2",(new Date(element.quote.USD.timestamp)).getTime() ,element.quote.USD.volume)
              // cdata.push({time:(element),value:parseFloat(value[index])})
              // if(index<290){
              if (index + 1 <= timeArray.length) {
                if (+timeArray[index] < +timeArray[index + 1]) {
                  // console.log("graphLog2",element,value[index])
                  // console.log("graphLog2",(new Date(element.quote.USD.timestamp)).getTime() ,element.quote.USD.volume)
                  cdata.push({
                    time: element,
                    value: parseFloat(value[index]),
                  });
                }
                // }
              } else {
                if (index === timeArray.length) {
                  if (+timeArray[index - 1] < +timeArray[index]) {
                    // console.log("graphLog2", element, value[index]);
                    // console.log("graphLog2",(new Date(element.quote.USD.timestamp)).getTime() ,element.quote.USD.volume)
                    cdata.push({
                      time: element,
                      value: parseFloat(value[index]),
                    });
                  }
                }
              }
            });
            // console.log("graphData",cdata);
            candleSeries.setData(cdata);
          })
          .catch((err) => {
            console.log(err);
            // setChartLoader(false)
          });
      } else {
        API.post(`/chart`, {
          coinAddress,
          coinChainID,
          timeline: graphInterval,
        })
          .then((res) => {
            // console.log("graphRes",res.data.data.chartCoordinates)
            let timeArray = [];
            let value = [];

            res.data.data.chartCoordinates.map((item) => {
              timeArray.push(item.x);
              value.push(item.y);
            });
            timeArray = timeArray.slice(Math.max(timeArray.length - 120, 1));
            value = value.slice(Math.max(value.length - 120, 1));

            // return res.data
            // console.log("graphData", timeArray, value, timeArray.length);
            const cdata = [];

            timeArray.map((element, index) => {
              // console.log("graphLog2",element,value[index])
              // console.log("graphLog2",(new Date(element.quote.USD.timestamp)).getTime() ,element.quote.USD.volume)
              // cdata.push({time:(element),value:parseFloat(value[index])})
              // if(index<290){
              if (index < 200) {
                if (index + 1 <= timeArray.length) {
                  if (+timeArray[index] < +timeArray[index + 1]) {
                    // console.log("graphLog2", element, value[index]);
                    // console.log("graphLog2",(new Date(element.quote.USD.timestamp)).getTime() ,element.quote.USD.volume)
                    cdata.push({
                      time: element,
                      value: parseFloat(value[index]),
                    });
                  }
                } else {
                  if (index === timeArray.length) {
                    if (+timeArray[index - 1] < +timeArray[index]) {
                      // console.log("graphLog2", element, value[index]);
                      // console.log("graphLog2",(new Date(element.quote.USD.timestamp)).getTime() ,element.quote.USD.volume)
                      cdata.push({
                        time: element,
                        value: parseFloat(value[index]),
                      });
                    }
                  }
                }
              }
            });
            // console.log("graphData", cdata);
            candleSeries.setData(cdata);
          })
          .catch((err) => {
            console.log(err);
            // setChartLoader(false)
          });
      }
    };
    chartCall();
  }, [graphInterval]);

  return (
    <>
      <div className="alphavault-graph">
        {graphInterval === "1h" && <div id="tvchart1"></div>}

        {graphInterval === "1d" && <div id="tvchart2"></div>}

        {graphInterval === "7d" && <div id="tvchart3"></div>}

        {graphInterval === "1m" && <div id="tvchart4"></div>}

        {graphInterval === "3m" && <div id="tvchart5"></div>}

        {graphInterval === "1y" && <div id="tvchart6"></div>}
      </div>
    </>
  );
}
