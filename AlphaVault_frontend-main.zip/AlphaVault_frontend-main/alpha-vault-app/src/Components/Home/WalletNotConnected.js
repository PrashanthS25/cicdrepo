/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React from 'react'
import { NavLink } from "react-router-dom";
import  wnc from "../../assets/images/wallet-not-connected.png";
import '../Home/Home.css'
import '../../App.css'
import '../../mobileApp.css';
export default function WalletNotConnected(){
   return(
      <>
      <div className='wallet-not-connected-section alphavault-sec-box py-5'>
         <div className='wallet-not-connected text-center'>
             <img src={wnc} alt="" />
             <h3>Wallet Not Connected!</h3>
             <p>Connect your wallet to start</p>
             <p>creating your vault and much more!</p>
         </div>
      </div>
      <div className="home-btn text-center mt-4">
      <NavLink  to='/connectWallet'><button type="button" className="btn btn-light btn-sm section1-button">connect</button></NavLink>
      </div>
      </>  
   )     
}

