/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useEffect,useState} from 'react'
import './Home.css'
import '../../App.css'
import '../../mobileApp.css';
import  eth from "../../assets/images/ethereum.svg";
import  compoundeth from "../../assets/images/compoundeth.png";
import  tether from "../../assets/images/tether.svg";
import  usd from "../../assets/images/usd.svg";
import  chainlink from "../../assets/images/chainlink.svg";
import {connect} from 'react-redux'
import Table from 'react-bootstrap/Table';
import {initWallet} from '../../redux/index'
import {findToken} from '../../Helper/helperFunctions'
import Emitter from '../../service/Emitter';

function MyWalletTokens(props){

  const [updatedTokenList,setUpdatedTokenList] = useState(null)
  useEffect(()=>{
    // console.log("props",props)
    Emitter.on('newTokenAdded',(t)=>setUpdatedTokenList(t.newTempTokenList))
  },[])

   return(
      <>
      <div className="mywallet-mid-section">
      <div  className='container'>
      {
          props.serverResponse?
          props.serverResponse.assetList.length ?
            <div className='alphavault-sec-box py-4'>  
              {
              props.serverResponse?  
                  props.homeMode?
                  props.serverResponse.assetList.map((e,i)=>{
                  if(i< 4){
                    return(
                      <>
                      <div className="mywallet-mid-section-box" key={i}>
                        <div className="mywallet-mid-left">
                          <img src={e.coinLogo} alt="" className="me-3 exploreVaultTableImage" />
                          <div className="mywallet-text">
                            <h6 className="mywallet-name  text-capitalize">{e.coinName}</h6>
                        
                            {
                            props.serverResponse?   
                                <h6 className="mywallet-percent mb-0">${e.coinPrice}</h6>
                            :
                            <></> 
                            }
                          </div>
                        </div>
                        <div className="mywallet-mid-right">
                          <h5 className="me-3 mywallet-q">{(+e.coinQuantity).toFixed(8)}</h5>
                          <h5 className="walletshortname">({e.coinSymbol})</h5>
                        </div>
                      </div>
                      {
                        i<3?
                      <hr className='section-border-color' /> 
                       :
                       <></> 
                      }
                      </> 
                    ) 
                  }  
                               
                  })
                  :
                  props.serverResponse.assetList.map((e,i)=>{
                    return(
                      <>
                      <div className="mywallet-mid-section-box" key={i}>
                        <div className="mywallet-mid-left">
                          <img src={e.coinLogo} alt="" className="me-3 exploreVaultTableImage" />
                          <div className="mywallet-text">
                            <h6 className="mywallet-name  text-capitalize">{e.coinName}</h6>
                        
                            {
                            props.serverResponse?   
                                <h6 className="mywallet-percent mb-0">${e.coinPrice}</h6>
                            :
                            <></> 
                            }
                          </div>
                        </div>
                        <div className="mywallet-mid-right position-relative">
                          <h5 className="position-absolute wallet-new-amount mywallet-q">{(+e.coinQuantity).toFixed(5)}</h5>
                          <h5 className="walletshortname">({e.coinSymbol})</h5>
                        </div>
                      </div>
                      <hr className='section-border-color' /> 
                      </> 
                    )              
                    })
              :
              null
          }
            </div>
            :<></>
        :
        <></>    
      }
      </div>
      </div>         
      </>  
   )     
}

const mapStateToProps =(state)=>{
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error
  }
}

const mapStateToDispatch = (dispatch)=>{
  return{
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)) 
  }
}

export default connect(mapStateToProps,mapStateToDispatch)(MyWalletTokens)