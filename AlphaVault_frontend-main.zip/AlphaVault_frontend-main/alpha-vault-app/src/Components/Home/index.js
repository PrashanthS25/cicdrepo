/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
/* eslint-disable no-undef */
import React, { useState, useEffect } from "react";
import WalletNotConnected from "./WalletNotConnected";
import HomeWalletInfo from "../../MobileComponents/HomeWalletInfo";
import { connect } from "react-redux";
import "react-pro-sidebar/dist/css/styles.css";
import "../../App.css";
import "../../Components/Home/Home.css";
import "../../mobileApp.css";
import Loader from "../Loader";
import { Link, useNavigate, NavLink } from "react-router-dom";
import { initWallet, fetchWalletResponse } from "../../redux/index";
import Spinner from "react-bootstrap/Spinner";
import chainlink from "../../assets/images/chainlink.svg";
import { formatValue } from "../../Helper/helperFunctions";
import eth1 from "../../assets/images/ethereum1.svg";
import tether from "../../assets/images/tether.svg";
import usd from "../../assets/images/usd.svg";
import action1 from "../../assets/images/action1.svg";
import action2 from "../../assets/images/action2.svg";
import action3 from "../../assets/images/action3.svg";
import MyWalletTokens from "./MyWalletTokens";
import TradingViewChart from "./TradingViewChart";
import ErrorComponent from "../ErrorComponent";
import { fetchCoins } from "../../redux/index";
import Emitter from "../../Helper/emitter";
import { getTimeChangeFilterValue } from "../../Helper/helperFunctions";
import API from "../../utils/Api";

const Home = (props) => {
  const [error, setError] = useState(null);
  const [chartLoader, setChartLoader] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [filterOption, setFilterOption] = useState(1);
  const [sampleVaultList, setSampleVaultList] = useState(1);
  let navigate = useNavigate();

  const [coinList, setCoinList] = useState(null);
  const [total, setTotal] = useState(0);

  // console.log("coin list", coinList)

  const [graphInterval, setGraphInterval] = useState("1h");

  useEffect(() => {
    setLoading(true);
    window.scrollTo(0, 0);
    const getCoinList = async () => {
      await props.fetchCoins();
    };
    getCoinList();

    setLoading(true);
    Emitter.on("setLoading", (data) => {
      // console.log("hereFit123", data.isLoading);
      setLoading(data.isLoading);
    });

    Emitter.on("setMobileLoading", (data) => {
      // console.log("hereFit123", data.isLoading);
      setLoading(data.isLoading);
    });

    let requiredChainId;
    if (props.chain?.networkId && props.isWalletConnected) {
      requiredChainId = props?.chain?.networkId;
    } else {
      requiredChainId = 1;
    }
    getVaultCoinLIst(requiredChainId);
    if (props?.chain?.networkId) {
      getSupportedCoinList();
    }
    // Emitter.on("setLoading", (data) => {
    //   // console.log("hereFit123", data.isLoading);
    //   setLoading(data.isLoading);
    // });
    setLoading(false);
  }, [props?.chain?.networkId, props.serverResponse?.totalBal]);

  const getVaultCoinLIst = async (requiredChainId) => {
    try {
      // console.log("getVaultCoinLIst");
      let vaultListReq = {
        count: 3,
        type: "list",
        search_query: null,
      };
      let _vaultData = await API.post(
        "/vault/list?coinChainID=" + requiredChainId,
        vaultListReq
      );
      // console.log("vaultListData", _vaultData.data);
      setSampleVaultList(_vaultData.data);
    } catch (error) {
      setSampleVaultList([]);
      console.log("error", error);
      setLoading(false);
    }
  };

  const getSupportedCoinList = async () => {
    let coinresponse = await API.get(
      "/coin/list?coinChainID=" + props?.chain?.networkId + "&page=1"
    );
    // console.log("coinList:**", coinresponse.data.data);
    setCoinList(coinresponse.data.data);
    setTotal(coinresponse.data.count);
    // console.log("COUNT!!!!!!=-----", coinresponse.data.count);
  };

  const navigateToCoin = (coinAddress) => {
    navigate("/coinpage?coinAddress=" + coinAddress);
  };

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const returnChartCss = (interval) => {
    if (graphInterval === interval) {
      return "btn btn-primary section-g-button1 active";
    } else {
      return "btn btn-primary section-g-button1";
    }
  };

  const sendFilterClass = (currValue) => {
    return currValue === filterOption
      ? "btn btn-primary vault-btn active"
      : "btn btn-primary vault-btn";
  };

  const navigateToVaultPage = (vaultAddress) => {
    navigate("/vaultDetail?vault=" + vaultAddress);
  };

  return (
    <>
      {/* {console.log("props123", props, props.loader)} */}
      {props.coinLoader || isLoading ? (
        <Loader />
      ) : (
        <section className="section homepage-sec">
          {props.error || error ? (
            <ErrorComponent
              setError={setError}
              error={error ? error : props.error}
            />
          ) : null}
          <div className="container">
            <div className="homepage-wrp">
              <HomeWalletInfo networkId={props.chain?.networkId}/>
              <div className="section-heading">
                <h3 className="section-title mb-4 mobile-v-hide">
                  Alpha Vault
                </h3>
              </div>
              {/* alphavualt section */}
              {props.isWalletConnected && props.serverResponse ? (
                <div className="alphavault-section alphavault-sec-box text-center pt-4 pb-4 pb-sm-5">
                  <h6 className="alphavault-box-title mb-3">Total Holdings</h6>
                  <h3 className="alphavault-price mb-1 mb-sm-3">
                    $
                    {props.serverResponse
                      ? props.serverResponse.grandtotalWalletBal.toFixed(3)
                      : 0}
                  </h3>
                  <h6 className="alphavault-percent green">
                    +$560 &nbsp;+2.36%
                  </h6>
                  <div className="text-center">
                    <div className="btn-group alpha-vaults-deatails-wrp mt-3 mb-4 mb-sm-5">
                      <Link
                        to="/"
                        className={returnChartCss("1h")}
                        onClick={() => setGraphInterval("1h")}
                      >
                        1H
                      </Link>
                      <Link
                        to="/"
                        className={returnChartCss("1d")}
                        onClick={() => setGraphInterval("1d")}
                      >
                        1D
                      </Link>
                      <Link
                        to="/"
                        className={returnChartCss("1m")}
                        // aria-current="page"
                        onClick={() => setGraphInterval("1m")}
                      >
                        1M
                      </Link>
                    </div>
                  </div>
                  {/* <div className="btn-group" role="grou p" aria-label="Basic example">
                <button type="button" className="btn btn-secondary" onClick={()=>setGraphInterval('1m')}>Min.</button>
                <button type="button" className="btn btn-secondary" onClick={()=>setGraphInterval('1h')}>Hour</button>
                <button type="button" className="btn btn-secondary">Day</button>
              </div> */}
                  {!chartLoader && props.chain?.networkId ? (
                    <TradingViewChart
                      graphInterval={graphInterval}
                      setChartLoader={setChartLoader}
                      coinAddress={"Ethereum"}
                      coinChainID={1}
                      coinMarketCapId={1}
                    />
                  ) : (
                    <Spinner animation="border" />
                  )}
                </div>
              ) : (
                <></>
              )}

              {/* alphavualt section end */}

              {/* <ComingSoon/> */}

              {/* action section */}
              <div className="home-sections-box mb-4 mb-sm-0">
                <h5 className="alphavault-sub-title mb-4 mobile-v-hide">
                  actions
                </h5>
                <div className="action-box  alphavault-sec-box  px-sm-5 px-4 pb-4 pb-sm-5">
                  <div className="action-box-wrp">
                    <div className="action-content-box">
                      <NavLink to="/vaults">
                        <div className="action-icons">
                          <img src={action1} alt="" />
                          {/* <FiActivity className="action-icons-c" /> */}
                        </div>
                      </NavLink>
                      <div className="action-icon-title">
                        <NavLink to="/vaults">
                          <h6>Explore Vaults</h6>
                        </NavLink>
                      </div>
                    </div>
                    <div className="action-content-box">
                      <NavLink to="/connectWallet">
                        <div className="action-icons">
                          <img src={action2} alt="" />
                          {/* <IoWallet className="action-icons-c"/> */}
                        </div>
                      </NavLink>
                      <div className="action-icon-title">
                        <NavLink to="/connectWallet">
                          <h6>My Wallet</h6>
                        </NavLink>
                      </div>
                    </div>
                    <div className="action-content-box">
                      <NavLink to="/staking">
                        <div className="action-icons">
                          <img src={action3} alt="" />
                          {/* <BsGraphUp className="action-icons-c"/> */}
                        </div>
                      </NavLink>
                      <div className="action-icon-title">
                        <NavLink to="/staking">
                          <h6>Stake Tokens</h6>
                        </NavLink>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* action section end*/}

              {/* vaults */}
              <div className="home-sections-box">
                <div className="vaults-top-section">
                  <h5 className="alphavault-sub-title mb-0">vaults</h5>
                  <div className="btn-group align-items-center">
                    <a
                      className={sendFilterClass(0)}
                      onClick={() => setFilterOption(0)}
                      aria-current="page"
                    >
                      1hr
                    </a>
                    <a
                      className={sendFilterClass(1)}
                      onClick={() => setFilterOption(1)}
                    >
                      1D
                    </a>
                    <a
                      className={sendFilterClass(2)}
                      onClick={() => setFilterOption(2)}
                    >
                      1W
                    </a>
                    <a
                      className={sendFilterClass(3)}
                      onClick={() => setFilterOption(3)}
                    >
                      1M
                    </a>
                    <a
                      className={sendFilterClass(4)}
                      onClick={() => setFilterOption(4)}
                    >
                      2M
                    </a>
                    <a
                      className={sendFilterClass(5)}
                      onClick={() => setFilterOption(5)}
                    >
                      3M
                    </a>
                  </div>
                </div>
                {sampleVaultList.length ? (
                  <div className="vault-mid-section alphavault-sec-box py-4 home-vault-box-mobile">
                    {sampleVaultList.map((vault) => {
                      return (
                        <>
                          <div
                            key={vault.vaultAddress}
                            className="vault-mid-section-box"
                          >
                            <div className="vault-mid-left">
                              <img
                                src={vault.vaultDetails.coinLogoUrl}
                                alt=""
                                className="me-3  exploreVaultTableImage"
                              />
                              <div className="vault-text">
                                <button
                                  className="select-token-d-btn d-flex custom-vault-text"
                                  onClick={() =>
                                    navigateToVaultPage(vault.vaultAddress)
                                  }
                                >
                                  <h6 className="vault-name  v-tbl-text text-capitalize">
                                    {vault.vaultName}&nbsp;
                                    <span>({vault.vaultSymbol})</span>
                                  </h6>
                                </button>
                                <h6 className="vault-percent mb-0">
                                  ${vault.vaultDetails.coinPrice.toFixed(2)}{" "}
                                  &nbsp;
                                  <span
                                    className={
                                      getTimeChangeFilterValue(
                                        vault.vaultDetails,
                                        filterOption
                                      ) > 0
                                        ? "vault-percnt-spn green"
                                        : "vault-percnt-spn red"
                                    }
                                  >
                                    {getTimeChangeFilterValue(
                                      vault.vaultDetails,
                                      filterOption
                                    )}
                                    %
                                  </span>
                                </h6>
                              </div>
                            </div>
                            <div className="vault-mid-right">
                              {vault.vaultCoins.map((vaultCoin, index) => {
                                if (index < 3) {
                                  return (
                                    <img
                                      src={vaultCoin.coinLogoUrl}
                                      className="me-2 vaultimage-mobile"
                                      alt=""
                                      key={vaultCoin.coinLogoUrl}
                                    />
                                  );
                                } else {
                                  return;
                                }
                              })}
                              <p>+10</p>
                            </div>
                          </div>
                          <hr className="section-border-color" />
                        </>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-center mt-3">
                    No vaults available for current network.
                  </p>
                )}
                <div className="home-btn text-center mt-4">
                  <NavLink to="/vaults">
                    {" "}
                    <button
                      type="button"
                      className="btn btn-light btn-sm section1-button"
                    >
                      view all
                    </button>
                  </NavLink>
                </div>
              </div>

              {/* vaults end*/}

              {/* mywallet */}

              <div className="home-sections-box">
                <div className="mywallet-top-section">
                  <h5 className="alphavault-sub-title">my wallet</h5>
                  {props.isWalletConnected ? (
                    <h5 className="mywallet-balance">
                      Balance:{" "}
                      <span>
                        ∼ $
                        {props.serverResponse
                          ? props.serverResponse.totalBal.toFixed(3)
                          : 0}{" "}
                      </span>{" "}
                    </h5>
                  ) : (
                    <h5 className="mywallet-balance">Balance: - </h5>
                  )}
                </div>
                {props.isWalletConnected ? (
                  <>
                    {props.serverResponse?.assetList?.length ? (
                      <MyWalletTokens homeMode={true} />
                    ) : (
                      <p className="text-center m-2">
                        No coins due to low balance of assets or unavailabilty
                        of assets in wallet.
                      </p>
                    )}
                    <div className="home-btn text-center mt-4">
                      <NavLink to="/connectWallet">
                        {" "}
                        <button
                          type="button"
                          className="btn btn-light btn-sm section1-button"
                        >
                          view all
                        </button>
                      </NavLink>
                    </div>
                  </>
                ) : (
                  <WalletNotConnected />
                )}
              </div>
              {/* mywallet end */}

              {/* staked tokens */}

              <div className="home-sections-box">
                <div className="staked-tokens-top-section">
                  <h5 className="alphavault-sub-title">Staked Tokens</h5>
                  {props.isWalletConnected ? (
                    <h5 className="staked-tokens-balance">
                      Staked:{" "}
                      <span>
                        {" "}
                        $
                        {props.serverResponse
                          ? props.serverResponse.totalBal.toFixed(3)
                          : 0}
                      </span>{" "}
                    </h5>
                  ) : (
                    <h5 className="mywallet-balance">Staked: - </h5>
                  )}
                </div>
                {props.isWalletConnected ? (
                  <>
                    <div className="staked-tokens-mid-section alphavault-sec-box  py-3 py-sm-4 alphavault-sec-box-mobile">
                      <div className="staked-tokens-mid-section-box">
                        <div className="staked-tokens-mid-left">
                          <img
                            src={eth1}
                            alt=""
                            className="me-3 mobile-v-hp-image"
                          />
                          <h6 className="staked-tokens-name  text-capitalize me-3">
                            Ethereum
                          </h6>
                          <h6 className="staked-tokens-shortname">(ETH)</h6>
                        </div>
                        <div className="staked-tokens-mid-right">
                          <h5 className="staked-tokens-amntt">1.4034</h5>
                          <h5 className="staked-days">29 days</h5>
                        </div>
                      </div>

                      <hr className="section-border-color home-st-hr" />

                      <div className="staked-tokens-mid-section-box">
                        <div className="staked-tokens-mid-left">
                          <img
                            src={tether}
                            alt=""
                            className="me-3 mobile-v-hp-image"
                          />
                          <h6 className="staked-tokens-name  text-capitalize me-3">
                            Tether
                          </h6>
                          <h6 className="staked-tokens-shortname">(USDT)</h6>
                        </div>
                        <div className="staked-tokens-mid-right">
                          <h5 className="staked-tokens-amntt">340.33</h5>
                          <h5 className="staked-days">120 days</h5>
                        </div>
                      </div>
                      <hr className="section-border-color home-st-hr" />

                      <div className="staked-tokens-mid-section-box">
                        <div className="staked-tokens-mid-left">
                          <img
                            src={usd}
                            alt=""
                            className="me-3 mobile-v-hp-image"
                          />
                          <h6 className="staked-tokens-name  text-capitalize me-3">
                            USD Coin
                          </h6>
                          <h6 className="staked-tokens-shortname">(USDC)</h6>
                        </div>
                        <div className="staked-tokens-mid-right">
                          <h5 className="staked-tokens-amntt">560.86</h5>
                          <h5 className="staked-days">12 days</h5>
                        </div>
                      </div>
                      <hr className="section-border-color home-st-hr" />

                      <div className="staked-tokens-mid-section-box">
                        <div className="staked-tokens-mid-left">
                          <img
                            src={chainlink}
                            alt=""
                            className="me-3 mobile-v-hp-image"
                          />
                          <h6 className="staked-tokens-name  text-capitalize me-3">
                            Chainlink
                          </h6>
                          <h6 className="staked-tokens-shortname">(LINK)</h6>
                        </div>
                        <div className="staked-tokens-mid-right">
                          <h5 className="staked-tokens-amntt">560.12</h5>
                          <h5 className="staked-days">300 days</h5>
                        </div>
                      </div>
                    </div>
                    <div className="home-btn text-center mt-4">
                      <button
                        type="button"
                        className="btn btn-light btn-sm section1-button"
                      >
                        view all
                      </button>
                    </div>
                  </>
                ) : (
                  <WalletNotConnected />
                )}
              </div>

              {/* staked tokens end */}

              {/* supported tokens */}
              <div className="supported-tokens-top-section">
                <h5 className="alphavault-sub-title mb-0 mb-sm-2">
                  supported Tokens
                </h5>
                <h5 className="supported-balance  mb-0 mb-sm-2">
                  Total:{" "}
                  <span>
                    {total && props.isWalletConnected ? `${total} Tokens` : "-"}
                  </span>
                </h5>
              </div>
              {coinList && props.isWalletConnected && props.chain.networkId ? (
                <div className="home-sections-box custom-home-sections-box">
                  <div className="supported-tokens-details mt-1">
                    {coinList.map((coin) => {
                      return (
                        <div
                          className="supported-tokens-box"
                          key={coin.coinAddress}
                        >
                          <div className="supported-tokens-box-left">
                            <img
                              src={coin.coinLogoUrl}
                              alt=""
                              className="me-3 exploreVaultTableImage"
                            />
                            <div className="supported-tokens-box-text">
                              <button
                                className="select-token-d-btn d-flex text-capitalize"
                                onClick={() => navigateToCoin(coin.coinAddress)}
                              >
                                {coin.coinName}
                              </button>
                              <h6 className="mb-0 grey text-uppercase supported-t-sn">
                                {coin.coinSymbol}
                              </h6>
                            </div>
                          </div>
                          <div className="supported-tokens-box-right">
                            <h5 className="font-styl supported-t-dollar">
                              {formatValue(coin.coinPrice, 2).toLocaleString()}
                            </h5>
                            <h6
                              className={
                                parseFloat(coin.percent_change_1h) >= 0
                                  ? "mb-0 green supported-t-prcnt"
                                  : "mb-0 red supported-t-prcnt"
                              }
                            >
                              {formatValue(
                                coin.percent_change_1h,
                                4
                              ).toLocaleString()}
                              %
                            </h6>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="home-btn text-center mt-4">
                    <NavLink to="/supportedcoins">
                      {" "}
                      <button
                        type="button"
                        className="btn btn-light btn-sm section1-button"
                      >
                        view all
                      </button>
                    </NavLink>
                  </div>
                </div>
              ) : (
                <WalletNotConnected />
              )}

              {/* supported tokens end */}
            </div>
          </div>
        </section>
      )}
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
    fetchCoins: () => dispatch(fetchCoins()),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(Home);
