/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import "../../App.css";
import "../BuySellVaults/BuySellVaults.css";
import "../../mobileApp.css";
import { connect } from "react-redux";
import Emitter from "../../Helper/emitter";
import Loader from "../Loader";
import { MdArrowBackIosNew } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import { initWallet, fetchWalletResponse,fetchCoins } from "../../redux/index";
import { formatValue } from "../../Helper/helperFunctions";
import API from "../../utils/Api";
import ErrorComponent from '../ErrorComponent'
import BuySellSelectTokenMobile from "../../MobileComponents/BuySellSelectTokenMobile";

function SelectToken(props) {

  const [coinAssetListData, setCoinAssetListData] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const [selectionMode, setSelectionMode] = useState(null);
  const [error,setError] = useState(null)
  const [isLoading1, setLoading1] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams("buy");
  const [searchMode, setSearchMode] = useState(false);
  const [assetList, setAssetList] = useState(null);

  useEffect(() => {
    // console.log("teting123",props?.chainId)
    Emitter.on("setLoading", (data) => {
      // console.log("hereFit123", data.isLoading);
      setLoading(data.isLoading);
    });
    setSelectionMode(props.txType);
    setLoading(true);
    // console.log("insideSelectToken", props.txType,props.serverResponse);
    if (props.txType === "buy") {
      setAssetList(props.serverResponse?.assetList);
    } else {
      getCoinList();
    }

    setLoading(false);
    // console.log("txMode", props.txType, props);
    setSelectionMode(props.txType);
    // console.log("here81")
    if(!props.isWalletConnected){
 
      // console.log("buySell451")
      setError('NoWalletConnection')
    }
  }, [props.chain?.networkId,props.serverResponse?.totalBal]);

  const getCoinList = async () => {
    try {
      let coinList = await API.get('/coin/list?coinChainID='+ props.chain.networkId+'&count=70&page=1');
      console.log("coinList", coinList);
      setAssetList(coinList.data.data);
      setCoinAssetListData(coinList.data.data);
    } catch (error) {
      setLoading(false);
      setError(error.message)
      // console.log("error", error);
    }
  };

  const tokenSelection = (requiredToken) => {
    console.log("tokenSelection1", requiredToken);
    if (selectionMode === "buy") {
      props.setRequiredCoinToSell(requiredToken);
    } else {
      // console.log("tokenSelection2", requiredToken);
      props.setRequiredCoinToBuy(requiredToken);
    }
    props.setModeType("default");
  };

  const searchToken = async (searchString, mode) => {
    if (mode === "buy") {
      // console.log("searchString", searchString);

      let resultarray = [];

      if (searchString.length == 0) {
        setAssetList(props.serverResponse.assetList);
        return;
      }

      for (let i = 0; i < props.serverResponse.assetList.length; i++) {
        if (
          props.serverResponse.assetList[i].coinName
            .toLowerCase()
            .startsWith(searchString.toLowerCase())
        ) {
          resultarray.push(props.serverResponse.assetList[i]);
        }
      }
      console.log("resultarray", resultarray);
      setAssetList(resultarray);
    } else {
      console.log("searchString", searchString);

      if (searchString.length == 0) {
        setAssetList(coinAssetListData);
        return;
      }

      setLoading1(true);
      let searchCoinList = await API.post(
        "/coin/string_filter?coinChainID=" + props.chain.networkId,
        { filter_string: searchString }
      );
      console.log("searchCoinList", searchCoinList);
      setAssetList(searchCoinList.data.data);
      setLoading1(false);
    }
  };

  return (
    <>
      {console.log("assetList", assetList)}
      {
      props.error || error ?
        <ErrorComponent setError={setError} error={error?error:props.error} />
        :
      null  
      }
      {isLoading ? (
        <Loader />
      ) : (
        <section className="section select-token-sec">
          <div className="container">
            <div className="section-top-heading-naviagte s-token-mobile-n">
              <button className="navigate-btn">
                {/* <NavLink to="/buysellvaults"> */}
                <MdArrowBackIosNew
                  onClick={() => props.setModeType("default")}
                  className="naviagte-arrow-icon"
                />
                {/* </NavLink> */}
              </button>
              <div className="section-heading">
                <h3 className="section-title-token">Select a token</h3>
              </div>
            </div>
            <div className="alphavault-sec-box select-token-p-box">
              <div className="seacrhcoin-box">
                <form className="select-token-search-box">
                  <IoSearchOutline className="select-token-search-alpha" />
                  <input
                    className="form-control select-token-seach-plchldr"
                    type="search"
                    placeholder="Search by name"
                    aria-label="Search"
                    onChange={(e) => searchToken(e.target.value, selectionMode)}
                  />
                </form>
                {/* <p className="mt-5  mb-0">
                You can only Buy using ETH, USDT & USDC
              </p> */}
              </div>
              <hr className="section-border-color select-token-border" />

              <div className="select-token-details s-t-padding">
                {isLoading1 ? (
                  <p className="text-center">Loading...</p>
                ) : assetList ? (
                  assetList.length ? (
                    assetList.map((asset, index) => {
                      return (
                        
                        <div
                          key={index}
                          className="select-token-details-box mb-4 curserptr"
                          onClick={() => tokenSelection(asset)}
                        >
                          <div className="select-token-details-box-left">
                            {/* <img src={data.imgSRC} alt="" className="me-4" /> */}
                            <img
                              src={asset.coinLogoUrl?asset.coinLogoUrl:asset.coinLogo}
                              alt=""
                              className="me-3 mobile-v-hp-image exploreVaultTableImage"
                            />
                            <div className="select-token-text">
                              <h6
                                className="text-capitalize"
                                
                              >
                                {asset.coinName}
                              </h6>
                              <h6 className="mb-0 grey text-uppercase">
                                {asset.coinSymbol}
                              </h6>
                            </div>
                          </div>
                          {asset.coinQuantity ? (
                            <div className="select-token-details-box-right">
                              <h5>{formatValue(asset.coinQuantity, 5)}</h5>
                              <h6 className="mb-0 grey">
                                ${formatValue(asset.coinValue, 2)}
                              </h6>
                            </div>
                          ) : (
                            <div className="select-token-details-box-right">
                              <h5>${formatValue(asset.coinPrice, 2)}</h5>
                              {/* <h6 className="mb-0 grey">${formatValue(asset.coinValue,2)}</h6> */}
                            </div>
                          )}
                        </div>
                     
                      );
                    })
                  ) : (
                    <p>
                      Token is not present in wallet or due to low balance of
                      token ,Token is Unavailable.{" "}
                    </p>
                  )
                ) : null}
              </div>
            </div>
          </div>
        </section>
        
      )}
      {/* <BuySellSelectTokenMobile  requiredCoinToSell={props.requiredCoinToSell} setRequiredCoinToSell={props.setRequiredCoinToSell}/> */}
    </>
    
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
    fetchCoins: () => dispatch(fetchCoins()),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(SelectToken);
