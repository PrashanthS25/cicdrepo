/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useEffect,useState} from "react";
import "../../App.css";
import "../BuySellVaults/BuySellVaults.css";
import "../../mobileApp.css";
import { MdArrowBackIosNew } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import Loader from '../Loader';
import API from '../../utils/Api'
import { initWallet, fetchWalletResponse,fetchCoins } from "../../redux/index";
import ErrorComponent from '../ErrorComponent'
import Emitter from "../../Helper/emitter";


function SelectVault(props) {
  const [vaultList,setVaultList] = useState([])
  const [vaultListData,setVaultListData] = useState([])
  const [selectionMode,setSelectionMode] = useState(null)
  const [isLoading,setLoading] = useState(false)
  const [isLoading1,setLoading1] = useState(false)
  const [error,setError] = useState(null)


  useEffect(()=>{
    setSelectionMode(props.txType)
    Emitter.on("setLoading", (data) => {
      setLoading(data.isLoading);
    });

    console.log("insideVault",props.txType)
    if(props.txType==='buy'){
      setLoading(true)
      getVaultList()
    }
    else{
      setVaultList(props.serverResponse?.vaults)      
    }
    if(!props.isWalletConnected){
      console.log("buySell451")
      setError('NoWalletConnection')
    }
  },[props.chain?.networkId,props.serverResponse?.totalBal])

  const vaultSelection = (requiredVault) =>{
    if(selectionMode==='buy'){
        props.setRequiredVaultToBuy(requiredVault)   
    }
    else{
      console.log("vault1Check",requiredVault)
      props.setRequiredVaultToSell(requiredVault)
    } 
    props.setModeType('default') 
  }

  const getVaultList = async() =>{
  try{
    let reqObj = {
      "count":20,
      "type":"buy/sell",
      "search_query":null
  }
  let vaultList = await API.post('/vault/list?coinChainID='+props.chain.networkId,reqObj)
  console.log("vaultList",vaultList)
  setVaultList(vaultList.data)
  setVaultListData(vaultList.data)
  setLoading(false)
  }
  catch(error){
  setLoading(false)  
  console.log("error",error)
  }
  }

  const searchVault = async(searchString,mode) =>{
    if(mode === 'buy'){
    console.log("searchString",searchString)

    if(searchString.length == 0){
      setVaultList(vaultListData);
      return;
    }
    

    setLoading1(true)
    let reqObj ={
        "count":5,
        "type":"buy/sell",
        "search_query":searchString
    }  
    await API.post('/vault/list',reqObj)
    let searchVaultList = await API.post('/vault/list',reqObj)
    console.log("vaultList",searchVaultList)
    setVaultList(searchVaultList.data)
    setLoading1(false)
    }  
    else{
      console.log("searchString",searchString)

    let resultarray = [];

    if(searchString.length == 0){
      setVaultList(props.serverResponse.vaults);
      return;
    }
    

    for(let i=0; i<props.serverResponse.vaults.length; i++){
      if(props.serverResponse.vaults[i].coinName.toLowerCase().startsWith(searchString.toLowerCase())){
        resultarray.push(props.serverResponse.vaults[i])
      }
    }
    console.log("resultarray",resultarray)
    setVaultList(resultarray);
    }
  }

  return (
    <>
    {
      props.error || error ?
        <ErrorComponent setError={setError} error={error?error:props.error} />
        :
      null  
      }
    {
    isLoading?
    <Loader/>
    :
      <section className=" section buy-sell-select-vault">
        <div className="container">
          <div className="section-top-heading-naviagte s-token-mobile-n">
            <button className="navigate-btn">
              {" "}
              <NavLink to="/buysellvaults">
                <MdArrowBackIosNew onClick={()=>props.setModeType('default')} className="naviagte-arrow-icon" />
              </NavLink>
            </button>
            <div className="section-heading">
              <h3 className="section-title-token">Select a vault</h3>
            </div>
          </div>
          <div className="alphavault-sec-box select-token-p-box">
            <div className="seacrhcoin-box">
              <form className="select-token-search-box">
                <IoSearchOutline className="select-token-search-alpha" />
                <input
                  className="form-control select-token-seach-plchldr"
                  type="search"
                  placeholder="Search by name"
                  aria-label="Search"
                  onChange={(e)=>searchVault(e.target.value,selectionMode)}
                />
              </form>
            </div>
            <hr className="section-border-color select-token-border" />
            <div className="select-vault-details s-t-padding">
              {
              isLoading1? 
              <p className="text-center">Loading...</p>
              : 
               vaultList.length?
               vaultList.map((vault,index)=>{ 
                return(
                     <div className="curserptr d-flex justify-content-between mb-4" key={index}  onClick={()=>vaultSelection(vault)}>
                      {/* {
                    console.log("vault",vault,vault.vaultDetails?.coinLogoUrl,)
                       } */}
                       <div className="d-flex align-items-center select-vault">
                         <img src={vault.coinLogo ?vault.coinLogo:vault.vaultDetails?.coinLogoUrl} alt="" className="me-4 v-imge" />
                         <div className="select-vault-c">
                           <h5 className="text-capitalize" onClick={()=>vaultSelection(vault)}>{vault.coinName?vault.coinName:vault.vaultDetails?.coinName}</h5>
                           <h6 className="grey mb-0">({vault.coinSymbol?vault.coinSymbol:vault.vaultDetails?.coinSymbol})</h6>
                         </div>
                       </div>
                       <div className="select-vault-right">
                         {
                           vault.coinValue?
                         <h5>${vault.coinValue.toFixed(2)}</h5>
                         :
                         null
                         }
                         <h6 className="grey mb-0">${vault.coinPrice?vault.coinPrice.toFixed(2):vault.vaultDetails?.coinPrice.toFixed(2)}</h6>
                       </div>
                     </div>
                    
                )  
              })
              :
              <p className="text-center">No Data Available</p>
              }
              {/* <div className="d-flex justify-content-between mb-4">
                <div className="d-flex align-items-center select-vault">
                  <img src={meta} alt="" className="me-4 v-imge" />
                  <div className="select-vault-c">
                    <h5 className="text-capitalize">meta vault</h5>
                    <h6 className="grey mb-0">(MVX)</h6>
                  </div>
                </div>
                <div className="select-vault-right">
                  <h5>$5.45</h5>
                  <h6 className="grey mb-0">$1,300.78</h6>
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div className="d-flex align-items-center select-vault">
                  <img src={meta} alt="" className="me-4 v-imge" />
                  <div className="select-vault-c">
                    <h5 className="text-capitalize">meta vault</h5>
                    <h6 className="grey mb-0">(MVX)</h6>
                  </div>
                </div>
                <div className="select-vault-right">
                  <h5>$5.45</h5>
                  <h6 className="grey mb-0">$1,300.78</h6>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </section>
    }    
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
    fetchCoins: () => dispatch(fetchCoins()),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(SelectVault);
