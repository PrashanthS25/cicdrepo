/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useEffect, useState, useRef } from "react";
import { connect } from "react-redux";
import { useLocation, useSearchParams } from "react-router-dom";
import "../../App.css";
import "./BuySellVaults.css";
import "../../mobileApp.css";
import Nav from "react-bootstrap/Nav";
import Tab from "react-bootstrap/Tab";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Button from "react-bootstrap/Button";
import ReserveComponent from "../ReserveComponent";
import { MdArrowForwardIos } from "react-icons/md";
import { BsFillArrowDownCircleFill } from "react-icons/bs";
import Spinner from "react-bootstrap/Spinner";
import { useNavigate } from "react-router-dom";

import HomeWalletInfo from "../../MobileComponents/HomeWalletInfo";
import BuySellSelectTokenMobile from "../../MobileComponents/BuySellSelectTokenMobile";
import BuySellSelectVaultMobile from "../../MobileComponents/BuySellSelectVaultMobile";
import { selectVault } from "../../redux/index";
import BigNumber from "bignumber.js";
import { generateMultiSwap } from "../../Helper/txHelper";
import Emitter from "../../Helper/emitter";
import Loader from "../Loader";
import SelectToken from "./SelectToken";
import SelectVault from "./SelectVault";
import ErrorComponent from "../ErrorComponent";
import { MdArrowBackIosNew } from "react-icons/md";
import { formatValue } from "../../Helper/helperFunctions";

function BuySellVaults(props) {
  const [txType, setTxType] = useState("buy");
  const [modeType, setModeType] = useState("default");
  const [requiredVaultToSell, setRequiredVaultToSell] = useState(null);
  const [requiredVaultToBuy, setRequiredVaultToBuy] = useState(null);
  const [requiredCoinToSell, setRequiredCoinToSell] = useState(null);
  const [sellApproxValue, setSellApproxValue] = useState();
  const [requiredCoinToBuy, setRequiredCoinToBuy] = useState(null);
  const [processingLoader, setProcessingLoader] = useState(null);
  const [buyQuantity, setBuyQuantity] = useState(null);
  const [error, setError] = useState(null);
  const [sellQuantity, setSellQuantity] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const sellValueRef1 = useRef();
  const buyValueRef1 = useRef();
  const sellValueRef2 = useRef();
  const buyValueRef2 = useRef();
  const sellBtnRef = useRef();
  let navigate = useNavigate();
  let location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
    setLoading(true);
    Emitter.on("setLoading", (data) => {
      // // console.log("hereFit123", data.isLoading);
      setLoading(data.isLoading);
    });
    // // console.log("props56", props);
    if (props.selectedVaultForTx) {
      if (props.selectedVaultForTx.mode === "buy") {
        setRequiredVaultToBuy(props.selectedVaultForTx.vault);
        setTxType("buy");
      }
      if (props.selectedVaultForTx.mode === "sell") {
        setRequiredVaultToSell(props.selectedVaultForTx.vault);
        setTxType("sell");
        sellBtnRef.current.click();
      }
    }
    setLoading(false);
    // // console.log("buySell45");
    if (!props.isWalletConnected) {
      // // console.log("buySell451");
      // setError("NoWalletConnection");
      localStorage.setItem("lastVisitedPage", location.pathname)  
      navigate("/connectWallet")
    }
  }, []);

  const calculateQuantity = (value, requiredCoin, type) => {
    // console.log("log69", value, requiredCoin, type);
    //add validation for value
    //add validation for buy coi selection
    if (!requiredCoin) {
      return setError("Please Select Required Coin or Vault.");
    }
    //add validation for requiredCoin ===null
    if (txType === "buy") {
      if (type === "token") {
        //validation to check buy vault is selected
        if (!requiredVaultToBuy) {
          sellValueRef1.current.value = 0.0;
          return setError("Please Select Buying Vault.");
        }
        if (value > requiredCoin.coinQuantity) {
          sellValueRef1.current.value = 0.0;
          return setError(`Insufficient balance of ${requiredCoin.coinName}.`);
        }
        let changedCoinValue = new BigNumber(value)
          .multipliedBy(new BigNumber(requiredCoin.coinPrice))
          .toNumber();
        // console.log("changedCoinValue", changedCoinValue);
        //set approx value in state
        if (type === "token") {
          let _buyVaultQuant = new BigNumber(changedCoinValue)
            .dividedBy(new BigNumber(requiredVaultToBuy.vaultDetails.coinPrice))
            .toNumber();
          // console.log("buyVaultQuant", _buyVaultQuant);
          setSellApproxValue(changedCoinValue.toFixed(2));
          setSellQuantity(value);
          setBuyQuantity(_buyVaultQuant);
          buyValueRef1.current.value = _buyVaultQuant.toFixed(4);
        } else {
        }
      }
    } else {
      //validation to check buy vault is selected
      if (!requiredCoinToBuy) {
        sellValueRef2.current.value = 0.0;
        return setError("Please Select Buying Coin.");
      }
      if (value > requiredCoin.coinQuantity) {
        sellValueRef2.current.value = 0.0;
        return setError(`Insufficient balance of ${requiredCoin.coinName}.`);
      }
      let changedCoinValue = new BigNumber(value)
        .multipliedBy(new BigNumber(requiredCoin.coinPrice))
        .toNumber();
      // console.log("changedCoinValue", changedCoinValue);
      //set approx value in state
      let _buyCoinQuant = new BigNumber(changedCoinValue)
        .dividedBy(new BigNumber(requiredCoinToBuy.coinPrice))
        .toNumber();
      // console.log("_buyCoinQuant", _buyCoinQuant);
      setSellApproxValue(changedCoinValue.toFixed(2));
      setSellQuantity(value);
      setBuyQuantity(_buyCoinQuant);
      buyValueRef2.current.value = _buyCoinQuant.toFixed(4);

    }
  };

  const changeMode = (_modeType, _txType) => {
    // console.log("logger787", _modeType, _txType);
    setModeType(_modeType);
    setTxType(_txType);
  };

  const initialteTx = async (method) => {
    try {
      setProcessingLoader(true);
      // console.log("sellQuantity", sellQuantity);
      let _changedCoins = { increasedCoins: [], reducedCoins: [] };
      let totalAmount = sellQuantity;
      let requiredSellQuantity = new BigNumber(totalAmount)
        .multipliedBy(new BigNumber(1 - process.env.REACT_APP_FeePerc))
        .toNumber();
      let feeQuantity = new BigNumber(totalAmount)
        .multipliedBy(new BigNumber(process.env.REACT_APP_FeePerc))
        .toNumber();

      if (method === "buy") {
        let requiredbuyQuantity = new BigNumber(requiredCoinToSell.coinPrice)
          .multipliedBy(new BigNumber(requiredSellQuantity))
          .dividedBy(new BigNumber(requiredVaultToBuy.vaultDetails.coinPrice))
          .toNumber();
        // console.log(
        //   "logFire",
        //   requiredSellQuantity,
        //   feeQuantity,
        //   totalAmount,
        //   requiredbuyQuantity,
        //   requiredSellQuantity * requiredCoinToSell.coinPrice,
        //   requiredbuyQuantity * requiredVaultToBuy.vaultDetails.coinPrice
        // );
        _changedCoins.reducedCoins.push({
          coinAddress: requiredCoinToSell.coinAddress,
          coinName: requiredCoinToSell.coinName,
          requiredCoinQuantity: parseFloat(requiredSellQuantity),
          coinPrice: +requiredCoinToSell.coinPrice,
          coinDecimal: +requiredCoinToSell.coinDecimal,
          sellToken: requiredCoinToSell.coinSymbol,
          buyToken: "Wei",
          sellAmount:
            requiredSellQuantity * 10 ** +requiredCoinToSell.coinDecimal,
          feeQuantity,
          totalAmount,
        });
        // console.log("buyObj", requiredVaultToBuy);
        _changedCoins.increasedCoins.push({
          coinAddress: requiredVaultToBuy.vaultAddress,
          coinName: requiredVaultToBuy.vaultName,
          requiredCoinQuantity: parseFloat(requiredbuyQuantity),
          coinPrice: +requiredVaultToBuy.vaultDetails.coinPrice,
          coinDecimal: +requiredVaultToBuy.vaultDetails.coinDecimalPlaces,
          sellToken: "Wei",
          buyToken: requiredVaultToBuy.vaultAddress,
          buyAmount:
            requiredbuyQuantity *
            10 ** +requiredVaultToBuy.vaultDetails.coinDecimalPlaces,
        });
      } else {
        let requiredbuyQuantity = new BigNumber(requiredVaultToSell.coinPrice)
          .multipliedBy(new BigNumber(requiredSellQuantity))
          .dividedBy(new BigNumber(requiredCoinToBuy.coinPrice))
          .toNumber();
        // console.log(
        //   "logFire",
        //   requiredSellQuantity,
        //   feeQuantity,
        //   totalAmount,
        //   requiredbuyQuantity,
        //   requiredSellQuantity * requiredVaultToSell.coinPrice,
        //   requiredbuyQuantity * requiredCoinToBuy.coinPrice
        // );
        _changedCoins.reducedCoins.push({
          coinAddress: requiredVaultToSell.coinAddress,
          coinName: requiredVaultToSell.coinName,
          requiredCoinQuantity: parseFloat(requiredSellQuantity),
          coinPrice: +requiredVaultToSell.coinPrice,
          coinDecimal: +requiredVaultToSell.coinDecimal,
          sellToken: requiredVaultToSell.coinSymbol,
          buyToken: "Wei",
          sellAmount:
            requiredSellQuantity * 10 ** +requiredVaultToSell.coinDecimal,
          feeQuantity,
          totalAmount,
        });
        // console.log("buyObj", requiredVaultToBuy);
        _changedCoins.increasedCoins.push({
          coinAddress: requiredCoinToBuy.coinAddress,
          coinName: requiredCoinToBuy.coinName,
          requiredCoinQuantity: parseFloat(requiredbuyQuantity),
          coinPrice: +requiredCoinToBuy.coinPrice,
          coinDecimal: +requiredCoinToBuy.coinDecimal,
          sellToken: "Wei",
          buyToken: requiredCoinToBuy.vaultAddress,
          buyAmount: requiredbuyQuantity * 10 ** +requiredCoinToBuy.coinDecimal,
        });
      }
      // console.log("_changedCoins", _changedCoins);
      await generateMultiSwap(
        _changedCoins,
        props.web3InStance,
        props.walletAddress.toString(),
        0,
        props.chain
      );
      setProcessingLoader(false);
    } catch (error) {
      // console.log("error", error);
      setProcessingLoader(false);
      setError(error.message);
    }
  };

  const selectMaxQuantity = () => {
    if (txType === "buy") {
      if (!requiredCoinToSell || !requiredVaultToBuy) {
        return setError("Please Select Required Coin or Vault.");
      }
      sellValueRef1.current.value = requiredCoinToSell.coinQuantity;
      calculateQuantity(
        requiredCoinToSell.coinQuantity,
        requiredCoinToSell,
        "token"
      );
    } else {
      if (!requiredVaultToSell || !requiredCoinToBuy) {
        return setError("Please Select Required Coin or Vault.");
      }
      sellValueRef2.current.value = requiredVaultToSell.coinQuantity;
      calculateQuantity(
        requiredVaultToSell.coinQuantity,
        requiredVaultToSell,
        "token"
      );
    }
  };

  const changeTxMode = (mode) => {
    setTxType(mode);
    if (mode == "sell") {
      if(sellValueRef1 && buyValueRef1){
      sellValueRef1.current.value = 0.0;
      buyValueRef1.current.value = 0.0;
      }
      setRequiredCoinToSell(null);
      setRequiredVaultToBuy(null);
    } else {
      if(sellValueRef2 && buyValueRef2){
      sellValueRef2.current.value = 0.0;
      buyValueRef2.current.value = 0.0;
      }
      setRequiredVaultToSell(null);
      setRequiredCoinToBuy(null);
    }
  };

  return (
    <>
      {props.error || error ? (
        <ErrorComponent
          setError={setError}
          error={error ? error : props.error}
        />
      ) : null}

      {processingLoader ? (
        <div className="confirm-loader">
          <Spinner animation="border" />
        </div>
      ) : null}

      {isLoading ? (
        <Loader />
      ) : modeType === "default" ? (
        <section className="section buy-sell-vault-sec">
          <div className="container">
            <HomeWalletInfo />
            <div className="section-top-heading-naviagte  mt-3 busellvault-navigate">
              <button
                className="navigate-btn mb-2"
                onClick={() => {
                  navigate(-1);
                }}
              >
                <MdArrowBackIosNew className="naviagte-arrow-icon" />
              </button>
              <div className="section-heading">
                <h3 className="section-title mb-2">Buy / Sell</h3>
              </div>
            </div>
            {/* <div className="section-heading">
                  <h3 className="section-title mb-4">Buy / Sell</h3>
               </div> */}
            <div className="buy-sell-vault-box alphavault-sec-box p-4 mb-5">
              <Tab.Container
                id="left-tabs-example"
                defaultActiveKey={txType ? txType : "sell"}
              >
                <Nav
                  variant="pills"
                  className="justify-content-center alphavault-tab-nav"
                  defaultActiveKey="/home"
                >
                  <Nav.Item className="alphavault-tab-nav-item">
                    <Nav.Link
                      eventKey="buy"
                      className="alphavault-tab-nav-links"
                      onClick={() => changeTxMode("buy")}
                    >
                      Buy
                    </Nav.Link>
                  </Nav.Item>
                  <Nav.Item className="alphavault-tab-nav-item">
                    <Nav.Link
                      eventKey="sell"
                      className="alphavault-tab-nav-links"
                      ref={sellBtnRef}
                      onClick={() => changeTxMode("sell")}
                    >
                      Sell
                    </Nav.Link>
                  </Nav.Item>
                </Nav>

                <Tab.Content className="alphavault-tab-nav-content">
                  {txType === "buy" ? (
                    <Tab.Pane eventKey="buy">
                      <div className="buy-content">
                        <div className="from-content mt-3 mb-4">
                          <h6 className="buy-content-title">From</h6>
                          <div className="buy-content-box">
                            <div className="buy-content-balance d-flex mb-2">
                              {requiredCoinToSell ? (
                                <p className="buy-balance-b mb-0">
                                  <span className="tile me-1">∼</span> $
                                  {sellApproxValue}
                                </p>
                              ) : (
                                <p className="buy-balance-b mb-0">
                                  <span className="tile me-1">∼</span>-
                                </p>
                              )}

                              <p className="buy-balance mb-0 d-flex">
                                Balance:{" "}&nbsp;
                                {requiredCoinToSell ? (
                                  <span className="text-end grey mb-0">
                                    {formatValue(
                                      +requiredCoinToSell.coinQuantity,
                                      4
                                    )}
                                  </span>
                                ) : (
                                  <span className="text-end grey mb-0">-</span>
                                )}
                              </p>
                            </div>

                            <InputGroup className="align-items-center">
                              <Form.Control
                                placeholder="0.0"
                                aria-label="0.0000"
                                aria-describedby="basic-addon2"
                                className="form-buy-input"
                                type="number"
                                onChange={(e) =>
                                  calculateQuantity(
                                    e.target.value,
                                    requiredCoinToSell,
                                    "token"
                                  )
                                }
                                ref={sellValueRef1}
                              />
                              <InputGroup.Text
                                id="basic-addon2"
                                className="buy-max"
                                onClick={() => selectMaxQuantity()}
                              >
                                MAX
                              </InputGroup.Text>
                              {/* <Button variant="outline-secondary buy-button" id="button-addon2">
                                         <img src={eth} className="buy-icon me-2"  alt=""/> <span className='me-2'>ETH </span><MdArrowForwardIos/>
                                       </Button> */}
                              {/* <NavLink to='/buysellvaults/selecttoken?mode=buy' className='mobile-stake-btnhide'> */}
                              {/* <Button variant="outline-secondary buy-button" id="button-addon2" onClick={()=>{changeMode('token','buy')}}>Select token <MdArrowForwardIos className='ms-1'/> </Button> */}
                              {/* </NavLink> */}
                              <Button
                                className="mobile-hide-button"
                                variant="outline-secondary buy-button"
                                id="button-addon2"
                                disabled={
                                  props?.isWalletConnected ? false : true
                                }
                                onClick={() => {
                                  changeMode("token", "buy");
                                }}
                              >
                                
                                {requiredCoinToSell ? (
                                  <>
                                    <img
                                      src={requiredCoinToSell.coinLogo? requiredCoinToSell.coinLogo:requiredCoinToSell.coinLogoUrl}
                                      alt=""
                                      className="me-1 exploreVaultTableCoinImage"
                                    />
                                    <span>{requiredCoinToSell.coinSymbol}</span>
                                  </>
                                ) : (
                                  <>
                                   Select A Token{" "}
                                    <MdArrowForwardIos className="ms-1" />
                                  </>
                                )}
                              </Button>

                              <BuySellSelectTokenMobile  requiredCoinToSell={requiredCoinToSell} setRequiredCoinToSell={setRequiredCoinToSell}  selectionMode={txType}/>
                            </InputGroup>

                            <div className="buy-content-price mt-2">
                              {/* <p className='text-end grey mb-0'>Price: <span> $3,120</span></p>                                 */}
                              {requiredCoinToSell ? (
                                <p className="text-end grey mb-0">
                                  Price:{" "}
                                  <span>
                                    {" "}
                                    ${requiredCoinToSell.coinPrice.toFixed(2)}
                                  </span>
                                </p>
                              ) : (
                                <p className="text-end grey mb-0">
                                  Price: <span>-</span>
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="from-content mt-3">
                          <div className="d-flex position-relative">
                            <h6 className="buy-content-title">to</h6>{" "}
                            <BsFillArrowDownCircleFill className="buy-arrow-icon" />
                          </div>

                          <div className="buy-content-box sell-content-box">
                            <div className="buy-content-price mb-2">
                              {/* {
                                    // console.log("detaiuls",props.selectedVaultForTx?.vault.vaultDetails)
                                  } */}
                              {requiredVaultToBuy ? (
                                <p className="text-end grey mb-0">
                                  Price:{" "}
                                  <span>
                                    {" "}
                                    $
                                    {requiredVaultToBuy.vaultDetails.coinPrice.toFixed(
                                      2
                                    )}
                                  </span>
                                </p>
                              ) : (
                                <p className="text-end grey mb-0">
                                  Price: <span>-</span>
                                </p>
                              )}
                            </div>
                            <InputGroup className=" align-items-center">
                              <Form.Control
                                placeholder="0.0"
                                aria-label="0.0000"
                                aria-describedby="basic-addon2"
                                className="form-buy-input"
                                ref={buyValueRef1}
                                disabled={true}
                                type="number"
                              />
                              {/* <NavLink to='/buysellvaults/selectvault' className='mobile-stake-btnhide'> */}
                              <Button
                                className="mobile-hide-button"
                                variant="outline-secondary buy-button"
                                id="button-addon2"
                                disabled={
                                  props?.isWalletConnected ? false : true
                                }
                                onClick={() => {
                                  changeMode("vault", "buy");
                                }}
                              >
                                {requiredVaultToBuy ? (
                                  <>
                                    <img
                                      className="me-1 edit-vault-input-img"
                                      src={
                                        requiredVaultToBuy.vaultDetails.coinLogoUrl
                                      }
                                      alt=""
                                    />
                                    <span>
                                      {
                                        requiredVaultToBuy.vaultDetails
                                          .coinSymbol
                                      }
                                    </span>
                                  </>
                                ) : (
                                  <>
                                    Select a Vault{" "}
                                    <MdArrowForwardIos className="ms-1" />
                                  </>
                                )}
                              </Button>
                              {/* </NavLink> */}

                              <BuySellSelectVaultMobile  chainInfo={props.chain} setRequiredVaultToBuy={setRequiredVaultToBuy} requiredVaultToBuy={requiredVaultToBuy} selectionMode={txType}/>
                            </InputGroup>
                          </div>
                        </div>

                        <div>
                          <ReserveComponent />
                        </div>

                        <div className="section-btn text-center mt-3">
                          <button
                            type="button"
                            className="btn btn-light section-button"
                            onClick={() => initialteTx("buy")}
                            disabled={requiredCoinToSell&&requiredVaultToBuy&&(+sellApproxValue)?false:true}
                          >
                            buy
                          </button>
                        </div>

                        {/* <div className='buy-content-message text-center mt-3'>
                              <p className='mb-0'>Insufficient ETH Ballance</p>
                            </div> */}
                      </div>
                    </Tab.Pane>
                  ) : (
                    <Tab.Pane eventKey="sell">
                      <div className="buy-content">
                        <div className="from-content mt-3 mb-4">
                          <h6 className="buy-content-title">From</h6>
                          <div className="buy-content-box">
                            <div className="buy-content-balance d-flex mb-2">
                              {/* <p className='buy-balance-b mb-0'><span className='tile me-1'>∼</span> $230.59</p> */}
                              {requiredVaultToSell ? (
                                <p className="buy-balance-b mb-0">
                                  <span className="tile me-1">∼</span> $
                                  {sellApproxValue}
                                </p>
                              ) : (
                                <p className="buy-balance-b mb-0">
                                  <span className="tile me-1">∼</span>-
                                </p>
                              )}
                              <p className="buy-balance mb-0 d-flex">
                                Balance:{" "}&nbsp;
                                {requiredVaultToSell ? (
                                  <span className="text-end grey mb-0">
                                    {formatValue(
                                      +requiredVaultToSell.coinQuantity,
                                      4
                                    )}
                                  </span>
                                ) : (
                                  <p className="text-end grey mb-0">-</p>
                                )}
                              </p>
                            </div>

                            <InputGroup className="align-items-center">
                              <Form.Control
                                placeholder="0.0"
                                aria-label="0.0"
                                aria-describedby="basic-addon2"
                                className="form-buy-input"
                                type="number"
                                onChange={(e) =>
                                  calculateQuantity(
                                    e.target.value,
                                    requiredVaultToSell,
                                    "token"
                                  )
                                }
                                ref={sellValueRef2}
                              />
                              <InputGroup.Text
                                id="basic-addon2"
                                className="buy-max"
                                onClick={() => selectMaxQuantity()}
                              >
                                MAX
                              </InputGroup.Text>
                              <Button
                               className="mobile-hide-button"
                                variant="outline-secondary sell-button"
                                id="button-addon2"
                                disabled={
                                  props?.isWalletConnected ? false : true
                                }
                                onClick={() => {
                                  changeMode("vault", "sell");
                                }}
                              >
                                {requiredVaultToSell ? (
                                  <>
                                    <img
                                      src={requiredVaultToSell.coinLogo}
                                      alt=""
                                      className="me-1 exploreVaultTableCoinImage"
                                    />
                                    <span>
                                      {requiredVaultToSell.coinSymbol}
                                    </span>
                                  </>
                                ) : (
                                  <>
                                    Select a Vault{" "}
                                    <MdArrowForwardIos className="ms-1" />
                                  </>
                                )}
                              </Button>
                              <BuySellSelectVaultMobile  requiredVaultToSell={requiredVaultToSell} setRequiredVaultToSell={setRequiredVaultToSell}  selectionMode={txType}/>
                              
                            </InputGroup>

                            <div className="buy-content-price mt-2">
                              {requiredVaultToSell ? (
                                <p className="text-end grey mb-0">
                                  Price:{" "}
                                  <span>
                                    {" "}
                                    ${requiredVaultToSell.coinPrice.toFixed(2)}
                                  </span>
                                </p>
                              ) : (
                                <p className="text-end grey mb-0">
                                  Price: <span>-</span>
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="from-content mt-3">
                          <div className="d-flex position-relative">
                            <h6 className="buy-content-title">to</h6>{" "}
                            <BsFillArrowDownCircleFill className="buy-arrow-icon" />
                          </div>

                          <div className="buy-content-box sell-content-box">
                            <div className="buy-content-price mb-2">
                              {/* <p className='text-end grey mb-0'>Price: <span> $3,120</span></p> */}
                              {requiredCoinToBuy ? (
                                <p className="text-end grey mb-0">
                                  Price:{" "}
                                  <span>
                                    ${(+requiredCoinToBuy.coinPrice).toFixed(4)}
                                  </span>
                                </p>
                              ) : (
                                <p className="text-end grey mb-0">-</p>
                              )}
                            </div>
                            <InputGroup className=" align-items-center">
                              <Form.Control
                                placeholder="0.0"
                                aria-label="0.0"
                                aria-describedby="basic-addon2"
                                className="form-buy-input"
                                ref={buyValueRef2}
                                disabled={true}
                                type="number"
                              />
                              <Button
                               className="mobile-hide-button"
                                variant="outline-secondary  sell-button-to"
                                id="button-addon2"
                                disabled={
                                  props?.isWalletConnected ? false : true
                                }
                                onClick={() => {
                                  changeMode("token", "sell");
                                }}
                              >
                                {requiredCoinToBuy ? (
                                  <>
                                    <img
                                      className="me-1 edit-vault-input-img"
                                      src={requiredCoinToBuy.coinLogo?requiredCoinToBuy.coinLogo:requiredCoinToBuy.coinLogoUrl}
                                      alt=""
                                    />
                                    <span>{requiredCoinToBuy.coinSymbol}</span>
                                  </>
                                ) : (
                                  <>
                                    Select a Coin{" "}
                                    <MdArrowForwardIos className="ms-1" />
                                  </>
                                )}
                              </Button>
                              <BuySellSelectTokenMobile  requiredCoinToBuy={requiredCoinToBuy} setRequiredCoinToBuy={setRequiredCoinToBuy} selectionMode={txType} networkId={props.chain.networkId}/>
                            </InputGroup>
                          </div>
                        </div>
                        <div>
                          <ReserveComponent />
                        </div>

                        <div className="section-btn text-center mt-3">
                          <button
                            type="button"
                            className="btn btn-light section-button"
                            onClick={() => initialteTx("sell")}
                            disabled ={requiredVaultToSell&&requiredCoinToBuy&&(+sellApproxValue)?false:true}
                          >
                            sell
                          </button>
                        </div>
                      </div>
                    </Tab.Pane>
                  )}
                </Tab.Content>
              </Tab.Container>
            </div>
          </div>
        </section>
      ) : props.serverResponse ? (
        modeType === "token" ? (
          <SelectToken
            setModeType={setModeType}
            modeType={modeType}
            txType={txType}
            setRequiredCoinToSell={setRequiredCoinToSell}
            setRequiredCoinToBuy={setRequiredCoinToBuy}
            realAssetList={props.serverResponse.assetList}
            chainId={props.chain?.networkId}
          />
        ) : (
          <SelectVault
            setModeType={setModeType}
            modeType={modeType}
            txType={txType}
            setRequiredVaultToBuy={setRequiredVaultToBuy}
            setRequiredVaultToSell={setRequiredVaultToSell}
            storedVaults={props.serverResponse.vaults}
            chainId={props.chain?.networkId}
          />
        )
      ) : null}
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
    selectedVaultForTx: state.publicVault.selectedVault,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    selectVaultForTx: (vaultDetails) => dispatch(selectVault(vaultDetails)),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(BuySellVaults);
