import React, { useState } from 'react';
import '../../App.css'
import '../Staking/Staking.css'
import '../../mobileApp.css';
import Nav from 'react-bootstrap/Nav';
import Tab from 'react-bootstrap/Tab';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Button from 'react-bootstrap/Button';
import { MdArrowForwardIos} from "react-icons/md";
import  eth from "../../assets/images/ethereum1.svg";
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Modal from 'react-bootstrap/Modal';
import Popover from 'react-bootstrap/Popover';
import {NavLink} from "react-router-dom";
import HomeWalletInfo from '../../MobileComponents/HomeWalletInfo';
import SelectDurationMobile from '../../MobileComponents/SelectDurationMobile';
import StakeSelectTokenMobile from '../../MobileComponents/StakeSelectTokenMobile';
import UnstakeSelectTokenMobile from '../../MobileComponents/UnstakeSelectTokenMobile';

export default function Stake(){
  
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

    return(
       <>
       <section className='section stake-card-sec'>
          <div className="container">
          <HomeWalletInfo/>
               <div className="section-heading">
                  <h3 className="section-title mb-4">stake</h3>
               </div>
               <div className='alphavault-sec-box p-4'>
                  <Tab.Container id="left-tabs-example" defaultActiveKey="stake">
                     <Nav variant="pills" className='justify-content-center alphavault-tab-nav' defaultActiveKey="/home">
                      <Nav.Item className='alphavault-tab-nav-item'>
                        <Nav.Link eventKey="stake" className='alphavault-tab-nav-links'>stake</Nav.Link>
                      </Nav.Item>
                      <Nav.Item className='alphavault-tab-nav-item'>
                        <Nav.Link eventKey="unstake" className='alphavault-tab-nav-links'>unstake</Nav.Link>
                      </Nav.Item>
                    </Nav>
        
                    <Tab.Content className='alphavault-tab-nav-content'>
                      <Tab.Pane eventKey="stake">
                        <div className='stake-content mt-4'>
                             <h6 className='stake-content-title'>Choose Token & Amount to Stake 
                               <sup>
                          
                                       {['top'].map((placement) => (
                                     <OverlayTrigger
                                       
                                       key={placement}
                                       placement={placement}
                                       overlay={
                                         <Popover id={`popover-positioned-${placement}`}>
                                           <Popover.Body>
                                             Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                             . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                              temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                               nesciunt harum consectetur impedit amet suscipit ducimus id!
                                           </Popover.Body>
                                         </Popover>
                                       }
                                     >
                                        <Button variant="secondary" className='stake-i-button ms-2'>!</Button>
                                     </OverlayTrigger>
                                   ))}
                               </sup>
                             </h6>
                             <div className='stake-content-box'>
                              <div className='stake-content-box-top-text'>
                                 <p className='mb-2 font-styl'><span className='tile me-1'>∼</span>$230.59</p>
                                 <p className='mb-2'>Available Balance:<span className='ms-2'>1.1020564</span></p>
                              </div>
                                <InputGroup className="align-items-center stake-input">
                                   <Form.Control  placeholder="0.00"  aria-label="0.0"  aria-describedby="basic-addon2" className='form-stake-input' />
                                   <input type="text" className="stake-percent active" placeholder="0%"  aria-label="Username" aria-describedby="basic-addon1" />
                                     <NavLink to='/staking/stakeselecttoken' className='mobile-stake-btnhide'>
                                        <Button variant="outline-secondary stake-button" id="button-addon2">
                                         Select token <MdArrowForwardIos className='stake-icon ms-1'/>
                                        </Button>
                                     </NavLink>

                                     <StakeSelectTokenMobile/>

                                     {/* <Button variant="outline-secondary stake-button after-stake-btn" id="button-addon2">
                                         <img src={eth} className="stake-btn-icon me-2"  alt=""/> <span className='me-3'>ETH </span><MdArrowForwardIos className='stake-icon'/>
                                     </Button>  */}
                                </InputGroup>
                             </div>
                        </div>
                        <div className='stake-content mt-4'>
                             <h6 className='stake-content-title'>Choose Staking Platform
                             <sup>
                             {['top'].map((placement) => (
                                     <OverlayTrigger
                                       
                                       key={placement}
                                       placement={placement}
                                       overlay={
                                         <Popover id={`popover-positioned-${placement}`}>
                                           <Popover.Body>
                                             Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                             . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                              temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                               nesciunt harum consectetur impedit amet suscipit ducimus id!
                                           </Popover.Body>
                                         </Popover>
                                       }
                                     >
                                        <Button variant="secondary" className='stake-i-button ms-2'>!</Button>
                                     </OverlayTrigger>
                                   ))}
                               </sup>
                              </h6>
                             <div className='stake-content-box'>
                             <div className='stake-content-box-top-text'>
                                 <p className='mb-2 grey font-styl'><span className='tile me-1'>∼</span>APY</p>
                              </div>
                                <InputGroup className="align-items-center stake-input">
                                   <Form.Control  placeholder="0.0%"  aria-label="0.0"  aria-describedby="basic-addon2" className='form-stake-input' />
                                      <NavLink to='/staking/stakingplatform'>
                                        <Button variant="outline-secondary stake-button" id="button-addon2">
                                         Staking Platform <MdArrowForwardIos className='stake-icon ms-1'/>
                                        </Button>
                                      </NavLink>
                                     {/* <Button variant="outline-secondary stake-button after-stake-btn1" id="button-addon2">
                                        Stake DAO <MdArrowForwardIos className='stake-icon ms-3'/>
                                     </Button> */}
                                </InputGroup>
                             </div>
                        </div>
                        <div className='stake-content mt-4'>
                             <h6 className='stake-content-title'>Choose Staking Duration
                             <sup>
                             {['top'].map((placement) => (
                                     <OverlayTrigger
                                       
                                       key={placement}
                                       placement={placement}
                                       overlay={
                                         <Popover id={`popover-positioned-${placement}`}>
                                           <Popover.Body>
                                             Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                             . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                              temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                               nesciunt harum consectetur impedit amet suscipit ducimus id!
                                           </Popover.Body>
                                         </Popover>
                                       }
                                     >
                                        <Button variant="secondary" className='stake-i-button ms-2'>!</Button>
                                     </OverlayTrigger>
                                   ))}
                               </sup>
                             </h6>
                             <div className='stake-content-box'>
                                <InputGroup className="align-items-center stake-input">
                                   <Form.Control  placeholder="0.00"  aria-label="0.0"  aria-describedby="basic-addon2" className='form-stake-input' />
                                      <NavLink to='/staking/stakingduration' className='duration-hide'>
                                        <Button variant="outline-secondary stake-button" id="button-addon2">
                                           Staking Duration <MdArrowForwardIos className='stake-icon ms-1' />
                                        </Button>
                                      </NavLink>
                                  {/* <NavLink to='/staking/stakingduration'>
                                        <Button variant="outline-secondary stake-button after-stake-btn1" id="button-addon2">
                                          Staking Duration<MdArrowForwardIos className='stake-icon ms-1'/>
                                        </Button>
                                      </NavLink> */}

                                   <SelectDurationMobile/>
                                     
                                </InputGroup>
                             </div>
                     </div>
                        <div className='section-btn text-center mt-3'>
                           {/* <button type="button" className="btn btn-light  stake-disabled-btn" onClick={handleShow}>stake</button > */}
                           <button type="button" className="btn btn-light section-button stake-b " onClick={handleShow}>stake</button >
                           <Modal show={show} onHide={handleClose}   centered>
                             <Modal.Header>
                               <Modal.Title><h4 className='mt-4 staking-warning-title'>Warning!</h4></Modal.Title>
                             </Modal.Header>
                             <Modal.Body className='warning-staking-body'>
                               <p className='text-center mb-0 warning-staking-p'>Acknowledgement</p>
                               <p className='text-center mb-0 staking-check-label'>You accept that the use of the Alpha Vault Protocol is entirely at your own risk, and 
                                  that staking may result in charges applying from the staking platform. Alpha Vault does not 
                                  hold any responsibility in any lose of fund what so ever. Your staked tokens maybe locked and can 
                                  be unlocked based on the staking platform rules.
                               </p>
                              
                             </Modal.Body>
                             <hr className='section-border-color' />
                             <Modal.Footer>
                             <div className="form-check connect-wallet-form-check staking-form-check">
                               <input className="form-check-input modal-check" type="checkbox" value="a" id="flexCheckDefault1"/>
                               <label className="form-check-label  modal-check-labl pe-4" for="flexCheckDefault">
                                <p className='staking-check-label stke-warning-check-p'>You accept that the use of the Stake Alpha Vault Protocol is entirely at your own risk</p> 
                               </label>
                             </div>
                              <div className='staking-warning-button'>
                               <Button  variant="secondary"  className='section-button staking-warning-btn'>
                                 STAKE
                               </Button>
                               <Button variant="secondary" className='staking-warning-close-btn' onClick={handleClose}>
                                 Cancel
                               </Button>
                               </div>
                             </Modal.Footer>
                           </Modal>

                        </div>
                          
                      </Tab.Pane>

                      <Tab.Pane eventKey="unstake">
                      <div className='stake-content mt-4'>
                             <h6 className='stake-content-title'>Choose Token & Amount to UnStake 
                               <sup>
                               {['top'].map((placement) => (
                                     <OverlayTrigger
                                       
                                       key={placement}
                                       placement={placement}
                                       overlay={
                                         <Popover id={`popover-positioned-${placement}`}>
                                           <Popover.Body>
                                             Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                             . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                              temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                               nesciunt harum consectetur impedit amet suscipit ducimus id!
                                           </Popover.Body>
                                         </Popover>
                                       }
                                     >
                                        <Button variant="secondary" className='stake-i-button ms-2'>!</Button>
                                     </OverlayTrigger>
                                   ))}
                               </sup>
                             </h6>
                             <div className='stake-content-box'>
                              <div className='stake-content-box-top-text'>
                                 <p className='mb-2 font-styl'><span className='tile me-1'>∼</span>$230.59</p>
                                 <p className='mb-2'>Staked Amount:<span className='ms-2'>1.1020564</span></p>
                              </div>
                                <InputGroup className="align-items-center stake-input">
                                   <Form.Control  placeholder="0.00"  aria-label="0.0"  aria-describedby="basic-addon2" className='form-stake-input' />
                                   <input type="text" className="stake-percent active" placeholder="0%"  aria-label="Username" aria-describedby="basic-addon1" />
                                   
                                      <NavLink to='/staking/unstakeselecttoken' className='mobile-stake-btnhide'>
                                        <Button variant="outline-secondary stake-button" id="button-addon2">
                                          Select token <MdArrowForwardIos className='stake-icon ms-1'/>
                                        </Button>
                                      </NavLink>

                                      <UnstakeSelectTokenMobile />

                                     {/* <Button variant="outline-secondary stake-button after-stake-btn" id="button-addon2">
                                         <img src={eth} className="stake-btn-icon me-2"  alt=""/> <span className='me-3'>ETH </span><MdArrowForwardIos className='stake-icon'/>
                                     </Button>  */}
                                </InputGroup>
                             </div>
                        </div>
                        <div className='stake-content mt-4'>
                             <h6 className='stake-content-title'>Choose Staking Platform
                             <sup>
                             {['top'].map((placement) => (
                                     <OverlayTrigger
                                       
                                       key={placement}
                                       placement={placement}
                                       overlay={
                                         <Popover id={`popover-positioned-${placement}`}>
                                           <Popover.Body>
                                             Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                             . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                              temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                               nesciunt harum consectetur impedit amet suscipit ducimus id!
                                           </Popover.Body>
                                         </Popover>
                                       }
                                     >
                                        <Button variant="secondary" className='stake-i-button ms-2'>!</Button>
                                     </OverlayTrigger>
                                   ))}
                               </sup>
                              </h6>
                             <div className='stake-content-box'>
                             <div className='stake-content-box-top-text'>
                                 <p className='mb-2 font-styl'>Charges</p>
                              </div>
                                <InputGroup className="align-items-center stake-input">
                                   <Form.Control  placeholder="0.0%"  aria-label="0.0"  aria-describedby="basic-addon2" className='form-stake-input' />
                                     <NavLink to='/staking/unstakeplatform'>
                                        <Button variant="outline-secondary stake-button" id="button-addon2">
                                          Staking Platform <MdArrowForwardIos className='stake-icon ms-1'/>
                                        </Button>
                                      </NavLink>
                                     {/* <Button variant="outline-secondary stake-button after-stake-btn1" id="button-addon2">
                                        Stake DAO <MdArrowForwardIos className='stake-icon ms-3'/>
                                     </Button> */}
                                </InputGroup>
                             </div>
                        </div>
                        <div className='unstaking-warning-msg'>
                               <p>Charges might apply when UnStaking before the locking period ends </p>
                              </div>
                        <div className='section-btn text-center mt-3'>
                           {/* <button type="button" className="btn btn-light stake-disabled-btn" onClick={handleShow}>unstake</button > */}
                           <button type="button" className="btn btn-light section-button stake-b" onClick={handleShow}>unstake</button >
                           <Modal show={show} onHide={handleClose}   centered>
                             <Modal.Header>
                               <Modal.Title><h4 className='mt-4 staking-warning-title'>Warning!</h4></Modal.Title>
                             </Modal.Header>
                             <Modal.Body className='warning-staking-body'>
                               <p className='text-center mb-0 warning-staking-p'>Acknowledgement</p>
                               <p className='text-center mb-0 staking-check-label'>You accept that the use of the Alpha Vault Protocol is entirely at your own risk, and 
                                  that staking may result in charges applying from the staking platform. Alpha Vault does not 
                                  hold any responsibility in any lose of fund what so ever. Your staked tokens maybe locked and can 
                                  be unlocked based on the staking platform rules.
                               </p>
                              
                             </Modal.Body>
                             <hr className='section-border-color' />
                             <Modal.Footer>
                             <div className="form-check connect-wallet-form-check staking-form-check">
                               <input className="form-check-input modal-check" type="checkbox" value="a" id="flexCheckDefault1"/>
                               <label className="form-check-label  modal-check-labl pe-4" for="flexCheckDefault">
                                <p className='staking-check-label stke-warning-check-p'>You accept that the use of the Stake Alpha Vault Protocol is entirely at your own risk</p> 
                               </label>
                             </div>
                              <div className='staking-warning-button text-center'>
                               <Button  variant="secondary"  className='section-button staking-warning-btn'>
                                 UNSTAKE
                               </Button>
                               <Button variant="secondary" className='staking-warning-close-btn' onClick={handleClose}>
                                 Cancel
                               </Button>
                               </div>
                             </Modal.Footer>
                           </Modal>

                        </div>
                      
                      </Tab.Pane>
                    </Tab.Content> 
                  </Tab.Container>
               </div>
               <div className='unstaking-warning-msg'>
                <p>Charges might apply when UnStaking before the locking period ends </p>
               </div>
          </div>
        </section>
        
       </>
    )
}