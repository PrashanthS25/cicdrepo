import React,{useEffect} from 'react';
import '../../App.css'
import '../Staking/Staking.css'
import '../../mobileApp.css';
import  eth from "../../assets/images/ethereum1.svg";
import { Link } from 'react-router-dom';
import HomeWalletInfo from '../../MobileComponents/HomeWalletInfo';

export default function Staking(){
   useEffect(()=>{
      window.scrollTo(0, 0)
   },[])

   return(
      <>
      {/* <section className='section staking-homepage'>
        <div className='container'>
        <HomeWalletInfo/>
          <div className="section-heading">
            <h3 className="section-title mb-4">Staking</h3>
          </div>
            <div className="staking-homepage-sec alphavault-sec-box p-4 text-center">
              <h5 className='staking-homepage-title grey'>Current Wallet Balance</h5>
              <h2 className="staking-homepage-price font-styl mb-3 mt-4"><span className='tile me-1'>∼</span>$3,230.00</h2>
                  <div className='staking-homepage-d-box'>
                     <div className='staking-homepage-box me-2 me-sm-0'>
                        <h5 className='staking-homepage-box-title grey'>Total Staked</h5>
                        <h4 className='staking-homepage-box-h4 font-styl'>$2,145.23&nbsp;<span className='grey'>(75%)</span></h4>
                     </div>
                     <div className='staking-homepage-box'>
                        <h5 className='staking-homepage-box-title grey'>Total Rewards</h5>
                        <h4 className='staking-homepage-box-h4 font-styl'>$1,154.76</h4>
                     </div>
                  </div>
                  <div className='section-btn text-center mt-4'>
                  <Link  to="/Staking/Stake">  <button type="button" className="btn btn-light section-button">STAKE / UNSTAKE</button ></Link>
                  </div>
            </div> 
         
        <div className='staked-wallet-tokens'>
           <div className='staked-wallet-top'>
              <h5 className="staked-wallet-top-title">wallet tokens</h5>
              <div className='staked-wallet-right'>
              <div className="staked-button-btn-grp btn-group">
                <button  className="btn btn-primary staked-button active" aria-current="page">All</button>
                <button  className="btn btn-primary staked-button">Staked</button>
                <button  className="btn btn-primary staked-button">Not staked</button>
              </div>
              </div>
           </div>

         <div className="alphavault-sec-box Staked-wallet-section mt-3">
           <div className="staked-wallet-section-box">
             <div className="staked-wallet-left">
                   <img src={eth} alt="" className="me-3 mobile-v-hp-image" />
                   <div className="staked-wallet-text">
                     <h6 className="staked-wallet-name  mb-1 mb-sm-2  text-capitalize">Ethereum</h6> 
                     <h6 className="staked-wallet-percent mb-0 grey">$3,900</h6>
                   </div>
                 </div>
                 <div className="staked-wallet-right">
                   <h5 className="staked-wallet-price me-2 mb-0">1.4034</h5>
                   <h5 className="walletshortname mb-0">ETH</h5>
                 </div>
             </div>
             <hr className='section-border-color' />

             <div className='staked-wallet-row text-center'>
                <div className='col staked-wallet-col'>
                   <h6 className="grey">Staked</h6>
                   <h5 className=" mb-0">1.05 ETH</h5>
                </div>
                <div className='col staked-br staked-wallet-col'>
                   <h6 className="grey">Return</h6>
                   <h5 className="mb-0">1.05 ETH</h5>
                </div>
                <div className='col staked-wallet-col'>
                   <h6 className="grey">Remaining</h6>
                   <h5 className="mb-0">120 days</h5>
                </div>
             </div>
           </div>
        <div className="alphavault-sec-box Staked-wallet-section">
           <div className="staked-wallet-section-box">
             <div className="staked-wallet-left">
                   <img src={eth} alt="" className="me-3 mobile-v-hp-image" />
                   <div className="staked-wallet-text">
                     <h6 className="staked-wallet-name  text-capitalize">Ethereum</h6> 
                     <h6 className="staked-wallet-percent mb-0 grey">$3,900</h6>
                   </div>
                 </div>
                 <div className="staked-wallet-right">
                   <h5 className="staked-wallet-price me-2 mb-0">1.4034</h5>
                   <h5 className="walletshortname mb-0">ETH</h5>
                 </div>
             </div>
             <hr className='section-border-color' />

             <div className='staked-wallet-row text-center'>
                <div className='col staked-wallet-col'>
                   <h6 className="grey">Staked</h6>
                   <h5 className=" mb-0">0</h5>
                </div>
                <div className='col staked-wallet-col staked-br'>
                   <h6 className="grey">Return</h6>
                   <h5 className="mb-0">-</h5>
                </div>
                <div className='col staked-wallet-col'>
                   <h6 className="grey">Remaining</h6>
                   <h5 className="mb-0">-</h5>
                </div>
             </div>
           </div>
        </div>
      </div>
    </section> */}
   
      </>
   )

}