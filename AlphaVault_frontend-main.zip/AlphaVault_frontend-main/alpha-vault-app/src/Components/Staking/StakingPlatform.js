import React, { useState } from 'react';
import '../../App.css'
import '../Staking/Staking.css'
import '../../mobileApp.css';
import { MdArrowBackIosNew , MdKeyboardArrowDown} from "react-icons/md";
import { IoIosArrowDown } from "react-icons/io";
import  eth1 from "../../assets/images/ethereum1.svg";
import  stakingicon1 from "../../assets/images/cream.svg";
import Button from 'react-bootstrap/Button';
import Collapse from 'react-bootstrap/Collapse';
import {NavLink} from "react-router-dom";

export default function StakingPlatform(){
    const [open, setOpen] = useState(false);
    return(
       <>
        <section className='section staking-platform'>
          <div className='container'>
             <div className='section-top-heading-naviagte mt-3 mt-lg-0'>
                <button className='navigate-btn'><NavLink to='/staking/stake'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button>
                <div className="section-heading">
                      <h3 className="section-title-token">Select a Staking Platform</h3>
                </div>
             </div>

             <div className='staking-platform-sec mt-5'>
                <div className='staking-platform-sec-top mb-4'>
                     <img src={eth1} alt="" />
                     <p className='mb-0 ms-3 me-2'>Ethereum</p>
                     <IoIosArrowDown className='stakeing-platform-icon'/>
                </div>
                <div className='staking-platform-box'>
                    <div className='staking-platform-box-top'> 
                       <div className='staking-platform-box-top-text'>
                           <img src={stakingicon1} alt="" />
                           <p className='mb-0 ms-2'>Cream Finance</p>
                       </div>
                       {/* <form action="/"> */}
                           <div className="form-check">
                             <input className="form-check-input staking-plfrm-radio" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
                             {/* <label className="form-check-label" for="flexRadioDefault1">
                               Default radio
                             </label> */}
                           </div>
                        {/* </form> */}
                    </div>
                    <div className='staking-platform-box-mid mt-3'>
                        <p className='mb-0'>C.R.E.A.M. Finance is a blockchain agnostic, decentralized peer to peerlending platform
                             based on a fork of Compound Finance. C.R.E.A.M. bridges  
                        </p>
                        <Button  onClick={() => setOpen(!open)}   aria-controls="example-collapse-text"  aria-expanded={open} className="staking-pltfrm-expand" >
                          Expand <MdKeyboardArrowDown className='staking-pltfrm-expand-icon'/>
                        </Button>
                        <Collapse in={open}>
                          <div id="example-collapse-text staking-pltfrm-expand-text">
                              <p>liquidity across underserved assets by providing algorithmic money markets to these underserved assets.</p>
                          </div>
                        </Collapse>
                    </div>
                    <hr className='section-border-color' />
                    <div className='staking-platform-box-bottom'>
                        <div className='row text-center'>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Fees</h5>
                                <h4 className='font-styl mb-0'>10%</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Earn</h5>
                                <h4 className='font-styl mb-0'>9.86%</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Stakers</h5>
                                <h4 className='font-styl mb-0'>155</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>TLV</h5>
                                <h4 className='font-styl mb-0'>$566.21M</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='staking-platform-box'>
                    <div className='staking-platform-box-top'> 
                       <div className='staking-platform-box-top-text'>
                           <img src={stakingicon1} alt="" />
                           <p className='mb-0 ms-2'>Stake DAO</p>
                       </div>
                       {/* <form action="/"> */}
                           <div className="form-check">
                              <input className="form-check-input staking-plfrm-radio" type="radio" name="flexRadioDefault" id="flexRadioDefault2"/>
                              {/* <label className="form-check-label" for="flexRadioDefault2">
                                Default checked radio
                              </label> */}
                            </div>
                        {/* </form> */}
                    </div>
                    <div className='staking-platform-box-mid mt-3'>
                        <p className='mb-0'>Stake DAO is a trusted Proof-of-Stake infrastructure provider and validator to comfortably stake your coins and earn rewards with Livepeer, Idex, Tezos,
                        </p>
                        <Button  onClick={() => setOpen(!open)}   aria-controls="example-collapse-text"  aria-expanded={open} className="staking-pltfrm-expand" >
                          Expand <MdKeyboardArrowDown className='staking-pltfrm-expand-icon'/>
                        </Button>
                        <Collapse in={open}>
                          <div id="example-collapse-text staking-pltfrm-expand-text">
                              <p> Ethereum, Kyber Network, 0x, Polygon, undefined, Solana, and Harmony. </p>
                          </div>
                        </Collapse>
                    </div>
                    <hr className='section-border-color' />
                    <div className='staking-platform-box-bottom'>
                        <div className='row text-center'>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Fees</h5>
                                <h4 className='font-styl'>10%</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Earn</h5>
                                <h4 className='font-styl'>9.86%</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Stakers</h5>
                                <h4 className='font-styl'>155</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>TLV</h5>
                                <h4 className='font-styl'>$566.21M</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='staking-platform-box'>
                    <div className='staking-platform-box-top'> 
                       <div className='staking-platform-box-top-text'>
                           <img src={stakingicon1} alt="" />
                           <p className='mb-0 ms-2'>Rocket Pool</p>
                       </div>
                       {/* <form action="/"> */}
                       <div className="form-check">
                              <input className="form-check-input staking-plfrm-radio" type="radio" name="flexRadioDefault" id="flexRadioDefault3" />
                              {/* <label className="form-check-label" for="flexRadioDefault2">
                                Default checked radio
                              </label> */}
                            </div>
                        {/* </form> */}
                    </div>
                    <div className='staking-platform-box-mid mt-3'>
                        <p className='mb-0'>Rocket Pool is a trusted Proof-of-Stake infrastructure provider and validator to comfortably stake your coins and earn rewards with Ethereum. 
                        </p>
                        <Button  onClick={() => setOpen(!open)}   aria-controls="example-collapse-text"  aria-expanded={open} className="staking-pltfrm-expand" >
                          Expand <MdKeyboardArrowDown className='staking-pltfrm-expand-icon'/>
                        </Button>
                        <Collapse in={open}>
                          <div id="example-collapse-text staking-pltfrm-expand-text">
                              <p>...</p>
                          </div>
                        </Collapse>
                    </div>
                    <hr className='section-border-color' />
                    <div className='staking-platform-box-bottom'>
                        <div className='row text-center'>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Fees</h5>
                                <h4 className='font-styl'>10%</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Earn</h5>
                                <h4 className='font-styl'>9.86%</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>Stakers</h5>
                                <h4 className='font-styl'>155</h4>
                            </div>
                            <div className='col staking-platform-box-bottom-text'>
                                <h5 className='grey'>TLV</h5>
                                <h4 className='font-styl'>$566.21M</h4>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
          </div>
        </section>
       </>
    )
}