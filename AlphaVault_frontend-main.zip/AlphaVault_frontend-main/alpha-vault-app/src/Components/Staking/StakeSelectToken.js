import React from 'react';
import '../../App.css'
import '../Staking/Staking.css'
import '../../mobileApp.css';
import { IoSearchOutline } from "react-icons/io5";
import  tether from "../../assets/images/tether.svg";
import  usdcoin from "../../assets/images/usdcoin.png";
import  aave from "../../assets/images/aave.png";
import  swash from "../../assets/images/swash.png";
import { MdArrowBackIosNew } from "react-icons/md";
import  eth from "../../assets/images/ethereum1.svg";
import {NavLink} from "react-router-dom";

export default function StakeSelectToken(){

    return(
       <>
     <section className='section select-token-sec'>
           <div className='container'>
              <div className='section-top-heading-naviagte s-token-mobile-n'>
              <button className='navigate-btn'><NavLink to='/staking/stake'><MdArrowBackIosNew className='naviagte-arrow-icon'/></NavLink></button>
                 <div className="section-heading">
                       <h3 className="section-title-token">Select a token</h3>
                 </div>
              </div>
              <div className='alphavault-sec-box select-token-p-box'>
                <div className='seacrhcoin-box'>
                   <form className="select-token-search-box">
                        <IoSearchOutline className="select-token-search-alpha" />
                        <input className="form-control select-token-seach-plchldr" type="search" placeholder="Search by name" aria-label="Search" />
                  </form>
                   <p className='mt-5 text-end mb-0'>Available Balance for Staking</p>
                </div>
                  <hr className='section-border-color select-token-border' />
            
               <div className='select-token-details s-t-padding'>
                  <div className="select-token-details-box mb-4">
                     <div className="select-token-details-box-left">
                       <button className='selct-token-btn'><img src={eth} alt="" className="me-4" /></button>
                        <div className="select-token-text">
                        <button className='selct-token-btn'> <h6 className="text-capitalize">Ethereum</h6></button>
                         <h6 className="mb-0 grey text-uppercase">ETH</h6>
                        </div>
                     </div>
                     <div className="select-token-details-box-right">
                      <h5>0.1020564</h5>
                      <h6 className='mb-0 grey'>$1,300.78</h6>
                     </div>
                   </div>
                   <div className="select-token-details-box mb-4 disable-box">
                     <div className="select-token-details-box-left">
                     <button className='selct-token-btn'><img src={aave} alt="" className="me-4" /></button>
                        <div className="select-token-text">
                        <button className='selct-token-btn'><h6 className="text-capitalize">AAVE</h6></button>
                         <h6 className="mb-0 grey text-uppercase">Aave</h6>
                        </div>
                     </div>
                     <div className="select-token-details-box-right">
                     <h5>0.1020564</h5>
                     <h6 className='mb-0 grey'>$1,300.78</h6>
                     </div>
                   </div>
                  <div className="select-token-details-box mb-4 disable-box">
                     <div className="select-token-details-box-left">
                        <button className='selct-token-btn'><img src={tether} alt="" className="me-4" /></button>
                        <div className="select-token-text">
                           <button className='selct-token-btn'><h6 className="text-capitalize">Tether</h6></button>
                            <h6 className="mb-0 grey text-uppercase">USDT</h6>
                        </div>
                     </div>
                     <div className="select-token-details-box-right">
                       <h5>0.1020564</h5>
                       <h6 className='mb-0 grey'>$1,300.78</h6>
                     </div>
                  </div>
                  <div className="select-token-details-box mb-4">
                    <div className="select-token-details-box-left">
                    <button className='selct-token-btn'> <img src={usdcoin} alt="" className="me-4" /></button>
                       <div className="select-token-text">
                       <button className='selct-token-btn'><h6 className="text-capitalize">USD Coin</h6></button>
                        <h6 className="mb-0 grey text-uppercase">USDC</h6>
                       </div>
                    </div>
                    <div className="select-token-details-box-right">
                    <h5>0.1020564</h5>
                    <h6 className='mb-0 grey'>$1,300.78</h6>
                    </div>
                  </div>
                  <div className="select-token-details-box">
                    <div className="select-token-details-box-left">
                    <button className='selct-token-btn'><img src={swash} alt="" className="me-4" /></button>
                       <div className="select-token-text">
                       <button className='selct-token-btn'><h6 className="text-capitalize">SWASH</h6></button>
                        <h6 className="mb-0 grey text-uppercase">SWASH</h6>
                       </div>
                    </div>
                    <div className="select-token-details-box-right">
                     <h5>0.1020564</h5>
                     <h6 className='mb-0 grey'>$1,300.78</h6>
                    </div>
                  </div>
               </div>
               </div>

           </div>
           
        </section>
       </>
    )
}