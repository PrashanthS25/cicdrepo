/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React from 'react'
import '../../App.css'
import '../Vaults/Vaults.css'
import '../../mobileApp.css';
import Table from 'react-bootstrap/Table';
import  avlanche from "../../assets/images/avlanche.svg";
import  polygon from "../../assets/images/polygon.svg";
import  bitcoin from "../../assets/images/bitcoin.png";
import  ethereum1 from "../../assets/images/ethereum1.png";
import  Algorand from "../../assets/images/algorand.svg";
import  mimble from "../../assets/images/mimble.svg";
import  polkadot from "../../assets/images/polkadot.svg";
import { MdArrowBackIosNew} from "react-icons/md";
import { NavLink } from 'react-router-dom';
export default function TransactionHistory(){
   return(
      <>
        <section className='section transaction-histoty'>
            <div className='container'>
            <div className='section-top-heading-naviagte mt-3 mt-lg-0'>
              <button className='navigate-btn'><NavLink to="/predefinedvault"><MdArrowBackIosNew className='naviagte-arrow-icon me-5'/></NavLink></button>
                 <div className="section-heading">
                       <h3 className="section-title">Transaction History</h3>
                 </div>
              </div>
                <div className='alpha-vaults-section-table predefined-aplha-tran-hstry'>
                <h6 className="mobile-txn-h text-center">Transaction History</h6>
                <p className='text-center'>Apr 25, 2020, 11:48:00 AM (IST)</p>
                <Table responsive="lg" className='transaction-hstry-table'>
                   <thead className='transaction-histoty-table-heading '>
                     <tr>
                       <th>Token</th>
                       <th className='txn-hstry-tbl-d'>Prevoius</th>
                       <th className='txn-hstry-tbl-d'>Current</th>
                     </tr>
                   </thead>
                   <tbody className='alpha-vaults-section-table-data txn-hstry-section-td'>
                     <tr>
                       <td className='txn-hstry-td'>
                          <div className="vault-mid-left">
                               <img src={ethereum1} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                             <div className="vault-text">
                              <h6 className="table-vault-name  text-capitalize">Ethereum</h6>
                             </div>
                          </div>
                       </td>
                       <td className='font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                     </tr>
                     <tr>
                       <td>
                           <div className="vault-mid-left">
                             <img src={bitcoin} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                              <div className="vault-text">
                               <h6 className="table-vault-name  text-capitalize">Bitcoin</h6>
                              </div>
                           </div>
                       </td>
                       <td className=' font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                     </tr>
                     <tr>
                       <td>
                           <div className="vault-mid-left">
                             <img src={avlanche} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                              <div className="vault-text">
                               <h6 className="table-vault-name  text-capitalize">Avalanche</h6>
                              </div>
                           </div>
                       </td>
                       <td className='font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                      
                     </tr>
                     <tr>
                       <td>
                          <div className="vault-mid-left">
                               <img src={mimble} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                             <div className="vault-text">
                              <h6 className="table-vault-name  text-capitalize">Chainlink</h6>
                             </div>
                          </div>
                       </td>
                       <td className=' font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                      
                     </tr>
                     <tr>
                       <td>
                          <div className="vault-mid-left">
                               <img src={polygon} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                             <div className="vault-text">
                              <h6 className="table-vault-name  text-capitalize">Polygon</h6>
                             </div>
                          </div>
                       </td>
                       <td className=' font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                  
                     </tr>
                     <tr>
                       <td>
                          <div className="vault-mid-left">
                               <img src={polkadot} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                             <div className="vault-text">
                              <h6 className="table-vault-name  text-capitalize">Polkadot</h6>
                             </div>
                          </div>
                       </td>
                       <td className='font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                     </tr>
                     <tr>
                       <td>
                          <div className="vault-mid-left">
                               <img src={Algorand} alt="" className="me-2 me-sm-3 txn-hstry-image" />
                             <div className="vault-text">
                              <h6 className="table-vault-name  text-capitalize">Algorand</h6>
                             </div>
                          </div>
                       </td>
                       <td className='font-styl txn-hstry-tbl-d table-vault-lname'>10%</td>
                       <td  className='font-styl txn-hstry-tbl-d table-vault-lname'>5%</td>
                     </tr>
                   </tbody>
                 </Table>
                </div>
            </div>
        </section>
      </>  
   )     
}

