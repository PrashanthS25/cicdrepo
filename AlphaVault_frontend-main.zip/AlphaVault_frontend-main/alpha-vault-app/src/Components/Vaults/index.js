/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { initWallet, fetchWalletResponse } from "../../redux/index";
import "../Vaults/Vaults.css";
import "../../App.css";
import "../../mobileApp.css";
import VaultTable from "./VaultTable";
import defi from "../../assets/images/defi.svg";
import meta from "../../assets/images/meta.svg";
import bluechip from "../../assets/images/bluechip.svg";
import HomeWalletInfo from "../../MobileComponents/HomeWalletInfo";
import Emitter from "../../Helper/emitter";
import Loader from "../Loader";
import API from "../../utils/Api";
import { formatValue } from "../../Helper/helperFunctions";
import { getTimeChangeFilterValue } from "../../Helper/helperFunctions";

function Vaults(props) {
  const [isLoading, setLoading] = useState(false);
  const [vaultList, setVaultList] = useState([]);
  let navigate = useNavigate();
  // const [activeTimeFilter,setActiveTimeFilter] = useState(1)
  const [activeTimeFilter2, setActiveTimeFilter2] = useState(1);
  const [vaultCoinList, setVaultCoinList] = useState([]);
  const [selectVaultMode, setSelectVaultMode] = useState(false);
  const [selectedVault, setSelectedVault] = useState(null);
  const [vaultListPeriodFilter, setVaultListPeriodFilter] = useState(1);

  useEffect(() => {
    window.scrollTo(0, 0);
    Emitter.on("setLoading", (data) => {
      // console.log("hereFit123", data.isLoading);
      
      if (!data.isLoading) {
        if (props?.chain?.networkId && props.isWalletConnected) {
          requiredChainId = props.chain.networkId;
        }
        getVaultList(requiredChainId);
        setLoading(data.isLoading);
      }
      else{
        setLoading(data.isLoading);
      }
    });
    setLoading(true);
    let requiredChainId;
    // console.log("networkIdddddddd", props.chain?.networkId);
    // console.log("isWalletConnecteddddddd", props.isWalletConnected);
    // if (props.chain?.networkId && props.isWalletConnected) {
    //   requiredChainId = props.chain.networkId;
    // } else {
    //   requiredChainId = 1;
    // }
    if (props?.chain?.networkId) {
      requiredChainId = props.chain.networkId;
    } 
    else{
      requiredChainId = 1
    }
    // console.log("requiredChainId",requiredChainId)   
    getVaultList(requiredChainId);
  }, [props.chain?.networkId]);

  const getVaultList = async (requiredChainId) => {
    try {
      let reqObj = {
        count: 20,
        type: "list",
        search_query: null,
      };

      // console.log("tim6778 ");
        let vaultListResponse = await API.post(
          "/vault/list?coinChainID=" + requiredChainId,
          reqObj
        );
        // console.log("vaultListResponse", vaultListResponse);
        if (vaultListResponse.data.length) {
          setVaultList(vaultListResponse.data);
          vaultListResponse.data.map((vaultElement) => {
            setVaultCoinList((list) => [...list, vaultElement.vaultDetails]);
          });
        } else {
          setVaultList([]);
        }
        setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const getTimeFilterClass2 = (currValue) => {
    if (activeTimeFilter2 === currValue) {
      return "btn btn-primary section-g-button1 active";
    } else {
      return "btn btn-primary section-g-button1";
    }
  };

  const getTimeFilterClass = (currValue) => {
    // console.log("filterOne",currValue ,vaultListPeriodFilter)
    if (currValue === vaultListPeriodFilter) {
      return "btn btn-primary section-g-button1 active";
    } else {
      return "btn btn-primary section-g-button1";
    }
  };

  const navigateToVaultPage = (vaultAddress) => {
    navigate("/vaultDetail?vault=" + vaultAddress);
  };
  return (
    <>
      {/* {console.log("pingHere", vaultList)} */}
      {props.coinLoader || isLoading ? (
        <Loader />
      ) : (
        <section className="alpha-vaults-section pre-in-vaults-sec">
          <div className="container">
            <HomeWalletInfo />
            {props.isWalletConnected && props.serverResponse?.vaults.length ? (
              <div className="alpha-vaults-deatails mt-4 mt-lg-0">
                <div className="section-heading">
                  <h3 className="section-title mb-4">Alpha Vaults</h3>
                </div>
                <div className="alphavault-section alphavault-sec-box pt-4 pb-2">
                  <h6 className="alphavault-box-title mb-2 mb-sm-3 text-center">
                    vaults Holdings
                  </h6>
                  <h2 className="alphavault-price mb-2 mb-sm-3 text-center">
                    ${formatValue(props.serverResponse.totalVaultBal, 2)}
                  </h2>
                  {/* <h6 className="alphavault-percent green text-center">+$560 &nbsp;+2.36%</h6> */}
                  <div className="text-center">
                    <div className="btn-group alpha-vaults-deatails-wrp mt-2 mt-sm-3 mb-2 mb-sm-3">
                      <Link
                        to="#"
                        className={getTimeFilterClass2(0)}
                        onClick={() => setActiveTimeFilter2(0)}
                        aria-current="page"
                      >
                        1hr
                      </Link>
                      <Link
                        to="#"
                        className={getTimeFilterClass2(1)}
                        onClick={() => setActiveTimeFilter2(1)}
                      >
                        1D
                      </Link>
                      <Link
                        to="#"
                        className={getTimeFilterClass2(2)}
                        onClick={() => setActiveTimeFilter2(2)}
                      >
                        1W
                      </Link>
                      <Link
                        to="#"
                        className={getTimeFilterClass2(3)}
                        onClick={() => setActiveTimeFilter2(3)}
                      >
                        1M
                      </Link>
                      <Link
                        to="#"
                        className={getTimeFilterClass2(4)}
                        onClick={() => setActiveTimeFilter2(4)}
                      >
                        2M
                      </Link>
                      <Link
                        to="#"
                        className={getTimeFilterClass2(5)}
                        onClick={() => setActiveTimeFilter2(5)}
                      >
                        3M
                      </Link>
                    </div>
                  </div>
                  <hr className="mb-2 mb-sm-3" />
                  <div className="py-2 px-4 px-sm-5">
                    {props.serverResponse.vaults.map((existingVault, index) => {
                      return (
                        <>
                          <div
                            className="vault-mid-section-box"
                            key={existingVault.coinAddress}
                          >
                            <div className="vault-mid-left">
                              <img
                                src={existingVault.coinLogo}
                                alt=""
                                className="me-3 exploreVaultTableImage"
                              />
                              <div className="vault-text">
                                <button
                                  className="select-token-d-btn d-flex"
                                  onClick={() =>
                                    navigateToVaultPage(
                                      existingVault.coinAddress
                                    )
                                  }
                                >
                                  <h6 className="vault-name  text-capitalize">
                                    {existingVault.coinName}&nbsp;
                                    <span>({existingVault.coinSymbol})</span>
                                  </h6>
                                </button>
                                <h6 className="vault-percent mb-0">
                                  {formatValue(existingVault.coinQuantity, 2)}{" "}
                                  &nbsp; &nbsp;$
                                  {formatValue(existingVault.coinPrice, 2)}
                                </h6>
                              </div>
                            </div>
                            <div className="vault-tokens-mid-right text-end">
                              <h5 className="v-t-price">
                                ${formatValue(existingVault.coinValue, 2)}
                              </h5>
                              {/* {console.log(
                                "her2Say",
                                existingVault,
                                activeTimeFilter2
                              )} */}
                              <h5
                                className={
                                  getTimeChangeFilterValue(
                                    existingVault,
                                    activeTimeFilter2
                                  ) > 0
                                    ? "staked-days green mb-0"
                                    : "staked-days red mb-0"
                                }
                              >
                                {getTimeChangeFilterValue(
                                  existingVault,
                                  activeTimeFilter2
                                )}
                                %
                              </h5>
                            </div>
                          </div>
                          {index < existingVault.length - 2 ? (
                            <hr className="section-border-color home-st-hr" />
                          ) : null}
                        </>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : (
              <></>
            )}
            <div className="alpha-vaults-section-wrp mt-5">
              <div className="vaults-top-section">
                {/* <h5 className="alphavault-sub-title pre-vaults-section-title mb-0">alpha vaults</h5> */}

                <h5 className="alphavault-sub-title pre-vaults-section-title mb-0">
                  Explore Vaults
                </h5>

                <div className="section-grp-button1">
                  <h6 className="me-3 mb-0">Filter by:</h6>
                  <div className="btn-group section-grp-button1-wrp">
                    <Link
                      className={getTimeFilterClass(0)}
                      onClick={() => {
                        setVaultListPeriodFilter(0);
                      }}
                      aria-current="page"
                    >
                      1hr
                    </Link>
                    <Link
                      className={getTimeFilterClass(1)}
                      onClick={() => setVaultListPeriodFilter(1)}
                    >
                      1D
                    </Link>
                    <Link
                      className={getTimeFilterClass(2)}
                      onClick={() => setVaultListPeriodFilter(2)}
                    >
                      1W
                    </Link>
                    <Link
                      className={getTimeFilterClass(3)}
                      onClick={() => setVaultListPeriodFilter(3)}
                    >
                      {" "}
                      1M
                    </Link>
                    <Link
                      className={getTimeFilterClass(4)}
                      onClick={() => setVaultListPeriodFilter(4)}
                    >
                      {" "}
                      2M
                    </Link>
                    <Link
                      className={getTimeFilterClass(5)}
                      onClick={() => setVaultListPeriodFilter(5)}
                    >
                      {" "}
                      3M
                    </Link>
                  </div>
                </div>
              </div>
              {/* {console.log("vaultList", vaultList)} */}
              {vaultList.length > 0 ? (
                <VaultTable
                  vaultList={vaultList}
                  vaultCoinList={vaultCoinList}
                  vaultListPeriodFilter={vaultListPeriodFilter}
                />
              ) : (
                <p className="text-center mt-3">
                  No vaults available for current network.
                </p>
              )}
            </div>
          </div>
          {/* <Link to="/predefinedvault">Next Page</Link> */}
          {/* <>
                  selectVaultMode?
                    <PredefinedVault/>
                  </> */}
        </section>
      )}
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(Vaults);
