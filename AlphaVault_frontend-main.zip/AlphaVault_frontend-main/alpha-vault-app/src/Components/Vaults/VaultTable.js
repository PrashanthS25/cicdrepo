/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useEffect } from "react";
import "../../App.css";
import "../Vaults/Vaults.css";
import "../../mobileApp.css";
import { useNavigate } from "react-router-dom";
import { BsArrowDownShort } from "react-icons/bs";
import Table from "react-bootstrap/Table";
import VaultTableMobile from "../../MobileComponents/VaultTableMobile";
import { getTimeChangeFilterValue } from "../../Helper/helperFunctions";

export default function VaultTable(props) {
  let navigate = useNavigate();

  useEffect(() => {}, [props.vaultList.length]);

  const navigateToVaultPage = (vaultAddress) => {
    navigate("/vaultDetail?vault=" + vaultAddress);
  };

  const getPriceClass = (value) => {
    return value > 0
      ? "text-center font-styl green"
      : "text-center font-styl red";
  };

  return (
    <>
      {/* {console.log("propsData", props)} */}
      <div className="mobile-vault-table-hide mt-4">
        <div className="table-responsive alpha-vaults-section-table">
          <table>
            <thead className="alpha-vaults-section-table-heading">
              <tr>
                <th className="text-center px-2">#</th>
                <th className="vault-table-width">vault</th>
                <th className="text-left">
                  <span className="idchnage">
                    <BsArrowDownShort className="fs-5" /> change
                  </span>
                </th>
                <th className="text-end">price</th>
                <th className="text-end pe-5">Total coins</th>
                <th>coins</th>
              </tr>
            </thead>
            <tbody className="alpha-vaults-section-table-data txn-hstry-td">
              {props.vaultList.length
                ? props.vaultList.map((vault, index) => {
                    return (
                      <tr key={vault.vaultAddress}>
                        <td className="text-center">{index + 1}</td>
                        <td>
                          <div className="vault-mid-left">
                            <img
                              src={props.vaultCoinList[index].coinLogoUrl}
                              alt=""
                              className="me-2 exploreVaultTableImage"
                            />
                            <div className="vault-text">
                              <button
                                className="select-token-d-btn d-flex text-start"
                                onClick={() =>
                                  navigateToVaultPage(vault.vaultAddress)
                                }
                              >
                                <h6 className="vault-name table-vault-name  text-capitalize">
                                  {vault.vaultName}&nbsp;
                                  <span>({vault.vaultSymbol})</span>
                                </h6>
                              </button>
                            </div>
                          </div>
                        </td>
                        {/* {console.log("vault45", vault)} */}
                        <td
                          className={getPriceClass(
                            getTimeChangeFilterValue(
                              props.vaultCoinList[index],
                              props.vaultListPeriodFilter
                            )
                          )}
                        >
                          {getTimeChangeFilterValue(
                            props.vaultCoinList[index],
                            props.vaultListPeriodFilter
                          ).toFixed(2)}
                          %
                        </td>
                        <td className="font-styl text-end">
                          ${props.vaultCoinList[index].coinPrice.toFixed(2)}
                        </td>
                        <td className="text-end pe-5">
                          {vault.vaultCoins.length}
                        </td>
                        <td>
                          <div className="vault-mid-right">
                            {vault.vaultCoins.length
                              ? vault.vaultCoins.map((vaultCoin, index2) => {
                                  if (index2 <= 2) {
                                    return (
                                      <img
                                        src={vaultCoin.coinLogoUrl}
                                        className="me-2 alpha-vaults-tble-icon"
                                        alt=""
                                      />
                                    );
                                  } else {
                                    return;
                                  }
                                })
                              : null}

                            {vault.vaultCoins.length > 3 ? (
                              <p>+{vault.vaultCoins.length - 3}</p>
                            ) : (
                              <p>0</p>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                : null}
            </tbody>
          </table>
        </div>
      </div>

      <VaultTableMobile
        vaultListPeriodFilter={props.vaultListPeriodFilter}
        vaultList={props.vaultList}
        navigateToVaultPage={navigateToVaultPage}
      />
    </>
  );
}
