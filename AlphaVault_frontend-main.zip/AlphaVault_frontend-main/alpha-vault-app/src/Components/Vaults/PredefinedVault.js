/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useState,useEffect} from 'react'
import '../Vaults/Vaults.css'
import '../../App.css'
import '../../mobileApp.css';
import {connect} from 'react-redux'
import {initWallet,fetchWalletResponse} from '../../redux/index'
import TradingViewChart from '../Home/TradingViewChart';
import { MdArrowBackIosNew , MdArrowForwardIos} from "react-icons/md";
import  tablemeta from "../../assets/images/tablemeta.svg";
import  graph from "../../assets/images/graph.png";
import {Link, NavLink, useNavigate,useSearchParams} from "react-router-dom";
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import {formatValue, getTimeChangeFilterValue} from '../../Helper/helperFunctions'
import {selectVault} from '../../redux/index'
import Loader from '../Loader';
import API from '../../utils/Api'
import Popover from 'react-bootstrap/Popover';
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Button from 'react-bootstrap/Button';
// import TransactionHistory from '../Vaults/TransactionHistory';

function PredefinedVault(props){
   // const [timePeriod,setTimePeriod] = useState(1)
   const [activeTimeFilter,setActiveTimeFilter] = useState(1)
   const [activeTimeFilter2,setActiveTimeFilter2] = useState(1)
   const [activeTimeFilter3,setActiveTimeFilter3] = useState("1h")
   const [vaultDetail,setVaultDetail] = useState(null)
   const [investmentDetails,setInvestmentDetails] = useState(null)
   const [isLoading,setLoading] = useState(false)
   let navigate = useNavigate();
   const [searchParams, setSearchParams] = useSearchParams()
   useEffect(()=>{
      let queryParams = searchParams.get('vault')
      // console.loglog("queryParams",queryParams)
      if(queryParams){
        setLoading(true)
        getVaultInfo(queryParams,(props.chain?.networkId?props.chain?.networkId:1))
      }
   },[props.chain?.networkId])

   const getVaultInfo = async(vaultAddress,coinChainId)=>{
      try{
        let vaultInfo = await API.post('/vault?coinChainId='+coinChainId,{vaultAddress})
        // console.loglog("vaultInfo",vaultInfo)
         if(vaultInfo.data){
            setVaultDetail(vaultInfo.data)
        }
        setLoading(false)
      }
      catch(error){
          // console.loglog(error)
          setLoading(false)
      }  
   }
   

   const getTimeFilterClass = (currValue) =>{
      if(activeTimeFilter === currValue){
         return 'btn btn-primary predefined-section-g-button active'
      }  
      else{
         return 'btn btn-primary predefined-section-g-button'
      }
   }

   const getTimeFilterClass2 = (currValue) =>{
      if(activeTimeFilter2 === currValue){
         return 'btn btn-primary section-g-button1 active'
      }  
      else{
         return 'btn btn-primary section-g-button1'
      }
   }

   const getTimeFilterClass3 = (currValue) =>{
      if(activeTimeFilter3 === currValue){
         return 'btn btn-primary section-g-button1 active'
      }  
      else{
         return 'btn btn-primary section-g-button1'
      }
   }

   const getPercChangeClass = (value) =>{
     return  parseFloat(value)<0? "red":"green" 
      }

   const selectVaultProcess = (requiredVault,txType) =>{
         props.selectVault({vault:requiredVault,mode:txType})
         navigate('/buysellvaults')
   }   

   const checkVaultisInvested = (investedVaultList) =>{
      if(!investedVaultList){
         return false
      }

      if(!investedVaultList.length){
         return false
      }
      // console.loglog("checkVaultisInvestedCheck1")
      let investmentDetails =  investedVaultList.find((vault,index)=>{
         // console.loglog("checks",vault.coinAddress,vaultDetail.vaultDetails.coinAddress)
         if(vault.coinAddress === vaultDetail.vaultDetails.coinAddress){
            // setInvestmentDetails(vault)
            // console.loglog("setInvestmentDetails",vault)
            return vault
         }
         // else{
         //    return false
         // }
      })
      // console.loglog("investmentStatus",investmentDetails)
      return investmentDetails
   }

   return(
      <>
      {
         // console.loglog("her1Props",props)
      }
      {
         (isLoading|| !vaultDetail)?
         <Loader/>
         :
      <div className='section'>
         <section className='vaults detail-section'>
           <div className='container'>
              <div className='section-top-heading-naviagte  mt-3 mt-lg-0'>
              <button className='navigate-btn' onClick={()=>{navigate(-1)}}><MdArrowBackIosNew className='naviagte-arrow-icon'/></button>
                 <div className="section-heading">
                       <h3 className="section-title">vault details</h3>
                 </div>
              </div>

              <div className="alphavault-sec-box py-4 predefined-v-m">
                   <div className="vault-mid-left justify-content-center">
                      <img src={vaultDetail.vaultDetails.coinLogoUrl} alt="" className="me-2 exploreVaultTableImage" />
                       <div className="vault-text">
                        <h5 className="pre-vault-name  text-capitalize mb-0">{vaultDetail.vaultName}&nbsp;<span className='grey'>({vaultDetail.vaultSymbol})</span></h5>
                       </div>
                   </div>
                    <h6 className=" text-center mb-3 mt-3 mt-sm-4 mb-sm-4">${vaultDetail.vaultDetails.coinPrice.toFixed(2)} &nbsp; <span className={parseFloat(vaultDetail.vaultDetails.percent_change_24h)<0?"predefined-vault-price-minus":"predefined-vault-price-plus"} >{vaultDetail.vaultDetails.percent_change_24h.toFixed(2)}%</span></h6>
                    <hr className='section-border-color' />
                    <p className='section-p mb-0'>{vaultDetail.vaultDescription}</p>
              </div>
               </div>
         </section> 

         {
         props.isWalletConnected&&props.serverResponse?.vaults.length&& checkVaultisInvested(props.serverResponse?.vaults)?      
         <section className='vaults detail-section mt-4 mb-4'>
            {/* {
               // console.loglog("InVault123",vaultDetail,props.selectVault,investmentDetails)
            } */}
           <div className='container'>
              <div className="alphavault-sec-box py-4 py-sm-5">
                   <div className="vault-mid-left justify-content-center">
                      <img src={vaultDetail.vaultDetails.coinLogoUrl} alt="" className="me-2" />
                       <div className="vault-text">
                        <h5 className="pre-vault-name  text-capitalize mb-0">{vaultDetail.vaultName}&nbsp;<span className='grey'>({vaultDetail.vaultSymbol})</span></h5>
                        
                       </div>
                   </div>
                   <h6 className='mt-3 grey text-center pre-v-b'>{formatValue(checkVaultisInvested(props.serverResponse?.vaults).coinQuantity,2)}</h6>
                   <h3 className="alphavault-price pre-price mb-3 text-center">${formatValue(checkVaultisInvested(props.serverResponse?.vaults).coinValue,2)}</h3>
                    <h6 className="predefined-vault-price text-center mb-3 mt-3 mt-sm-4 mb-sm-4">&nbsp; <span className={getTimeChangeFilterValue(vaultDetail.vaultDetails,activeTimeFilter2)>0?"staked-days green mb-0":"staked-days red mb-0"}>{getTimeChangeFilterValue(vaultDetail.vaultDetails,activeTimeFilter2)}%</span></h6>
                    <div className='text-center'>
                     <div className="btn-group alpha-vaults-deatails-wrp mt-3 mb-3">
                     <Link  className={getTimeFilterClass2(0)} onClick={()=>setActiveTimeFilter2(0)} aria-current="page">1hr</Link>
                       <Link    className={getTimeFilterClass2(1)} onClick={()=>setActiveTimeFilter2(1)}>1D</Link>
                       <Link    className={getTimeFilterClass2(2)} onClick={()=>setActiveTimeFilter2(2)}>1W</Link>
                       <Link    className={getTimeFilterClass2(3)} onClick={()=>setActiveTimeFilter2(3)}>1M</Link>
                       <Link    className={getTimeFilterClass2(4)} onClick={()=>setActiveTimeFilter2(4)}>60D</Link>
                       <Link    className={getTimeFilterClass2(5)} onClick={()=>setActiveTimeFilter2(5)}>90D</Link>
                     </div>
                  </div>
                  <div className='predefined-vault-token-details d-flex text-center justify-content-evenly mt-4'>
                     <div className='predefined-vault-token-detail-box '>
                        <h5 className='grey'>Total Tokens</h5>
                        <h4 className='mb-0'>{vaultDetail.vaultDetails.max_supply}<span className='grey'>{vaultDetail.vaultSymbol}</span></h4>
                     </div>
                     <div className='predefined-vault-token-detail-box'>
                        <h5 className='grey'>Price Per Token</h5>
                        <h4 className='mb-0'>${formatValue(vaultDetail.vaultDetails.coinPrice,2)}</h4>
                     </div>
                  </div>
               </div>
                <div className='section-btn text-center mt-4'>
                   <button type="button" className="btn btn-light topup-btn" onClick={()=>selectVaultProcess(vaultDetail,'buy')}>Top up</button >
                   <button type="button" className="btn btn-light sell-btn" onClick={()=>selectVaultProcess(checkVaultisInvested(props.serverResponse?.vaults),'sell')}>Sell</button >
                </div>
             </div>
         </section>
         :
         <div className='section-btn text-center mt-4'>
                   <button type="button" className="btn  invest-button" onClick={()=>selectVaultProcess(vaultDetail,'buy')}>invest in vault</button >
         </div> 
         }

         <section className='trading-view-chart'>
             <div className='container'>
                <div className="alphavault-section alphavault-sec-box text-center pt-4 pb-4">
                      <div className="alphavault-graph">
                      <TradingViewChart graphInterval={activeTimeFilter3} coinAddress={vaultDetail.vaultDetails.coinAddress} coinChainID={props.chain?.networkId} coinMarketCapId={vaultDetail.vaultDetails.coinCMC_Id}/>
                      </div>
                      <div className='text-center'>
                     <div className="btn-group section-grey-btn-bg mt-4">
                       <Link  className={getTimeFilterClass3("1h")} onClick={()=>setActiveTimeFilter3("1h")} aria-current="page">1hr</Link>
                       <Link    className={getTimeFilterClass3("1d")} onClick={()=>setActiveTimeFilter3("1d")}>1D</Link>
                       <Link    className={getTimeFilterClass3("7d")} onClick={()=>setActiveTimeFilter3("7d")}>1W</Link>
                       <Link    className={getTimeFilterClass3("1m")} onClick={()=>setActiveTimeFilter3("1m")}>1M</Link>
                       <Link    className={getTimeFilterClass3("3m")} onClick={()=>setActiveTimeFilter3("3m")}>3M</Link>
                       <Link    className={getTimeFilterClass3("1y")} onClick={()=>setActiveTimeFilter3("1y")}>1Y</Link>
                     </div>
                  </div>
                </div>
             </div>
         </section>
         <section className='predefined-details mt-4 mt-sm-5'>
            <div className='container'>
              <h5 className="alphavault-sub-title  mb-sm-4 pre-mob-descp-hide">details</h5>
              <h5 className="alphavault-sub-title  mb-sm-4 pre-mob-descp">Description</h5>
              <div className='alphavault-sec-box prde-details-box'>
               <p className='predefined-para'>
                  The metaverse bucket is designed to give exposure to the trending crypto currencies projects in metaverse. These allocations are 
                  weighted by market cap and rebalanced.
               </p>
               <div className='details-content'>
                  <div className='d-flex align-items-center'>
                  <p className='details-c-left mb-0'>Buy Type:</p>
                  <sup>  
                     {['top'].map((placement) => (
                        <OverlayTrigger
                          
                          key={placement}
                          placement={placement}
                          overlay={
                            <Popover id={`popover-positioned-${placement}`}>
                              <Popover.Body>
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                 temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                  nesciunt harum consectetur impedit amet suscipit ducimus id!
                              </Popover.Body>
                            </Popover>
                          }
                        >
                           <Button variant="secondary" className='stake-i-button ms-2 predefined-i-btn'>!</Button>
                        </OverlayTrigger>
                      ))}
                    </sup>
                  </div>
                  <p className='details-c-right mb-0'>{vaultDetail.vaultBuytype}</p>
               </div>
               <hr className='section-border-color' />
               <div className='details-content'>
                  <div className='d-flex align-items-center'>
                     <p className='details-c-left mb-0'>Strategy:</p>
                     <sup>  
                     {['top'].map((placement) => (
                        <OverlayTrigger
                          
                          key={placement}
                          placement={placement}
                          overlay={
                            <Popover id={`popover-positioned-${placement}`}>
                              <Popover.Body>
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                 temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                  nesciunt harum consectetur impedit amet suscipit ducimus id!
                              </Popover.Body>
                            </Popover>
                          }
                        >
                           <Button variant="secondary" className='stake-i-button ms-2 predefined-i-btn'>!</Button>
                        </OverlayTrigger>
                      ))}
                    </sup>
                  </div>
                 
                  <p className='details-c-right mb-0'>{vaultDetail.vaultStrategy}</p>
               </div>
               <hr className='section-border-color' />
               <div className='details-content'>
                 <div className='d-flex align-items-center'>
                    <p className='details-c-left mb-0'>Rebalancing:</p>
                    <sup>  
                     {['top'].map((placement) => (
                        <OverlayTrigger
                          
                          key={placement}
                          placement={placement}
                          overlay={
                            <Popover id={`popover-positioned-${placement}`}>
                              <Popover.Body>
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                 temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                  nesciunt harum consectetur impedit amet suscipit ducimus id!
                              </Popover.Body>
                            </Popover>
                          }
                        >
                           <Button variant="secondary" className='stake-i-button ms-2 predefined-i-btn'>!</Button>
                        </OverlayTrigger>
                      ))}
                    </sup>
                  </div>
                    <p className='details-c-right mb-0'>{vaultDetail.vaultRebalancing?'ACTIVE':'INACTIVE'}</p>
               </div>
               <hr  className='section-border-color' />
               <div className='details-content'>
                  <div className='d-flex align-items-center'>
                    <p className='details-c-left mb-0'>Hold Term:</p>
                    <sup>  
                     {['top'].map((placement) => (
                        <OverlayTrigger
                          
                          key={placement}
                          placement={placement}
                          overlay={
                            <Popover id={`popover-positioned-${placement}`}>
                              <Popover.Body>
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit
                                . Nisi soluta laudantium cumque, delectus illum, voluptatum
                                 temporibus asperiores, fugit ipsum eligendi voluptatem nulla
                                  nesciunt harum consectetur impedit amet suscipit ducimus id!
                              </Popover.Body>
                            </Popover>
                          }
                        >
                           <Button variant="secondary" className='stake-i-button ms-2 predefined-i-btn'>!</Button>
                        </OverlayTrigger>
                      ))}
                    </sup>
                  </div>
                    <p className='details-c-right mb-0'>{vaultDetail.vaultHoldterm}</p>
               </div>
              </div>
            </div>
         </section>
         <section className='predefined-coins-sec mt-4 mt-sm-5'>
            <div className='container'>
            <div className="vaults-top-section">
              <h5 className="alphavault-sub-title predefined-coins-title mb-0">coins &nbsp;&nbsp;<span className='font-styl'>{vaultDetail.vaultCoins.length}</span> </h5>
              <div className="btn-group predefined-btn-wrp">
                 <Link  className={getTimeFilterClass(0)} onClick={()=>setActiveTimeFilter(0)} >1hr</Link>
                 <Link  className={getTimeFilterClass(1)} onClick={()=>setActiveTimeFilter(1)} aria-current="page">1D</Link>
                 <Link  className={getTimeFilterClass(2)} onClick={()=>setActiveTimeFilter(2)}>1W</Link>
                 <Link  className={getTimeFilterClass(3)} onClick={()=>setActiveTimeFilter(3)}>1M</Link>
                 <Link  className={getTimeFilterClass(4)} onClick={()=>setActiveTimeFilter(4)}>2M</Link>
                 <Link  className={getTimeFilterClass(5)} onClick={()=>setActiveTimeFilter(5)}>3M</Link>
               </div>
            </div>
   
            <div className='alphavault-sec-box py-4'>
                {
                  vaultDetail.vaultCoins.map((vaultCoin,index)=>{
                     return(
                        <>
                           <div className="d-flex justify-content-between predefined-coins-sec-box">
                              <div className="d-flex align-items-center predefined-coins-sec-box-left">
                              <img src={vaultCoin.coinLogoUrl} alt="" className="me-3  exploreVaultTableImage" />
                                 <div className="predefined-coins-sec-text">
                                 {/* {
                                    vaultCoin.coinTradable? */}
                                 <Link to={'/coinpage?coinAddress='+vaultCoin.coinAddress}> <h6 className="predefined-coins-sec-name text-capitalize">{vaultCoin.coinName}</h6></Link>
                                    {/* :
                                    <h6 className="predefined-coins-sec-name text-capitalize">{vaultCoin.coinName}</h6>
                                 } */}
                                 <h6 className="predefined-coins-sec-percent mb-0">${vaultCoin.coinPrice.toFixed(2)} &nbsp;<span className={getTimeChangeFilterValue(vaultCoin,activeTimeFilter)>0? 'green':'red'}>{getTimeChangeFilterValue(vaultCoin,activeTimeFilter).toFixed(2)}%</span></h6>
                                 </div>
                              </div>
                              <div className="d-flex predefined-coins-sec-box-right">
                              <h5>{vaultCoin.vaultPerc}%</h5>  
                              </div>
                           </div>
                           <hr className='section-border-color' />
                        </>
                     )
                  })
                
                }
               
            </div>
            </div>
         </section>
         <section className='predefined-transaction-history mt-4 mt-sm-5'>
            <div className='container'>
            <h5 className="alphavault-sub-title mb-4">Transaction History</h5>
            <div className='alphavault-sec-box predefined-transaction-history-box'>
               <div className='predefined-transaction-history-content d-flex justify-content-between align-items-center '>
                  <p>Apr 25, 2020, 11:48:00 AM (IST)</p>
                  <NavLink to="/predefinedvault/txhistory">
                     <MdArrowForwardIos  className="predefined-trn-hstry-side-arrow"/>
                  </NavLink>
               </div>
               <hr className='section-border-color' />
               <div className='predefined-transaction-history-content d-flex justify-content-between align-items-center'>
                   <p>Apr 25, 2020, 11:48:00 AM (IST)</p>
                   <NavLink to="/predefinedvault/txhistory">
                     <MdArrowForwardIos  className="predefined-trn-hstry-side-arrow"/>
                  </NavLink>
               </div>
               <hr className='section-border-color' />
               <div className='predefined-transaction-history-content d-flex justify-content-between align-items-center'>
                   <p>Apr 25, 2020, 11:48:00 AM (IST)</p>
                   <NavLink to="/predefinedvault/txhistory">
                     <MdArrowForwardIos  className="predefined-trn-hstry-side-arrow"/>
                  </NavLink>
               </div>
               <hr className='section-border-color' />
               <div className='predefined-transaction-history-content d-flex justify-content-between align-items-center'>
                   <p>Apr 25, 2020, 11:48:00 AM (IST)</p>
                   <NavLink to="/predefinedvault/txhistory">
                     <MdArrowForwardIos  className="predefined-trn-hstry-side-arrow"/>
                  </NavLink>
               </div>
               <hr className='section-border-color' />
               <div className='predefined-transaction-history-content d-flex justify-content-between align-items-center'>
                   <p>Apr 25, 2020, 11:48:00 AM (IST)</p>
                   <NavLink to="/predefinedvault/txhistory">
                     <MdArrowForwardIos  className="predefined-trn-hstry-side-arrow"/>
                  </NavLink>
               </div>
               <hr className='section-border-color' />
               <div className='predefined-transaction-history-content d-flex justify-content-between align-items-center'>
                   <p>Apr 25, 2020, 11:48:00 AM (IST)</p>
                   <NavLink to="/predefinedvault/txhistory">
                     <MdArrowForwardIos  className="predefined-trn-hstry-side-arrow"/>
                   </NavLink>
               </div>
               <hr className='section-border-color' />
               <div className='mt-4'> 
                   <Stack spacing={2}>
                     <Pagination count={12} hidePrevButton hideNextButton defaultPage={2} siblingCount={0} className='pagination-btn'/>
                   </Stack>
               </div>
             
            </div>
              
            </div>
         </section>
          
           {/* <TransactionHistory/> */}
        </div>
         }      
      </>  
   )     
}

const mapStateToProps =(state)=>{
   return {
     walletAddress: state.wallet.walletAddress,
     chain: state.wallet.chain,
     isWalletConnected: state.wallet.isWalletConnected,
     isPolicyAccepted: state.wallet.isPolicyAccepted,
     assets: state.wallet.assets,
     loader: state.wallet.loader,
     serverResponse: state.wallet.serverResponse,
     error: state.wallet.error,
     coinList: state.coins.coinList,
     coinLoader: state.coins.coinLoader,
     coinError: state.coins.coinError,
     web3InStance:state.wallet.web3InStance,
     selectedVault:state.publicVault.selectedVault 
   }
 }
 
 const mapStateToDispatch = (dispatch)=>{
   return{
     initWallet: (walletInfo) => dispatch(initWallet(walletInfo)), 
     fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
     selectVault: (vaultDetails)=>dispatch(selectVault(vaultDetails))
   }
 }
 
 export default connect(mapStateToProps,mapStateToDispatch)(PredefinedVault)


