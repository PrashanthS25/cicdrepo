/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
  useNavigate,
  NavLink,
} from "react-router-dom";
import Home from "./Components/Home";
import Vaults from "./Components/Vaults";
import CoinPage from "./Components/CoinPage";
import PaymentOption from "./Components/ConnectWallet/PaymentOption";
import ConnectWallet from "./Components/ConnectWallet";
import BuySellVaults from "./Components/BuySellVaults";
import SelectToken from "./Components/BuySellVaults/SelectToken";
import SelectVault from "./Components/BuySellVaults/SelectVault";
import Staking from "./Components/Staking";
import StakeSelectToken from "./Components/Staking/StakeSelectToken";
import Stake from "./Components/Staking/Stake";
import UnstakePlatform from "./Components/Staking/UnstakePlatform";
import UnstakeSelectToken from "./Components/Staking/UnstakeSelectToken";
import SelectDuration from "./Components/Staking/SelectDuration";
import Voting from "./Components/Voting";
import Settings from "./Components/Settings";
import Language from "./Components/Settings/Language";
import Currency from "./Components/Settings/Currency";
import Pincode from "./Components/Settings/Pincode";
import ErrorComponent from "./Components/ErrorComponent";
import CreatePassword from "./Components/Settings/CreatePassword";
import BottomNavbar from "./MobileComponents/BottomNavbar";
import MobileNavbar from "./MobileComponents/MobileNavbar";
import {
  ProSidebar,
  Menu,
  MenuItem,
  SidebarHeader,
  SidebarContent,
} from "react-pro-sidebar";
import { AiFillHome } from "react-icons/ai";
import { FiActivity, FiRepeat } from "react-icons/fi";
import { BsGraphUp } from "react-icons/bs";
import { BiSearch, BiCheckCircle } from "react-icons/bi";
import { RiArrowDownSLine, RiArrowRightSLine } from "react-icons/ri";
import { TbMessages } from "react-icons/tb";
import logo from "./assets/images/icon.svg";
import polygon from "./assets/images/polygon.svg";
import ellipse from "./assets/images/Ellipse.svg";
import metamask from "./assets/images/MetaMask.svg";
import walleticon from "./assets/images/walleticon.png";
import walleticonnect from "./assets/images/walletconnect.svg";
import bars from "./assets/images/bars.png";

import { MdArrowForwardIos, MdOutlineClose } from "react-icons/md";
import { IoWallet } from "react-icons/io5";
// import  homeactive from "./assets/images/homeactive.png";
// import  homeinactive from "./assets/images/home.png";
import { connect } from "react-redux";
import {
  initWallet,
  changeChainId,
  resetWallet,
  fetchWalletResponse,
  setActiveWallet,
  setLoaderInactive,
  setWeb3Instance,
} from "./redux/index";
import { formatAddress } from "./Helper/helperFunctions";
import PredefinedVault from "./Components/Vaults/PredefinedVault";
import TransactionHistory from "./Components/Vaults/TransactionHistory";
import SupportedCoins from "./Components/SupportedCoins";
import { netWorkConfig } from "./config/networkConfig";
import { VscDebugDisconnect } from "react-icons/vsc";
import Emitter from "./Helper/emitter";
import { useMoralis, useMoralisWeb3Api, useChain } from "react-moralis";
import './mobileApp.css'
import StakingPlatform from './Components/Staking/StakingPlatform';
import BigNumber from 'bignumber.js';

const Web3 = require("web3");
const web3 = new Web3();

// chageChainId
function App(props) {
  const [menuCollapse, setMenuCollapse] = useState(false);
  const [activeOption, setActiveOption] = useState(0);
  const [error,setError] = useState(null)
  const [activeWalletType, setActiveWalletType] = useState(
    localStorage.getItem("activeWalletType")
  );
  const [wallets, setWallets] = useState([]);
  const [activeWallet, setActiveWallet] = useState(null);
  const { user,logout, enableWeb3 } = useMoralis();
  const Web3Api = useMoralisWeb3Api();
  let navigate = useNavigate();
  let location = useLocation();
  const { switchNetwork } = useChain();

  useEffect(() => {
    connectWalletFromLocalStorage();
    configWallets();

    let requiredWallet = JSON.parse(localStorage.getItem("activeWallet"));
    if (requiredWallet) {
      setActiveWalletType(requiredWallet.type);
      setActiveWallet(requiredWallet.walletUser);
    }

    Emitter.on("SetWalletType", (walletType) => {
      setActiveWalletType(walletType.wallet);
      configWallets();
    });

    Emitter.on("newConnectionRequest", (requiredObj) => {
      configWallet(
        requiredObj.user,
        requiredObj.type,
        requiredObj.fromLocal,
        requiredObj.newConnect
      );
    });

    Emitter.on('changeNetworkFromMobile',(requiredNetwork)=>{
      // console.log("testUpdateNet2")
       updateNetwork(requiredNetwork) 
    })
  }, [props.chain?.networkId]);

  const connectWalletFromLocalStorage = () => {
    let existingUser = localStorage.getItem("WalletConnection");
    let requiredWallet = JSON.parse(localStorage.getItem("activeWallet"));
    if (existingUser && requiredWallet) {
      Emitter.emit("setLoading", { isLoading: true });
      if (requiredWallet.type === "Metamask") {
        if (requiredWallet.walletUser) {
          configWallet(requiredWallet.walletUser, "Metamask", true);
          props.setActiveWallet("Metamask");
        } else {
          //reset the setting
          Emitter.emit("setLoading", { isLoading: false });
        }
      } else {
        if (requiredWallet.walletUser) {
          configWallet(requiredWallet.walletUser, "WalletConnect", true);
          props.setActiveWallet("WalletConnect");
        } else {
          Emitter.emit("setLoading", { isLoading: false });
        }
      }
    } else {
      let connectObj = { metamask: [], walletConnect: [] };
      connectObj = JSON.stringify(connectObj);
      localStorage.setItem("WalletConnection", connectObj);
    }
  };

  const configWallets = (newWalletObj = null) => {
    let existingUser;
    if (newWalletObj) {
      existingUser = newWalletObj;
    } else {
      existingUser = JSON.parse(localStorage.getItem("WalletConnection"));
    }
    let _wallets = [];
    if (existingUser) {
      if (existingUser.metamask.length) {
        _wallets.push(...existingUser.metamask);
      }
      if (existingUser.walletConnect.length) {
        _wallets.push(...existingUser.walletConnect);
      }
    }
    setWallets(_wallets);
  };
  
  const configWallet = async (
    _user,
    walletType = null,
    fromLocal = false,
    toAddNewWallet = false,
    changeChainRequest=false
  ) => {
    try {
      Emitter.emit("setLoading", { isLoading: true });
      let _web3
      if(walletType ==='walletconnect'){
        _web3 = await enableWeb3({provider: 'walletconnect'});
      }
      else{
        _web3 = await enableWeb3(); 
      }
      let _web3_prov = new Web3(_web3.provider);
      props.setWeb3Instance(_web3_prov);
      Emitter.emit("setWeb3Obj", { web3: _web3_prov });
      Emitter.emit("setLoading", { isLoading: true });
      let _chainId = _web3._network.chainId;
      let requiredNetwork = netWorkConfig.find((e) => e.networkId === _chainId);
      props.changeChainId(requiredNetwork);
      let _address, userName;
      if (!fromLocal) {
        _address = await _user.get("ethAddress");
        userName = await _user.get("username");
      } else {
        _address = _user.accounts[0];
        userName = _user.username;
      }
      Emitter.emit("setLoading", { isLoading: true });
      let _tokenList = await Web3Api.account.getTokenBalances({
        chain: requiredNetwork.netWorkIdForMorallis,
        address: _address.toString(),
      });

    let balance = await Web3Api.account.getNativeBalance({chain: requiredNetwork.netWorkIdForMorallis,address:_address.toString()});
    _tokenList = formatNativeTokenObj(balance,_chainId, _tokenList)
    Emitter.emit('setLoading',{isLoading:true})
    props.initWallet({walletAddress:_address,userName,isWalletConnected:true,isPolicyAccepted:true,assets:_tokenList,web3InStance:_web3_prov})
  
    let coinDetails= _tokenList.map((item)=>{      
     return {
      "coin_address": item.token_address?item.token_address:"Ethereum",
      "coin_name": item.name,
      "coin_quantity":item.decimals===18?web3.utils.fromWei(item.balance, 'ether'):(new BigNumber(item.balance).dividedBy(new BigNumber(10).pow(new BigNumber(+item.decimals)))).toNumber() 
      }
    })
 
    await props.fetchWalletResponse({userAddress: _address.toString(),user_wallet_coin:coinDetails}, requiredNetwork.networkId)


      if (toAddNewWallet) {
        //logic to see if given user is already present or not
        let connections = JSON.parse(localStorage.getItem("WalletConnection"));
        let isAlreadyPresent = false;
        if (connections) {
          if (connections.metamask.length) {
            isAlreadyPresent = connections.metamask.find((e) => {
              if (e.accounts[0] === _address) {
                return true;
              } else {
                return false;
              }
            });
          }

          if (!isAlreadyPresent) {
            if (connections.walletConnect.length) {
              isAlreadyPresent = connections.walletConnect.find((e) => {
                if (e.accounts[0] === _address) {
                  return true;
                } else {
                  return false;
                }
              });
            }
          }
        }

        if (isAlreadyPresent) {
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: walletType, walletUser: _user })
          );
          Emitter.emit("SetWalletType", { wallet: walletType });
        } else {
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: walletType, walletUser: _user })
          );
          props.setActiveWallet(walletType);
          let connectObj = JSON.parse(localStorage.getItem("WalletConnection"));
          if (walletType === "Metamask") {
            connectObj.metamask.push(_user);
          } else {
            connectObj.walletConnect.push(_user);
          }
          localStorage.setItem("WalletConnection", JSON.stringify(connectObj));
          Emitter.emit("SetWalletType", { wallet: walletType });
        }
      }
      setTimeout(() => {
        Emitter.emit("setLoading", { isLoading: false });
        // console.log("lastRecord",localStorage.getItem('lastVisitedPage'))
        if(localStorage.getItem('lastVisitedPage')=== '/buysellvaults'){
                let navigationRoute = localStorage.getItem('lastVisitedPage')
                localStorage.setItem('lastVisitedPage','')
                navigate(navigationRoute)
        }
      }, 1000);
      
      if(changeChainRequest){
        Emitter.emit("setLoading", { isLoading: true });
        if(location.pathname === '/vaultDetail'){
        Emitter.emit("setLoading", { isLoading: true });
          navigate('/vaults')      
        }
      }

    } catch (error) {
      // setError(error)
      console.log(error)
      Emitter.emit("setLoading", { isLoading: false });
    }
  };

  const menuIconClick = () => {
    //condition checking to change state from true to false and vice versa
    menuCollapse ? setMenuCollapse(false) : setMenuCollapse(true);
  };

  const changeNetwork = (newNetwork) => {
    props.changeChainId(newNetwork);
  };

  const disconnectWallet = (wallet) => {
    // //console.log("logDisconnection1",wallet)
    let connections = JSON.parse(localStorage.getItem("WalletConnection"));
    // //console.log.log("connections",connections,wallet)
    let isDeleted = false;
    let requiredIndex = null;
    let walletConnector = null
    // //console.log("logDisconnection2",wallet)
    //logic to delete wallet instance from localStorage
    if (connections) {
      if (connections.metamask.length) {
        // //console.log.log("into1")
        connections.metamask.find((e, i) => {
          // //console.log.log("into12",e.accounts[0]===wallet.accounts[0])
          if (e.accounts[0] === wallet.accounts[0]) {
            requiredIndex = i;
            return i;
          } else {
            return null;
          }
        });
        // //console.log.log("into13",requiredIndex)

        if (requiredIndex !== null && requiredIndex !== undefined) {
          walletConnector = "Metamask"
          connections.metamask.splice(requiredIndex, 1);
          isDeleted = true;
        }
      }

      if (!requiredIndex && !isDeleted) {
        // //console.log.log("searchIntoWalletConnect")
        if (connections.walletConnect.length) {
          connections.walletConnect.find((e, i) => {
            if (e.accounts[0] === wallet.accounts[0]) {
              requiredIndex = i;
              return i;
            } else {
              return false;
            }
          });
        }
        if (requiredIndex !== null && requiredIndex !== undefined) {
          walletConnector = "WalletConnect"
          connections.walletConnect.splice(requiredIndex, 1);
          isDeleted = true;
        }
      }
    }
    // //console.log.log("connections",connections)
    localStorage.setItem("WalletConnection", JSON.stringify(connections));
    // //console.log("logoutLog01")
    // condition to set new Active wallet if active wallet needed to delete
    if (props.walletAddress === wallet.accounts[0]) {
      let NewActiveWallet = getNewActiveWallet(connections);
      // //console.log.log("connections1",NewActiveWallet)
      // //console.log("logoutLog11")
      if (!NewActiveWallet) {
        // //console.log("logoutLog12")
        removeWallet(walletConnector);
      } else {
        localStorage.setItem("activeWallet", JSON.stringify(NewActiveWallet));
        setActiveWalletType(NewActiveWallet.type);
        configWallet(NewActiveWallet.walletUser, null, true);
      }
    }
    configWallets(connections);
  };

  const removeWallet = async(walletConnector ) => {
    if(walletConnector === "WalletConnect"){
      localStorage.removeItem('walletconnect')
    }
    await logout();
    localStorage.removeItem("activeWallet");
    props.initWallet({
      walletAddress: null,
      chainId: null,
      isWalletConnected: false,
      isPolicyAccepted: false,
      assets: null,
    });
  };

  const getNewActiveWallet = (connections) => {
    let newElement = null;
    if (connections.metamask.length) {
      newElement = { type: "Metamask", walletUser: connections.metamask[0] };
    }

    if (connections.walletConnect.length && !newElement) {
      newElement = {
        type: "WalletConnect",
        walletUser: connections.walletConnect[0],
      };
    }
    return newElement;
  };

  //function used to connect pre-existing wallet from header and navigate user to walletConnect if it didn't connected earlier
  const connectUserWallet = () => {
    let existingUser = JSON.parse(localStorage.getItem("WalletConnection"));
    // //console.log.log("existingUser",existingUser)
    //condition to check if user object was already present
    if (
      existingUser === null ||
      existingUser === undefined ||
      existingUser === ""
    ) {
      //condition to navigate user to walletConnect page
      navigate("/connectWallet");
    } else if (
      !existingUser.metamask.length &&
      !existingUser.walletConnect.length
    ) {
      //condition to navigate user to walletConnect page
      navigate("/connectWallet");
    } else {
      // Emitter.emit('setLoading',{isLoading:true})
      // //console.log.log("ct1")
      let _activeWallet = JSON.parse(localStorage.getItem("activeWallet"));
      // //console.log.log("ct2",_activeWallet)
      setActiveWalletType(_activeWallet.type);
      if (_activeWallet) {
        if (_activeWallet?.walletUser) {
          configWallet(_activeWallet.walletUser, null, true);
        } else {
          navigate("/connectWallet");
        }
      } else {
        navigate("/connectWallet");
      }
    }
  };

  //to format the native token object
  const formatNativeTokenObj = (balanceObj, _chainId, _tokenList) => {
    if (_chainId === 56) {
      _tokenList.push({
        name: "Binance Coin",
        balance: balanceObj.balance,
        token_address:"Binance",
        decimals: 18,
      });
      return _tokenList;
    } else if (_chainId === 137 || _chainId === 80001) {
      _tokenList.push({
        name: "Polygon",
        balance: balanceObj.balance,
        token_address:"Polygon",
        decimals: 18,
      });
      return _tokenList;
    } else {
      _tokenList.push({
        name: "Ethereum",
        balance: balanceObj.balance,
        decimals: 18,
        token_address:"Ethereum",
        symbol: "ETH",
      });
      return _tokenList;
    }
  };

  //function to change wallet according to wallet
  const changeWalletUsingWalletType = (requiredWallet) => {
    let requiredWalletObj;
    Emitter.emit("setLoading", { isLoading: true });
    let existingUser = JSON.parse(localStorage.getItem("WalletConnection"));
    // //console.log.log("requiredWallet",existingUser,requiredWallet)
    let metaUser = existingUser.metamask;
    let walletConnectUser = existingUser.walletConnect;
    setActiveWalletType(requiredWallet);
    props.setLoaderActive();
    if (existingUser && (metaUser.length || walletConnectUser.length)) {
      // //console.log.log('existingCheck')
      if (requiredWallet === "Metamask") {
        // //console.log.log('MetamaskCheck')
        if (metaUser.length) {
          // //console.log.log('MetamaskCheck1')
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: "Metamask", walletUser: metaUser[0] })
          );
          configWallet(metaUser[0], "Metamask", true);
          // configWallet(metaUser[0],true)
          props.setActiveWallet("Metamask");
        } else {
          props.resetWallet();
          props.setLoaderInactive();
          props.setActiveWallet("Metamask");
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: "Metamask", walletUser: null })
          );
          Emitter.emit("setLoading", { isLoading: false });
          navigate("/connectWallet");
        }
      } else if (requiredWallet === "WalletConnect") {
        // //console.log.log('WalletConnectCheck')
        if (walletConnectUser.length) {
          // //console.log.log('WalletConnectCheck1')
          // localStorage.setItem("activeWalletType",'WalletConnect')
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({
              type: "WalletConnect",
              walletUser: walletConnectUser[0],
            })
          );
          configWallet(walletConnectUser[0], null, true);
          // Emitter.emit("connectExistingWalletconnect",{user:metaUser[0]})
          // configWallet(walletConnectUser[0],true)
          props.setActiveWallet("WalletConnect");
        } else {
          // //console.log.log('WalletConnectCheck2')
          props.resetWallet();
          props.setLoaderInactive();
          props.setActiveWallet("WalletConnect");
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: "WalletConnect", walletUser: null })
          );
          Emitter.emit("setLoading", { isLoading: false });
          navigate("/connectWallet");
        }
      }
    } else {
      props.setLoaderInactive();
      Emitter.emit("setLoading", { isLoading: false });
      navigate("/connectWallet");
    }
    Emitter.emit("setLoading", { isLoading: false });
  };

  const connectSelectedWallet = (wallet) => {
    
    let connections = JSON.parse(localStorage.getItem("WalletConnection"));
    let activeObj = { type: null, walletUser: wallet };
    let requiredIndex = null;
    if (connections) {
      if (connections.metamask.length) {
        connections.metamask.find((e, i) => {
          if (e.accounts[0].toString() === wallet.accounts[0].toString()) {
            activeObj.type = "Metamask";
            requiredIndex = i;
            return i;
          } else {
            return null;
          }
        });
      }

      if (requiredIndex == null) {
        if (connections.walletConnect.length) {
          connections.walletConnect.find((e, i) => {
            if (e.accounts[0].toString() === wallet.accounts[0].toString()) {
              activeObj.type = "WalletConnect";
              requiredIndex = i;
              return i;
            } else {
              return false;
            }
          });
        }
      }
    }
    localStorage.setItem("activeWallet", JSON.stringify(activeObj));
    setActiveWalletType(activeObj.type);
    configWallet(wallet, null, true);
  };

  //below fuction is used to change newtwork using 'switchNetwork'method of morallis hook 
  const updateNetwork = async(requiredNetwork) =>{
    Emitter.emit("setLoading", { isLoading: true });
    switchNetwork(requiredNetwork.netWorkIdForMorallis).then((status)=>{
      Emitter.emit("setLoading", { isLoading: false });
      configWallet(user,null,false,false,true);  //calling configWallet to get info of the wallet holdings for changed network
    })
    .catch((error)=>{
      Emitter.emit("setLoading", { isLoading: false });
      console.log("error",error.message)
      setError(error.message)
    })
  }
  
  let activeStyle = {
    color: "#843ea1",
  };

  let inActiveStyle = {
    color: "#000",
  };

  return (
    <>
      <div id="header">
      { error ?
            <ErrorComponent
              setError={setError}
              error={error}
            />
            :
        null    
      }      
        {/* collapsed props to change menu size using menucollapse state */}
        <ProSidebar collapsed={menuCollapse}>
          
          {/* <SidebarContent onMouseOver={menuIconClick}> */}
          <SidebarContent>
            <Menu iconShape="square" className="text-capitalize">
              <MenuItem
                active={location.pathname === "/" ? true : false}
                icon={<AiFillHome />}
                // onClick={() => setActiveOption(1)}
              >
                {" "}
                <NavLink
                  to="/"
                  style={({ isActive }) =>
                    // isActive ? activeStyle : inActiveStyle
                    isActive && location.pathname === "/"
                      ? activeStyle
                      : inActiveStyle
                  }
                >
                  Home
                </NavLink>
              </MenuItem>
              <MenuItem
                active={location.pathname === "/connectWallet" ? true : false}
                icon={<IoWallet />}
              >
                <NavLink to="/connectWallet"> my wallet</NavLink>
              </MenuItem>
              <MenuItem
                active={location.pathname === "/vaults" ? true : false}
                icon={<BsGraphUp />}
              >
                <NavLink to="/vaults">explore vaults</NavLink>
              </MenuItem>
              <MenuItem
                active={location.pathname === "/buysellvaults" ? true : false}
                icon={<FiRepeat />}
              >
                <NavLink >buy & sell vaults</NavLink>
              </MenuItem>
              <MenuItem
                active={location.pathname === "" ? true : false}
                icon={<FiActivity />}
              >
                <NavLink >stake tokens</NavLink>
              </MenuItem>
              <MenuItem
                active={location.pathname === "/voting" ? true : false}
                icon={<TbMessages />}
              >
                <NavLink >Voting</NavLink>
              </MenuItem>
            </Menu>
          </SidebarContent>
          {/* <SidebarFooter>
          <Menu iconShape="square">
            <MenuItem icon={<FiLogOut />}>Logout</MenuItem>
          </Menu>
        </SidebarFooter> */}
        </ProSidebar>
      </div>
      <header className="top-header">
        <nav className="navbar navbar-expand-sm navbar-light alphanav-desktop">
          <div className="container-fluid">
            <SidebarHeader className="text-center">
              <div className="closemenu" onClick={menuIconClick}>
                {/* changing menu collapse icon on click */}
                {menuCollapse ? (
                  // <i className="fa-solid fa-bars-staggered"></i>
                  <img src={bars} alt="" className="bars" />
                ) : (
                  <img src={bars} alt="" className="bars" />
                )}
              </div>
            </SidebarHeader>
            <a
              className="navbar-brand text-capitalize desktop-logo-text"
              href="/"
            >
              <img src={logo} alt="" className="me-2 desktop-logo" />
              alpha vault
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarTogglerDemo01"
              aria-controls="navbarTogglerDemo01"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div
              className="collapse navbar-collapse alpha-nav"
              id="navbarTogglerDemo01"
            >
              <form className="d-flex search-box">
                <BiSearch className="search-alpha" />
                <input
                  className="form-control seach-plchldr"
                  type="search"
                  placeholder="Search vaults, project etc."
                  aria-label="Search"
                />
                {/* <button className="btn btn-outline-success" type="submit">Search</button> */}
              </form>
              <ul className="navbar-nav desktop-nav text-capitalize wallet-connect-w">
                {props.isWalletConnected ? (
                  <li className="nav-item dropdown nav-box-s">
                    <a
                      className="nav-link nav-link-p"
                      href="/"
                      id="navbarDropdownMenuLink"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      <img
                        src={props.chain.networkLogo}
                        alt=""
                        className="choosenetwork-img"
                      />{" "}
                      {props.chain.networkName}{" "}
                      <RiArrowDownSLine className="choose-network-icon" />
                    </a>
                    <ul
                      className="dropdown-menu  choose-network-drpdwn alphadropdown1 alpha-menu-drpdwn"
                      aria-labelledby="navbarDropdownMenuLink"
                    >
                      <h5 className="dropdown-header text-center choose-network-drpdwn-header">
                        Choose Network
                      </h5>
                      <div className="dropdown-divider"></div>
                      {netWorkConfig.map((element, i) => {
                        return (
                          <li key={element.networkId}>
                            <div
                              className="d-flex justify-content-between align-items-center choose-network-drpdwn-li mb-4"
                            >
                              <div className="d-flex choose-network-drpdwn-left">
                                <img
                                  src={element.networkLogo}
                                  alt=""
                                  className="network-img"
                                />
                                <div className="choose-network-drpdwn-text">
                                  <h6 className="choose-network-drpdwn-1 text-capitalize mb-0">
                                    <button
                                      className="dropdown-item active"
                                      onClick={()=>updateNetwork(element)}
                                    >
                                      {element.networkName}
                                    </button>
                                  </h6>
                                  <h6 className="choose-network-drpdwn-2 text-uppercase mb-0">
                                    <button className="dropdown-item" >
                                      {element.symbol}
                                    </button>
                                  </h6>
                                </div>
                              </div>
                              {props.chain.networkId === element.networkId ? (
                                <div className="choose-network-drpdwn-right">
                                  <BiCheckCircle className="check-dropdown active" />
                                </div>
                              ) : null}
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </li>
                ) : (
                  <></>
                )}

                {props.isWalletConnected ? (
                  
                  <li className="nav-item dropdown  wallet-connect-bg nav-box-s">
                    <a
                      className="nav-link nav-link-p d-flex align-items-center"
                      href="/"
                      id="navbarDropdownMenuLink"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      {formatAddress(props.walletAddress)}
                      <img
                        src={walleticon}
                        className="walleticon-drpdown-img"
                        alt=""
                      />
                    </a>
                    <ul
                      className="dropdown-menu choose-network-drpdwn alphadropdown2 alpha-menu-drpdwn"
                      aria-labelledby="navbarDropdownMenuLink"
                    >
                      <h5 className="dropdown-header text-center choose-network-drpdwn-header">
                        Choose Another Wallet
                      </h5>
                      <div className="dropdown-divider"></div>
                      {wallets.map((wallet, i) => {
                        return (
                          <li key={i}>
                            <div className="d-flex justify-content-between align-items-center choose-network-drpdwn-li mb-4">
                              <div className="d-flex choose-network-drpdwn-left">
                                <img src={walleticon} alt="" />
                                <div
                                  className="choose-network-drpdwn-text"
                                  onClick={() => connectSelectedWallet(wallet)}
                                >
                                  <h6 className="choose-network-drpdwn-1 text-capitalize mb-0">
                                    <a className="dropdown-item active">
                                      {formatAddress(wallet.accounts[0])}
                                    </a>
                                  </h6>
                                  {/* <h6 className="choose-network-drpdwn-2 text-uppercase mb-0"><a className="dropdown-item" href="/">2.124505 ETH</a></h6> */}
                                </div>
                              </div>
                              <div className="choose-network-drpdwn-right d-flex">
                                {wallet.accounts[0] === props.walletAddress ? (
                                  <button className="btn">
                                    <BiCheckCircle className="check-dropdown active" />
                                  </button>
                                ) : null}

                                <button
                                  className="btn"
                                  onClick={() => disconnectWallet(wallet)}
                                >
                                  <VscDebugDisconnect className="disconnect-botton" />
                                </button>
                              </div>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </li>
                ) : 
                !(location.pathname === "/connectWallet") ? (
                  <li
                    className="nav-item dropdown nav-box-s connect-wallet-hover"
                    onClick={connectUserWallet}
                  >
                    <a
                      className="nav-link nav-link-p d-flex align-items-center"
                      href="/"
                      id="navbarDropdownMenuLink"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      Connect Wallet{" "}
                      <RiArrowRightSLine className="dropdown-right-icon fs-4" />
                    </a>
                    <ul
                      className="dropdown-menu  choose-network-drpdwn  wallet-connect-drpdwn alpha-menu-drpdwn"
                      aria-labelledby="navbarDropdownMenuLink"
                    >
                      <h5 class="dropdown-header text-center choose-network-drpdwn-header">
                        Choose Another Wallet
                      </h5>
                      <div class="dropdown-divider"></div>
                      {wallets.map((wallet, i) => {
                        return (
                          <li key={i}>
                            <div className="d-flex justify-content-between align-items-center choose-network-drpdwn-li mb-4">
                              <div className="d-flex choose-network-drpdwn-left">
                                <img src={walleticon} alt="" />
                                <div className="choose-network-drpdwn-text">
                                  <h6 className="choose-network-drpdwn-1 text-capitalize mb-0">
                                    <a
                                      className="dropdown-item active"
                                      href="/"
                                    >
                                      {formatAddress(wallet.accounts[0])}
                                    </a>
                                  </h6>
                                </div>
                              </div>
                            </div>
                          </li>
                        );
                      })}
                     
                    </ul>
                  </li>
                ) : null}

                {props.isWalletConnected ? (
                  <li className="nav-item dropdown nav-box-s">
                    <a
                      className="nav-link nav-link-p"
                      href="/"
                      id="navbarDropdownMenuLink"
                      role="button"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      {
                        // //console.log.log("activeWalletType",activeWalletType)
                      }
                      {activeWalletType === "Metamask" ? (
                        <img src={metamask} alt="" className="res-img" />
                      ) : (
                        <img
                          className="walletConnectIcon res-img"
                          src={walleticonnect}
                          alt=""
                        />
                      )}
                      <RiArrowDownSLine className="choose-network-icon" />
                    </a>
                    <ul
                      className="dropdown-menu wallets-dropdown alpha-menu-drpdwn"
                      aria-labelledby="navbarDropdownMenuLink"
                    >
                      <li>
                        <button
                          className="dropdown-item"
                          onClick={() =>
                            changeWalletUsingWalletType("Metamask")
                          }
                        >
                          <img src={metamask} alt="" className="res-img" />
                        </button>
                      </li>
                      <li>
                        <button
                          className="dropdown-item "
                          onClick={() =>
                            changeWalletUsingWalletType("WalletConnect")
                          }
                        >
                          <img
                            className="walletConnectIcon res-img"
                            src={walleticonnect}
                            alt=""
                          />
                        </button>
                      </li>
                    </ul>
                  </li>
                ) : (
                  <></>
                )}
              </ul>

              <div className="alpha-setting">
                <NavLink
                  to="/settings"
                  className={({ isActive }) =>
                    isActive ? "setactive" : "setinactive"
                  }
                >
                  <i className="fa-solid fa-gear settings-img-res"></i>
                </NavLink>
              </div>
            </div>
          </div>
        </nav>
      </header>

      <MobileNavbar routePath={location.pathname}/>
      <BottomNavbar routePath={location.pathname}/>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="connectWallet" element={<ConnectWallet />} />
        <Route path="vaults" element={<Vaults />} />
        <Route path="vaultDetail" element={<PredefinedVault />} />
        <Route path="buysellvaults" element={<BuySellVaults />} />
        <Route path="/buysellvaults/selecttoken" element={<SelectToken />} />
        <Route path="/buysellvaults/selectvault" element={<SelectVault />} />
        <Route path="/staking" element={<Staking />} />
        <Route path="/staking/stake" element={<Stake />} />
        <Route path="/staking/stakingplatform" element={<StakingPlatform />} />
        <Route path="/staking/stakingduration" element={<SelectDuration />} />
        <Route path="/staking/unstakeplatform" element={<UnstakePlatform />} />
        <Route
          path="/staking/unstakeselecttoken"
          element={<UnstakeSelectToken />}
        />
        <Route
          path="/staking/stakeselecttoken"
          element={<StakeSelectToken />}
        />
        {/* <Route path="/predefinedvault" element={<PredefinedVault />} /> */}
        <Route
          path="/predefinedvault/txhistory"
          element={<TransactionHistory />}
        />
        <Route path="/voting" element={<Voting />} />
        <Route path="/supportedcoins" element={<SupportedCoins />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/coinpage" element={<CoinPage />} />
        <Route path="/settings/language" element={<Language />} />
        <Route path="/settings/currency" element={<Currency />} />
        <Route path="/settings/pincode" element={<Pincode />} />
        <Route path="/paymentOptions" element={<PaymentOption />} />
        <Route path="/settings/createpassword" element={<CreatePassword />} />
      </Routes>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    walletBalance: state.wallet.walletBalance,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    activeWallet: state.wallet.activeWallet,
    chain: state.wallet.chain,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody, newtwork) =>
      dispatch(fetchWalletResponse(reqBody, newtwork)),
    changeChainId: (newChainId) => dispatch(changeChainId(newChainId)),
    setActiveWallet: (walletConnector) =>
      dispatch(setActiveWallet(walletConnector)),
    setLoaderActive: () => dispatch(setActiveWallet()),
    setLoaderInactive: () => dispatch(setLoaderInactive()),
    setWeb3Instance: (instance) => dispatch(setWeb3Instance(instance)),
    resetWallet: () => dispatch(resetWallet()),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(App);

// export default App;
