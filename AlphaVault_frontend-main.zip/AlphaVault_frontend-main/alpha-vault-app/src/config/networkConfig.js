/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
export const netWorkConfig = [
    {
        networkName:'Ethereum',
        networkId: 1,
        netWorkIdForMorallis: '0x1',
        symbol:'ETH',
        networkLogo:'https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png',
        contractAddress:'0xd29a9e75c52a5c9c60f211cff03aff506d6f348b',
        baseCurrencyAddress:'0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
    },
    // {
    //     networkName:'Goereli',
    //     networkId: 5,
    //     netWorkIdForMorallis: '0x5',
    //     symbol:'ETH',
    //     networkLogo:'https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png',
    //     contractAddress:'0xcd48a86666D2a79e027D82cA6Adf853357c70d02',
    //     baseCurrencyAddress:'0xb4fbf271143f4fbf7b91a5ded31805e42b2208d6'
    // },
    {
        networkName:'BSC',
        networkId: 56,
        netWorkIdForMorallis: '0x38',
        symbol:'BNB',
        networkLogo:'https://s2.coinmarketcap.com/static/img/coins/64x64/1839.png',
        contractAddress:'0xd29a9e75c52a5c9c60f211cff03aff506d6f348b',
        baseCurrencyAddress:'0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'
    },
    {
        networkName:'Polygon(Matic)',
        networkId: 137,
        netWorkIdForMorallis: '0x89',
        symbol:'MATIC',
        networkLogo:'https://s2.coinmarketcap.com/static/img/coins/64x64/3890.png',
        contractAddress:'0xfbfed8a575780e9212b248c0c10d25b61e4d7e54',
        baseCurrencyAddress:'0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270'  
    },
    // {
    //     networkName:'Arbitrum One',
    //     networkId: 42161,
    //     netWorkIdForMorallis: '0xa4b1',
    //     symbol:'AETH',
    //     networkLogo:'https://arbiscan.io/images/svg/brands/arbitrum.svg?v=1.3',
    // },
    // {
    //     networkName:'Avalanche C-Chain',
    //     networkId: 43114,
    //     netWorkIdForMorallis: '0xa86a',
    //     symbol:'AVAX',
    //     networkLogo:'https://s2.coinmarketcap.com/static/img/coins/64x64/5805.png',
    //     contractAddress:'0x6332804117b6d58d59193B7B911e50D92133D228',
    //     baseCurrencyAddress:'0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7'
    // },
    // {    
    //     networkName: "Fantom",
    //     networkId: 250,
    //     netWorkIdForMorallis: '0xfa',
    //     symbol:'FTM',
    //     networkLogo:'https://s2.coinmarketcap.com/static/img/coins/64x64/3513.png'
    // }
] 