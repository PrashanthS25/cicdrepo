/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import {FETCH_COINS_REQUEST,FETCH_COINS_SUCCESS,FETCH_COINS_ERROR} from './coinsActionTypes'
import API from '../../utils/Api'

export const fetchCoinsRequest = () =>{
    return {
        type: FETCH_COINS_REQUEST,
    }
}

export const fetchCoinsSuccess = (coinsDetails) =>{
    return {
        type: FETCH_COINS_SUCCESS,
        payload:coinsDetails
    }
}
export const fetchCoinsError = (error) =>{
    return {
        type: FETCH_COINS_ERROR,
        payload:error
    }
}

export const fetchCoins = () =>{
    return async(dispatch) =>{
        try{
        dispatch(fetchCoinsRequest)
        // console.log(reqData)
        let response = await API.get('/coin/list')
        // console.log("response",response)
        fetchCoinsSuccess(response.data)
        }
        catch(error){
            fetchCoinsError(error)
        }
    }    
}