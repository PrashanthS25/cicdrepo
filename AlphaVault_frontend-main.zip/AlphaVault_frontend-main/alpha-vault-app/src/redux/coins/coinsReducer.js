/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import {FETCH_COINS_REQUEST,FETCH_COINS_SUCCESS,FETCH_COINS_ERROR} from './coinsActionTypes'

const initialState = {
      coinList:[],
      coinLoader:false,
      coinError:null  
}

export const coinsReducer = (state=initialState,action) =>{
    switch(action.type){
        case FETCH_COINS_REQUEST: return{
            ...state,
            coinLoader:true
        }
        case FETCH_COINS_SUCCESS: return{
            ...state,
            coinLoader:false,
            coinList:action.payload,
            coinError:null
        }
        case FETCH_COINS_ERROR: return{
            ...state,
            coinLoader:false,
            coinError:action.payload
        }
        default: return state   
    }
}    