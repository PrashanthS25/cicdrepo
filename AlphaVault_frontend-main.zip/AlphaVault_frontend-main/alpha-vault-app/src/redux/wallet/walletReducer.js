import {INIT_WALLET} from './walletActionTypes'
import {FETCH_WALLET_REQUEST,FETCH_WALLET_SUCCESS,FETCH_WALLET_ERROR,CHANGE_CHAIN_ID,RESET_WALLET,SET_ACTIVE_WALLET,SET_LOADER_ACTIVE,SET_LOADER_INACTIVE,SET_WEB3_INSTANCE} from './walletActionTypes'

const initialState = {
    isWalletConnected:false,
    isPolicyAccepted:false,
    walletAddress:null,
    chain: null,
    userName:null,
    walletBalance: 0,
    assets:null,
    loader: false,
    serverResponse: null,
    error: null,
    activeWallet:null,
    web3InStance:null
}

export const walletReducer = (state=initialState,action) =>{
    switch(action.type){
        case INIT_WALLET: return{
            ...state,
            walletAddress:action.payload.walletAddress,
            userName: action.payload.userName,
            isWalletConnected:action.payload.isWalletConnected,
            isPolicyAccepted: action.payload.isPolicyAccepted,
            assets: action.payload.assets,
            web3InStance: action.payload.web3InStance
        }
        case FETCH_WALLET_REQUEST: return{
            ...state,
            loader:true
        }
        case FETCH_WALLET_SUCCESS: return{
            ...state,
            loader:false,
            serverResponse:action.payload,
            error:null
        }
        case FETCH_WALLET_ERROR: return{
            ...state,
            loader:false,
            error:action.payload
        }
        case CHANGE_CHAIN_ID: return{
            ...state,
            chain:action.payload
        }
        case SET_ACTIVE_WALLET: return{
            ...state,
            activeWallet: action.payload
        }
        case SET_LOADER_ACTIVE: return{
            ...state,
            loader:true
        }
        case SET_LOADER_INACTIVE: return{
            ...state,
            loader:false   
        }
        case SET_WEB3_INSTANCE: return{
            ...state,
             web3InStance: action.payload              
        }
        case RESET_WALLET: return{
            isWalletConnected:false,
            chain: null,
            userName:null,
            walletBalance: 0,
            assets:null,
            loader: false,
            serverResponse: null,
            error: null,
            web3InStance:null   
        }
        default: return state
    }
}