import {INIT_WALLET} from './walletActionTypes'
import {FETCH_WALLET_REQUEST,FETCH_WALLET_SUCCESS,FETCH_WALLET_ERROR,CHANGE_CHAIN_ID,RESET_WALLET,SET_ACTIVE_WALLET,SET_LOADER_ACTIVE,SET_LOADER_INACTIVE,SET_WEB3_INSTANCE} from './walletActionTypes'
import API from '../../utils/Api'
import {formatValue} from '../../Helper/helperFunctions'
import axios from 'axios'
import BigNumber from 'bignumber.js'

export const initWallet = (walletDetails) =>{
    return {
        type: INIT_WALLET,
        payload:walletDetails
    }
}

export const changeChainId = (chainId) =>{
    return {
        type: CHANGE_CHAIN_ID,
        payload:chainId
    }
}

export const fetchWalletRequest = () =>{
    return {
        type: FETCH_WALLET_REQUEST,
    }
}

export const fetchWalletSuccess = (walletDetails) =>{
    return {
        type: FETCH_WALLET_SUCCESS,
        payload:walletDetails
    }
}
export const fetchWalletError = (error) =>{
    return {
        type: FETCH_WALLET_ERROR,
        payload:error
    }
}

export const resetWallet = () =>{
    return {
        type: RESET_WALLET,
    }
}

export const setActiveWallet = (walletConnector) =>{
    return {
        type:SET_ACTIVE_WALLET,
        payload:walletConnector
    }
}

export const setLoaderActive = () =>{
    return{
        type:SET_LOADER_ACTIVE,
    }
}
//SET_LOADER_INACTIVE

export const setLoaderInactive = () =>{
    return{
        type:SET_LOADER_INACTIVE,
    }
}

export const setWeb3Instance = (instance)=>{
    return {
        type:SET_WEB3_INSTANCE,
        payload: instance       
    }
}



export const fetchWalletResponse = (reqData,networkId) =>{
    return async(dispatch) =>{
         dispatch(fetchWalletRequest)
         //console.log("connection34",reqData,networkId)

         API.post('/user/wallet?coinChainID='+ networkId,reqData)
         .then(async(response)=>{
            // dispatch(fetchWalletSuccess(response))
             //console.log("response1")               
            // dispatch(fetchWalletSuccess(response))
            let reserveQuantity = +process.env.REACT_APP_ReserveQuantityInDollard
            let totalBal =  parseFloat(response.data.data.total_wallet_balance) 
            let grandtotalWalletBal = parseFloat(response.data.data.total_balance)
            let totalVaultBal = parseFloat(response.data.data.total_index_balance)
            let assetList = response.data.data.user_wallet_coin
            let vaults= []
            let percAssetList = []
            let adjPerc = 0
            let reserveObj = {}
            //console.log("response2")
            if(assetList.length){
                //using map method to set the reserve object
                assetList.find((element,i)=>{
                    if(element.coin_address === "Ethereum"|| element.coin_address === "Binance" || element.coin_address === "Polygon"){
                        //finding total price of ether present in wallet
                        
                        let totalEtherPrice = (new BigNumber(+element.coin_quantity).multipliedBy(new BigNumber(+element.coin_price))).toNumber() 
                        let reqObj = {
                            coinName:element.coin_name,
                            coinAddress: element.coin_address,
                            coinSymbol: element.coin_symbol,
                            coinDecimal:element.coin_decimal,
                            coinPrice: element.coin_price,
                            coinLogo: element.coin_Logo,
                            coinQuantity:null,  
                            coinValue: null,
                            coinPerc:null
                        }
                        // if(+element.coin_price > 0){
                        if(totalEtherPrice < reserveQuantity){
                            reserveObj.reserveQuantity = totalEtherPrice
                            reserveObj.reservePerc = (new BigNumber(totalEtherPrice).dividedBy(new BigNumber(reserveQuantity))).multipliedBy(new BigNumber(100)).toNumber() 
                            reqObj.coinQuantity = 0 
                            reqObj.coinValue = 0
                            reqObj.coinPerc = 0
                            totalBal =0
                        }
                        else{
                            reserveObj.reserveQuantity = reserveQuantity
                            reserveObj.reservePerc = 100   
                            totalBal = (new BigNumber(totalBal).minus(new BigNumber(reserveQuantity))).toNumber()  
                            reqObj.coinQuantity = (new BigNumber(totalEtherPrice).minus(new BigNumber(reserveQuantity))).dividedBy(new BigNumber(+element.coin_price)).toNumber()
                            reqObj.coinValue = (new BigNumber(totalEtherPrice).minus(new BigNumber(reserveQuantity))).toNumber()
                            reqObj.coinPerc =((new BigNumber(+reqObj.coinValue).dividedBy(new BigNumber(totalBal))).multipliedBy(new BigNumber(100))).toNumber()
                        }
                        percAssetList.push(reqObj)
                        // }
                        
                    }
                })

                if(!reserveObj.reserveQuantity){
                    reserveObj.reserveQuantity = 0
                    reserveObj.reservePerc = 0  
                }

                //forEach method to format object for each token
                assetList.forEach((item,i)=>{
                    if(item.coin_address !== "Ethereum"&& item.coin_address !== "Binance" && item.coin_address !== "Polygon"){
                    percAssetList.push({
                       coinName:item.coin_name,
                       coinAddress: item.coin_address,
                       coinSymbol: item.coin_symbol,
                       coinQuantity:item.coin_quantity,  
                       coinDecimal:item.coin_decimal,
                       coinPrice: item.coin_price,
                       coinValue: item.coin_value,
                       coinLogo: item.coin_Logo,
                       coinPerc:totalBal? ((new BigNumber(+item.coin_value).dividedBy(new BigNumber(totalBal))).multipliedBy(new BigNumber(100))).toNumber():0
                    })
                }    
                })
                percAssetList = percAssetList.sort(function(a, b){return (+b.coinPerc- +a.coinPerc)})
            }
            else{
                    reserveObj.reserveQuantity = 0
                    reserveObj.reservePerc = 0  
            }
            if(response.data.data.user_index_coin){
                vaults= response.data.data.user_index_coin        
            }
            
            dispatch(fetchWalletSuccess({totalBal,grandtotalWalletBal,totalVaultBal,assetList:percAssetList,reserveObj,vaults}))
         })  
         .catch((error)=>{
            dispatch(fetchWalletError(error))
          })
    }
}

//103.78783665391448236556 - 10 = 93.78783665391448236556   