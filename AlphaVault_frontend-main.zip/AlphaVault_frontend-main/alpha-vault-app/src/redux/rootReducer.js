import { combineReducers } from 'redux';
import {walletReducer} from './wallet/walletReducer'
import {coinsReducer} from './coins/coinsReducer'
import {publicVaultReducer} from './publicVault/publicVaultReducer'


export const rootReducer = combineReducers({
    wallet: walletReducer,
    publicVault: publicVaultReducer,
    coins: coinsReducer
  });