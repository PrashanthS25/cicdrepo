import {SELECT_VAULT} from './publicVaultActionTypes'

const initState = {
    selectedVault: null
}


export const publicVaultReducer =(state=initState,action)=>{
    switch(action.type){
        case SELECT_VAULT: return{
            ...state,
            selectedVault:action.payload,
        }
        default:
            return state    
    }    
}
