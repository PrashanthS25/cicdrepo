import {SELECT_VAULT} from './publicVaultActionTypes'


export const selectVault = (vaultDetails) =>{
    return {
        type: SELECT_VAULT,
        payload:vaultDetails
    }
}