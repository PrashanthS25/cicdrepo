/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useState,useEffect} from 'react'
import '../../App.css'
import '../../Components/Vaults/Vaults.css'
import '../../mobileApp.css';
import API from '../../utils/Api'
import {getTimeChangeFilterValue} from '../../Helper/helperFunctions'
import Emitter from '../../Helper/emitter';


export default function VaultTableMobile(props){
  const [isLoading,setLoading] = useState(false)
  const [vaultList,setVaultList] = useState([])
  const [vaultCoinList,setVaultCoinList] = useState([])


  useEffect(()=>{
    window.scrollTo(0, 0)
    setLoading(true)
    Emitter.on('setLoading',(data)=>{
      // console.log("hereFit123",data.isLoading)
      setLoading(data.isLoading)
      if(!data.isLoading){
        // console.log("tryIt",props.isWalletConnected)
      }
    })
    // console.log("propsCheck",props)
     setVaultList(props.vaultList)
    //  getVaultList() 
    setLoading(false)
  },[])


  const getVaultList = async() =>{
    try{
      let reqObj = {
        "count":20,
        "type":"list",
        "search_query":null
    }
      let vaultListResponse = await API.post('/vault/list',reqObj)
      // console.log("vaultListResponse",vaultListResponse)     
      if(vaultListResponse.data.length){
        setVaultList(vaultListResponse.data)
        vaultListResponse.data.map((vaultElement)=>{
          setVaultCoinList((list)=>[...list,vaultElement.vaultDetails]) 
        })
      }
      if(props.isWalletConnected){
        // console.log("tryIt")
      }
      setLoading(false)  
    }
    catch(error){
      // console.log(error)
      setLoading(false)
  }  
   }

   return(
      <>
              
              {/* mobile-device vault table */}
              <div className='mobile-vault-table mt-3 mb-5'>
                {
                  vaultList.length?
                  vaultList.map((vault,index)=>{
                    return(
                  <div className='mob-vault-tbl-box' key={index}>
                    <div className='mob-vault-tbl-box-left'>
                       <img src={vault.vaultDetails.coinLogoUrl} alt="" className="me-3 mobile-v-hp-image mob-vault-tbl-box-img" />
                       <div className="vault-text">
                        <button className="select-token-d-btn d-flex" onClick={()=>props.navigateToVaultPage(vault.vaultAddress)}> <h6 className="vault-name  text-capitalize v-tbl-text">{vault.vaultName}&nbsp;<span>({vault.vaultSymbol})</span></h6></button>
                         <h6 className="vault-percent mb-0">${vault.vaultDetails.coinPrice.toLocaleString()} &nbsp; &nbsp;<span > ${getTimeChangeFilterValue(vault.vaultDetails,props.vaultListPeriodFilter).toFixed(2)}</span></h6>
                       </div>
                    </div>
                    <div className='mob-vault-tbl-box-right'>
                         {
                            vault.vaultCoins.length?
                            vault.vaultCoins.map((vaultCoin,index2)=>{                             
                                if(index2<=2){
                                  return(
                                  <img src={vaultCoin.coinLogoUrl} className="me-2 mob-vault-tbl-box-right-img"  alt="" />
                                  )
                                }
                                else{
                                  return
                                }                        
                            })
                            :
                            null
                           } 
                         {/* <p className='ms-1 mb-0 grey'>+10</p> */}
                         {
                            vault.vaultCoins.length > 3 ? 
                            <p className='ms-1 mb-0 grey'>+{(vault.vaultCoins.length-3)}</p>
                            :
                            <p className='ms-1 mb-0 grey'>0</p>
                            }
                    </div>
                  </div>
                    )
                  })
                  :
                  null
                }  
              </div>
      </>  
   )     
}

