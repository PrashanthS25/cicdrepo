/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useState } from 'react';
import '../App.css'
import '../Components/Staking/Staking.css'
import '../mobileApp.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { MdArrowForwardIos} from "react-icons/md";
import OverlayTrigger from 'react-bootstrap/OverlayTrigger';
import Tooltip from 'react-bootstrap/Tooltip';

export default function SelectDurationMobile(){

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return(
       <>
          <Button onClick={handleShow} variant="outline-secondary stake-button popup-select-duration-mobile" id="button-addon2">
              Staking Duration <MdArrowForwardIos className='stake-icon ms-1' />
           </Button>
           <Modal show={show} onHide={handleClose} centered className='s-duration-modal'>
           <Modal.Header closeButton className='s-duration-header'>
          <Modal.Title className='s-duration-title text-center'>Select a Staking Duration</Modal.Title>
        </Modal.Header>

              <Modal.Body className='s-duration-body'>
              <div className='select-d-reward'>
                    <p className='select-duration-title purple'>Rewards 
                         <sup>
                           {['top'].map((placement) => (
                             <OverlayTrigger
                               key={placement}
                               placement={placement}
                               overlay={
                                 <Tooltip id={`tooltip-${placement}`}>
                                   Tooltip on <strong>{placement}</strong>.
                                 </Tooltip>
                               }
                             >
                               <Button variant="secondary" className='stake-i-button ms-1 s-duration-i-btn'>!</Button>
                             </OverlayTrigger>
                           ))}
                         </sup>
                    </p>
                 </div>
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault1">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
                 <hr className='section-border-color' />
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault2"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault2">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
                 <hr className='section-border-color' />
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault3"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault3">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
                 <hr className='section-border-color' />
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault4"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault4">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
                 <hr className='section-border-color' />
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault5"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault5">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
                 <hr className='section-border-color' />
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault6"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault6">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
                 <hr className='section-border-color' />
                 <div className='select-d-info'>
                        {/* <form action="/"> */}
                        <div className="form-check select-d-info-check">
                              <input className="form-check-input staking-plfrm-radio me-3" type="radio" name="flexRadioDefault" id="flexRadioDefault7"/>
                              <label className="form-check-label mt-1" for="flexRadioDefault7">
                                7 Days
                              </label>
                            </div>
                        {/* </form> */}
                        <div>
                            <p className='mb-0 select-info-percent'>9.8%</p>
                        </div>
                 </div>
              </Modal.Body>
              
            </Modal>
       </>
    )
}