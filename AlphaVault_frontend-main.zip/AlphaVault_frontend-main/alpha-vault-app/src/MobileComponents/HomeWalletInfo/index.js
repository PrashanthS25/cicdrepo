/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useEffect, useState } from "react";
import "../../App.css";
import "../../mobileApp.css";
import "../HomeWalletInfo/HomeWalletInfo.css";
import { BiCheckCircle } from "react-icons/bi";
import { RiArrowDownSLine } from "react-icons/ri";
import metamask from "../../assets/images/MetaMask.svg";
import walleticon from "../../assets/images/walleticon.png";
import eth from "../../assets/images/ethereum.svg";
import Offcanvas from "react-bootstrap/Offcanvas";
import { VscDebugDisconnect } from "react-icons/vsc";
import { MdArrowBackIosNew } from "react-icons/md";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { netWorkConfig } from "../../config/networkConfig";
import Emitter from "../../Helper/emitter";
import { formatAddress } from "../../Helper/helperFunctions";
import { useMoralis, useMoralisWeb3Api, useChain } from "react-moralis";
import BigNumber from "bignumber.js";
import {
  initWallet,
  changeChainId,
  resetWallet,
  fetchWalletResponse,
  setActiveWallet,
  setLoaderInactive,
  setWeb3Instance,
} from "../../redux/index";
import { connect } from "react-redux";
import walleticonnect from "../../assets/images/walletconnect.svg";

const Web3 = require("web3");

function HomeWalletInfo(props) {
  const web3 = new Web3();
  const Web3Api = useMoralisWeb3Api();

  let navigate = useNavigate();
  let location = useLocation();
  const { switchNetwork } = useChain();
  const { user, logout, enableWeb3 } = useMoralis();

  const [error, setError] = useState(null);
  const [activeWalletType, setActiveWalletType] = useState(
    localStorage.getItem("activeWalletType")
  );
  const [wallets, setWallets] = useState([]);

  const configWallets = (newWalletObj = null) => {
    let existingUser;
    if (newWalletObj) {
      existingUser = newWalletObj;
    } else {
      existingUser = JSON.parse(localStorage.getItem("WalletConnection"));
    }
    let _wallets = [];
    if (existingUser) {
      if (existingUser.metamask.length) {
        _wallets.push(...existingUser.metamask);
      }
      if (existingUser.walletConnect.length) {
        _wallets.push(...existingUser.walletConnect);
      }
    }
    setWallets(_wallets);
  };

  const connectWalletFromLocalStorage = () => {
    let existingUser = localStorage.getItem("WalletConnection");
    let requiredWallet = JSON.parse(localStorage.getItem("activeWallet"));
    if (existingUser && requiredWallet) {
      Emitter.emit("setLoading", { isLoading: true });
      if (requiredWallet.type === "Metamask") {
        if (requiredWallet.walletUser) {
          configWallet(requiredWallet.walletUser, "Metamask", true);
          props.setActiveWallet("Metamask");
        } else {
          //reset the setting
          Emitter.emit("setLoading", { isLoading: false });
        }
      } else {
        if (requiredWallet.walletUser) {
          configWallet(requiredWallet.walletUser, "WalletConnect", true);
          props.setActiveWallet("WalletConnect");
        } else {
          Emitter.emit("setLoading", { isLoading: false });
        }
      }
    } else {
      let connectObj = { metamask: [], walletConnect: [] };
      connectObj = JSON.stringify(connectObj);
      localStorage.setItem("WalletConnection", connectObj);
      Emitter.emit("setLoading", { isLoading: false });
    }
  };

  useEffect(() => {
    // // console.log("HomeWalletInfo")
    // connectWalletFromLocalStorage();
    configWallets();

    let requiredWallet = JSON.parse(localStorage.getItem("activeWallet"));
    if (requiredWallet) {
      setActiveWalletType(requiredWallet.type);
      setActiveWallet(requiredWallet.walletUser);
    }

    Emitter.on("SetWalletType", (walletType) => {
      setActiveWalletType(walletType.wallet);
      configWallets();
    });

    Emitter.on("newConnectionRequest", (requiredObj) => {
      configWallet(
        requiredObj.user,
        requiredObj.type,
        requiredObj.fromLocal,
        requiredObj.newConnect
      );
    });
    // // console.log("networkTest",props.chain?.networkId)
  }, [props.networkId]);

  const [show, setShow] = useState(false);
  const [active, setActive] = useState(false);
  const [switchWallet, setSwitchWallet] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handle_network_close = () => setActive(false);
  const handle_network_show = () => setActive(true);

  const handle_switch_close = () => setSwitchWallet(false);
  const handle_switch_show = () => setSwitchWallet(true);

  //to format the native token object
  const formatNativeTokenObj = (balanceObj, _chainId, _tokenList) => {
    if (_chainId === 56) {
      _tokenList.push({
        name: "Binance Coin",
        balance: balanceObj.balance,
        token_address: "Binance",
        decimals: 18,
      });
      return _tokenList;
    } else if (_chainId === 137 || _chainId === 80001) {
      _tokenList.push({
        name: "Polygon",
        balance: balanceObj.balance,
        token_address: "Polygon",
        decimals: 18,
      });
      return _tokenList;
    } else {
      _tokenList.push({
        name: "Ethereum",
        balance: balanceObj.balance,
        decimals: 18,
        token_address: "Ethereum",
        symbol: "ETH",
      });
      return _tokenList;
    }
  };

  const configWallet = async (
    _user,
    walletType = null,
    fromLocal = false,
    toAddNewWallet = false,
    changeChainRequest = false
  ) => {
    try {
      Emitter.emit("setLoading", { isLoading: true });
      let _web3;
      if (walletType === "walletconnect") {
        _web3 = await enableWeb3({ provider: "walletconnect" });
      } else {
        _web3 = await enableWeb3();
      }
      let _web3_prov = new Web3(_web3.provider);
      props.setWeb3Instance(_web3_prov);
      Emitter.emit("setWeb3Obj", { web3: _web3_prov });
      Emitter.emit("setLoading", { isLoading: true });
      let _chainId = _web3._network.chainId;
      let requiredNetwork = netWorkConfig.find((e) => e.networkId === _chainId);
      props.changeChainId(requiredNetwork);
      let _address, userName;
      if (!fromLocal) {
        _address = await _user.get("ethAddress");
        userName = await _user.get("username");
      } else {
        _address = _user.accounts[0];
        userName = _user.username;
      }
      Emitter.emit("setLoading", { isLoading: true });
      let _tokenList = await Web3Api.account.getTokenBalances({
        chain: requiredNetwork.netWorkIdForMorallis,
        address: _address.toString(),
      });

      let balance = await Web3Api.account.getNativeBalance({
        chain: requiredNetwork.netWorkIdForMorallis,
        address: _address.toString(),
      });
      _tokenList = formatNativeTokenObj(balance, _chainId, _tokenList);
      Emitter.emit("setLoading", { isLoading: true });
      props.initWallet({
        walletAddress: _address,
        userName,
        isWalletConnected: true,
        isPolicyAccepted: true,
        assets: _tokenList,
        web3InStance: _web3_prov,
      });

      let coinDetails = _tokenList.map((item) => {
        return {
          coin_address: item.token_address ? item.token_address : "Ethereum",
          coin_name: item.name,
          coin_quantity:
            item.decimals === 18
              ? web3.utils.fromWei(item.balance, "ether")
              : new BigNumber(item.balance)
                  .dividedBy(
                    new BigNumber(10).pow(new BigNumber(+item.decimals))
                  )
                  .toNumber(),
        };
      });

      await props.fetchWalletResponse(
        { userAddress: _address.toString(), user_wallet_coin: coinDetails },
        requiredNetwork.networkId
      );

      if (toAddNewWallet) {
        //logic to see if given user is already present or not
        let connections = JSON.parse(localStorage.getItem("WalletConnection"));
        let isAlreadyPresent = false;
        if (connections) {
          if (connections.metamask.length) {
            isAlreadyPresent = connections.metamask.find((e) => {
              if (e.accounts[0] === _address) {
                return true;
              } else {
                return false;
              }
            });
          }

          if (!isAlreadyPresent) {
            if (connections.walletConnect.length) {
              isAlreadyPresent = connections.walletConnect.find((e) => {
                if (e.accounts[0] === _address) {
                  return true;
                } else {
                  return false;
                }
              });
            }
          }
        }

        if (isAlreadyPresent) {
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: walletType, walletUser: _user })
          );
          Emitter.emit("SetWalletType", { wallet: walletType });
        } else {
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: walletType, walletUser: _user })
          );
          props.setActiveWallet(walletType);
          let connectObj = JSON.parse(localStorage.getItem("WalletConnection"));
          if (walletType === "Metamask") {
            connectObj.metamask.push(_user);
          } else {
            connectObj.walletConnect.push(_user);
          }
          localStorage.setItem("WalletConnection", JSON.stringify(connectObj));
          Emitter.emit("SetWalletType", { wallet: walletType });
        }
      }
      setTimeout(() => {
        Emitter.emit("setLoading", { isLoading: false });
        // // console.log("lastRecord", localStorage.getItem("lastVisitedPage"));
        if (localStorage.getItem("lastVisitedPage") === "/buysellvaults") {
          let navigationRoute = localStorage.getItem("lastVisitedPage");
          localStorage.setItem("lastVisitedPage", "");
          navigate(navigationRoute);
        }
      }, 1000);

      if (changeChainRequest) {
        // // console.log("helloooooooooooooo");
        Emitter.emit("setLoading", { isLoading: true });
        if (location.pathname === "/vaultDetail") {
          Emitter.emit("setLoading", { isLoading: true });
          // // console.log("pathTracker1");
          navigate("/vaults");
        }
        // // console.log("changeRquest", location);
      }
    } catch (error) {
      // setError(error)
      Emitter.emit("setLoading", { isLoading: false });
    }
  };

  //below fuction is used to change newtwork using 'switchNetwork'method of morallis hook
  const updateNetwork = async (requiredNetwork) => {
    handle_network_close()
    // // console.log("here891")
    Emitter.emit("setMobileLoading", { isLoading: true });
    // Emitter.emit("updateMobNetwork", { changeNetwork: requiredNetwork });
    switchNetwork(requiredNetwork.netWorkIdForMorallis)
      .then((status) => {
        // // console.log("here891")
        Emitter.emit("setMobileLoading", { isLoading: true });
        // Emitter.emit("updateMobNetwork", { changeNetwork: requiredNetwork });
        configWallet(user, null, false, false, true); //calling configWallet to get info of the wallet holdings for changed network
        // to update the props according to the current network
        window.location.reload();
      })
      .catch((error) => {
        Emitter.emit("setMobileLoading", { isLoading: true });
        // Emitter.emit("updateMobNetwork", { changeNetwork: requiredNetwork });
        // // console.log("error", error.message);
        setError(error.message);
      })
    // // // console.log("testUpdateNet",requiredNetwork)
    // Emitter.emit('updateMobNetwork',requiredNetwork)
  };

  //function to change wallet according to wallet
  const changeWalletUsingWalletType = (requiredWallet) => {
    let requiredWalletObj;
    Emitter.emit("setLoading", { isLoading: true });
    let existingUser = JSON.parse(localStorage.getItem("WalletConnection"));
    // //// // console.log.log("requiredWallet",existingUser,requiredWallet)
    let metaUser = existingUser.metamask;
    let walletConnectUser = existingUser.walletConnect;
    setActiveWalletType(requiredWallet);
    props.setLoaderActive();
    if (existingUser && (metaUser.length || walletConnectUser.length)) {
      // //// // console.log.log('existingCheck')
      if (requiredWallet === "Metamask") {
        // //// // console.log.log('MetamaskCheck')
        if (metaUser.length) {
          // //// // console.log.log('MetamaskCheck1')
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: "Metamask", walletUser: metaUser[0] })
          );
          configWallet(metaUser[0], "Metamask", true);
          // configWallet(metaUser[0],true)
          props.setActiveWallet("Metamask");
        } else {
          props.resetWallet();
          props.setLoaderInactive();
          props.setActiveWallet("Metamask");
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: "Metamask", walletUser: null })
          );
          Emitter.emit("setLoading", { isLoading: false });
          navigate("/connectWallet");
        }
      } else if (requiredWallet === "WalletConnect") {
        // //// // console.log.log('WalletConnectCheck')
        if (walletConnectUser.length) {
          // //// // console.log.log('WalletConnectCheck1')
          // localStorage.setItem("activeWalletType",'WalletConnect')
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({
              type: "WalletConnect",
              walletUser: walletConnectUser[0],
            })
          );
          configWallet(walletConnectUser[0], null, true);
          // Emitter.emit("connectExistingWalletconnect",{user:metaUser[0]})
          // configWallet(walletConnectUser[0],true)
          props.setActiveWallet("WalletConnect");
        } else {
          // //// // console.log.log('WalletConnectCheck2')
          props.resetWallet();
          props.setLoaderInactive();
          props.setActiveWallet("WalletConnect");
          localStorage.setItem(
            "activeWallet",
            JSON.stringify({ type: "WalletConnect", walletUser: null })
          );
          Emitter.emit("setLoading", { isLoading: false });
          navigate("/connectWallet");
        }
      }
    } else {
      props.setLoaderInactive();
      Emitter.emit("setLoading", { isLoading: false });
      navigate("/connectWallet");
    }
    Emitter.emit("setLoading", { isLoading: false });
  };

  const disconnectWallet = (wallet) => {
    // //// // console.log("logDisconnection1",wallet)
    let connections = JSON.parse(localStorage.getItem("WalletConnection"));
    // //// // console.log.log("connections",connections,wallet)
    let isDeleted = false;
    let requiredIndex = null;
    let walletConnector = null
    // //// // console.log("logDisconnection2",wallet)
    //logic to delete wallet instance from localStorage
    if (connections) {
      if (connections.metamask.length) {
        // //// // console.log.log("into1")
        connections.metamask.find((e, i) => {
          // //// // console.log.log("into12",e.accounts[0]===wallet.accounts[0])
          if (e.accounts[0] === wallet.accounts[0]) {
            requiredIndex = i;
            return i;
          } else {
            return null;
          }
        });
        // //// // console.log.log("into13",requiredIndex)

        if (requiredIndex !== null && requiredIndex !== undefined) {
          walletConnector = "Metamask"
          connections.metamask.splice(requiredIndex, 1);
          isDeleted = true;
        }
      }

      if (!requiredIndex && !isDeleted) {
        // //// // console.log.log("searchIntoWalletConnect")
        if (connections.walletConnect.length) {
          connections.walletConnect.find((e, i) => {
            if (e.accounts[0] === wallet.accounts[0]) {
              requiredIndex = i;
              return i;
            } else {
              return false;
            }
          });
        }
        if (requiredIndex !== null && requiredIndex !== undefined) {
          walletConnector = "WalletConnect"
          connections.walletConnect.splice(requiredIndex, 1);
          isDeleted = true;
        }
      }
    }
    // //// // console.log.log("connections",connections)
    localStorage.setItem("WalletConnection", JSON.stringify(connections));
    // //// // console.log("logoutLog01")
    // condition to set new Active wallet if active wallet needed to delete
    if (props.walletAddress === wallet.accounts[0]) {
      let NewActiveWallet = getNewActiveWallet(connections);
      // //// // console.log.log("connections1",NewActiveWallet)
      // //// // console.log("logoutLog11")
      if (!NewActiveWallet) {
        // //// // console.log("logoutLog12")
        removeWallet(walletConnector);
      } else {
        localStorage.setItem("activeWallet", JSON.stringify(NewActiveWallet));
        setActiveWalletType(NewActiveWallet.type);
        configWallet(NewActiveWallet.walletUser, null, true);
      }
    }
    configWallets(connections);
    handleClose()
  };

  const getNewActiveWallet = (connections) => {
    let newElement = null;
    if (connections.metamask.length) {
      newElement = { type: "Metamask", walletUser: connections.metamask[0] };
    }

    if (connections.walletConnect.length && !newElement) {
      newElement = {
        type: "WalletConnect",
        walletUser: connections.walletConnect[0],
      };
    }
    return newElement;
  };

  const removeWallet = async(walletConnector ) => {
    if(walletConnector === "WalletConnect"){
      localStorage.removeItem('walletconnect')
    }
    await logout();
    localStorage.removeItem("activeWallet");
    props.initWallet({
      walletAddress: null,
      chainId: null,
      isWalletConnected: false,
      isPolicyAccepted: false,
      assets: null,
    });
  };

  return (
    <>
      <div className="home-wallet-info">
       {
       props.isWalletConnected? 
        <p className="mobile-v-nav-wc-conneted-walletinfo mb-2">
          Connected Wallet
        </p>
        :
        null
      }
        <div className="mobile-v-nav-wc">

        {
       props.isWalletConnected? 
          <button
            class="btn mobile-v-nav-wc-btn"
            type="button"
            onClick={handle_network_show}
          >
            <img
              src={props?.chain?.networkLogo}
              alt=""
              className="mobile-v-nav-wc-btn-img me-2"
            />
            <RiArrowDownSLine className="mobile-v-nav-wc-btn-icon" />
          </button>
        :
        null
        }  
          <Offcanvas
            show={active}
            onHide={handle_network_close}
            placement="bottom"
            className="mobile-v-nav-wc-offbox"
          >
            <div className="mobile-v-nav-wc-top-border"></div>
            <Offcanvas.Header className="mobile-v-nav-wc-off-header">
              {/* <button className="off-naviagte-btn"> */}
                {/* <NavLink to="/"> */}
                  <MdArrowBackIosNew className="modal-back-icon" onClick={handle_network_close}/>
                {/* </NavLink> */}
              {/* </button> */}
              <Offcanvas.Title className="mobile-v-nav-wc-heading">
                Choose Network
              </Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body className="mobile-v-nav-wc-offbody">
              {netWorkConfig.map((item, index) => (
                <div
                  className="d-flex justify-content-between align-items-center mobile-v-nav-wc-ul-dm-li-div"
                  key={item.networkId}
                >
                  
                  <div className="d-flex align-items-center">
                    <img
                      src={item.networkLogo || eth}
                      alt=""
                      className="mobile-v-nav-wc-btn-img"
                    />
                    <div className="mobile-v-nav-wc-li-dm-text">
                      <h6
                        className="mobile-v-nav-wc-li-dm-1 text-capitalize mb-0"
                      >
                        <span className="dropdown-item" 
                        onClick={() => updateNetwork(item)}
                        >
                          {item.networkName}
                        </span>
                      </h6>
                      <h6 className="mobile-v-nav-wc-li-dm-2 text-uppercase mb-0">
                        <span className="dropdown-item" >
                          {item.symbol}
                        </span>
                      </h6>
                    </div>
                  </div>
                  
                  {props?.chain?.networkId === item.networkId ? (
                    <div className="mobile-v-nav-wc-ul-dm-check">
                      <BiCheckCircle className="offcheck " />
                    </div>
                  ) : null}
                </div>
              ))}
            </Offcanvas.Body>
          </Offcanvas>

        { 
        props.isWalletConnected?           
          <button
            class="btn mobile-v-nav-wc-btn-wltaddres"
            type="button"
            onClick={handleShow}
          >
            {formatAddress(props.walletAddress)}
            <img
              src={walleticon}
              alt=""
              className="mobile-v-nav-wc-btn-wltimg ms-2"
            />
          </button>
          :
          <button
            class="btn mobile-v-nav-wc-btn-wltaddres m-auto"
            type="button"
            onClick={()=>navigate('/connectWallet')}
          >
           Connect Wallet 
          </button>
          }
          <Offcanvas
            show={show}
            onHide={handleClose}
            placement="bottom"
            className="mobile-v-nav-wc-offbox"
          >
            <div className="mobile-v-nav-wc-top-border"></div>

            <Offcanvas.Header className="mobile-v-nav-wc-off-header">
              {/* <button className="off-naviagte-btn">
                <NavLink to="/"> */}
                  <MdArrowBackIosNew className="modal-back-icon" onClick={handleClose}/>
                {/* </NavLink>
              </button> */}
              <Offcanvas.Title className="mobile-v-nav-wc-heading">
                Choose Another Wallet
              </Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body className="mobile-v-nav-wc-offbody">
            {
            wallets.map((wallet, i) => {
              return(  
              <div className="d-flex justify-content-between align-items-center mobile-v-nav-wc-ul-dm-li-div" key={i}>
                <div className="d-flex align-items-center">
                  <img
                    src={walleticon}
                    alt=""
                    className="mobile-v-nav-wc-btn-img"
                  />
                  <div className="mobile-v-nav-wc-li-dm-text">
                    <h6 className="mobile-v-nav-wc-li-dm-1 text-capitalize mb-0">
                      <p className="dropdown-item" >
                      {formatAddress(wallet.accounts[0])}
                      </p>
                    </h6>
                    {/* <h6 className="mobile-v-nav-wc-li-dm-2 text-uppercase mb-0">
                      <p className="dropdown-item" >
                        2.124505 ETH
                      </p>
                    </h6> */}
                  </div>
                </div>
                <div className="d-flex">
                {wallet.accounts[0] === props.walletAddress ?
                  <button className="btn">
                    <BiCheckCircle className="offcheck" />
                  </button>
                 :
                 null
                }
                  
                  <button className="btn">
                    <VscDebugDisconnect className="disconnect-botton"
                    onClick={() => disconnectWallet(wallet)}
                    />
                  </button>
                  
                </div>
              </div>
              )})
            }
              
            </Offcanvas.Body>
          </Offcanvas>

          {
          props.isWalletConnected?
          <button
            class="btn mobile-v-nav-wc-btn"
            type="button"
            onClick={handle_switch_show}
          >
            <img
              src={metamask}
              alt=""
              className="mobile-v-nav-wc-btn-img me-2"
            />
            <RiArrowDownSLine className="mobile-v-nav-wc-btn-icon" />
          </button>
          :
          null
          }
          <Offcanvas
            show={switchWallet}
            onHide={handle_switch_close}
            placement="bottom"
            className="mobile-v-nav-wc-offbox"
          >
            <div className="mobile-v-nav-wc-top-border"></div>

            <Offcanvas.Header className="mobile-v-nav-wc-off-header">
              {/* <button className="off-naviagte-btn" > */}
                {/* <NavLink > */}
                  <MdArrowBackIosNew className="modal-back-icon" onClick={handle_switch_close}/>
                {/* </NavLink> */}
              {/* </button> */}
              <Offcanvas.Title className="mobile-v-nav-wc-heading">
                Choose Another Wallet
              </Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body className="mobile-v-nav-wc-offbody">
              <div>
                <div
                  // className="dropdown-menu wallets-dropdown alpha-menu-drpdwn"
                  aria-labelledby="navbarDropdownMenuLink"
                  style={{
                    display: "flex",
                    flexDirection: "column",  
                    alignItems: "start",
                    justifyContent: "center",
                    marginTop: 20,
                  }}
                >
                  <div>
                    <button
                      className="dropdown-item"
                      onClick={() => changeWalletUsingWalletType("Metamask")}
                    >
                      <img
                        src={metamask}
                        alt=""
                        className=""
                      
                      />
                      <span>  MetaMask</span>
                    </button>
                  </div>
                  <div>
                    <button
                      className="dropdown-item "
                      onClick={() =>
                        changeWalletUsingWalletType("WalletConnect")
                      }
                    >
                      <img
                        className=""
                        src={walleticonnect}
                        alt=""
                        style={{ width: 30, marginTop: 10 }}
                      />
                      <span>  WalletConnect</span>
                    </button>
                  </div>
                </div>
              </div>
            </Offcanvas.Body>
          </Offcanvas>
        </div>
      </div>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    walletBalance: state.wallet.walletBalance,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    activeWallet: state.wallet.activeWallet,
    chain: state.wallet.chain,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody, newtwork) =>
      dispatch(fetchWalletResponse(reqBody, newtwork)),
    changeChainId: (newChainId) => dispatch(changeChainId(newChainId)),
    setActiveWallet: (walletConnector) =>
      dispatch(setActiveWallet(walletConnector)),
    setLoaderActive: () => dispatch(setActiveWallet()),
    setLoaderInactive: () => dispatch(setLoaderInactive()),
    setWeb3Instance: (instance) => dispatch(setWeb3Instance(instance)),
    resetWallet: () => dispatch(resetWallet()),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(HomeWalletInfo);
