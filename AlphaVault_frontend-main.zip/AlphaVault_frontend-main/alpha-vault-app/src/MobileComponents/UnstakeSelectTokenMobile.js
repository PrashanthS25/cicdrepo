/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useState } from 'react';
import '../App.css'
import '../Components/Staking/Staking.css'
import '../mobileApp.css';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Button from 'react-bootstrap/Button';
import { MdArrowForwardIos, MdArrowBackIosNew} from "react-icons/md";
import {NavLink} from "react-router-dom";
import { IoSearchOutline } from "react-icons/io5";
import  tether from "../assets/images/tether.svg";
import  usdcoin from "../assets/images/usdcoin.png";
import  aave from "../assets/images/aave.png";
import  swash from "../assets/images/swash.png";
import  eth from "../assets/images/ethereum1.svg";

export default function UnstakeSelectTokenMobile(){

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  
    return(
       <>
        <Button variant="outline-secondary stake-button mobile-stake-token-btn" id="button-addon2" onClick={handleShow}>
            Select token <MdArrowForwardIos className='stake-icon ms-1'/>
        </Button>

        <Offcanvas show={show} onHide={handleClose} placement="bottom" className='mobile-v-nav-wc-offbox s-token-offbox'>
           <div className='mobile-v-nav-wc-top-border'></div>

           <Offcanvas.Header className='mobile-v-nav-wc-off-header'>
             <button className='off-naviagte-btn'><NavLink to='/'><MdArrowBackIosNew className='modal-back-icon'/></NavLink></button>
             <Offcanvas.Title className='mobile-v-nav-wc-heading'>Select a token</Offcanvas.Title>
                <div className='seacrhcoin-box'>
                   <form className="select-token-search-box">
                        <IoSearchOutline className="select-token-search-alpha" />
                        <input className="form-control select-token-seach-plchldr" type="search" placeholder="Search by name" aria-label="Search" />
                  </form>
                   <div className='unstake-select-token-tbl-heading d-flex justify-content-between'>
                    <h6 className='mb-0'>Staked Tokens</h6>
                    <h6 className='mb-0'>Staked Amount</h6>
                   </div>
                </div>
           </Offcanvas.Header>

           <Offcanvas.Body className='mobile-v-nav-wc-offbody'>
           <div className='select-token-details s-t-padding'>
                  <div className="select-token-details-box mb-3">
                     <div className="select-token-details-box-left">
                       <button className='selct-token-btn'><img src={eth} alt="" className="me-3 s-token-image" /></button>
                        <div className="select-token-text">
                        <button className='selct-token-btn'> <h6 className="text-capitalize">Ethereum</h6></button>
                         <h6 className="mb-0 grey text-uppercase">ETH</h6>
                        </div>
                     </div>
                     <div className="select-token-details-box-right">
                      <h5>0.1020564</h5>
                      <h6 className='mb-0 grey'>$1,300.78</h6>
                     </div>
                   </div>
           
                  <div className="select-token-details-box mb-3">
                     <div className="select-token-details-box-left">
                        <button className='selct-token-btn'><img src={tether} alt="" className="me-3 s-token-image" /></button>
                        <div className="select-token-text">
                           <button className='selct-token-btn'><h6 className="text-capitalize">Tether</h6></button>
                            <h6 className="mb-0 grey text-uppercase">USDT</h6>
                        </div>
                     </div>
                     <div className="select-token-details-box-right">
                       <h5>0.1020564</h5>
                       <h6 className='mb-0 grey'>$1,300.78</h6>
                     </div>
                  </div>
                  <div className="select-token-details-box mb-3">
                    <div className="select-token-details-box-left">
                    <button className='selct-token-btn'> <img src={usdcoin} alt="" className="me-3 s-token-image" /></button>
                       <div className="select-token-text">
                       <button className='selct-token-btn'><h6 className="text-capitalize">USD Coin</h6></button>
                        <h6 className="mb-0 grey text-uppercase">USDC</h6>
                       </div>
                    </div>
                    <div className="select-token-details-box-right">
                    <h5>0.1020564</h5>
                    <h6 className='mb-0 grey'>$1,300.78</h6>
                    </div>
                  </div>
        
               </div>
           </Offcanvas.Body>
         </Offcanvas>
       </>
    )

}