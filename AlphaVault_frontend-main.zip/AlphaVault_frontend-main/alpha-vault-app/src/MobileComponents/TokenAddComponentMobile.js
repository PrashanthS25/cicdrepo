/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useState, useRef, useEffect } from "react";
import "../App.css";
import "../Components/Staking/Staking.css";
import "../mobileApp.css";
import Offcanvas from "react-bootstrap/Offcanvas";
import { MdArrowBackIosNew } from "react-icons/md";
import { RiArrowDownSLine } from "react-icons/ri";
import { NavLink } from "react-router-dom";
import { IoSearchOutline } from "react-icons/io5";
import tether from "../assets/images/tether.svg";
import usdcoin from "../assets/images/usdcoin.png";
import aave from "../assets/images/aave.png";
import swash from "../assets/images/swash.png";
import eth from "../assets/images/ethereum1.svg";
import Accordion from "react-bootstrap/Accordion";
import API from "../utils/Api";
import { findToken } from "../Helper/helperFunctions";
import { fetchCoins } from "../redux";
import { connect } from "react-redux";
import Loader from "../Components/Loader";

function TokenAddComponentMobile(props) {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [coinList, setCoinList] = useState([]);
  const [categoryList, setCategoryList] = useState([{ categoryName: "All" }]);
  const [loader, setLoader] = useState(true);
  const [category, selectCategory] = useState("All");
  const [coinsLoader, setCoinsLoader] = useState(false);
  // const [props.selectAllSelector,props.setSelectAllSelector] = useState(false)
  const [tempSelection, setTempSelection] = useState([]);
  const [searchCoinMode, setSearchCoinMode] = useState(false);
  const [searchResultCoins, setSearchResultCoins] = useState([]);
  const [searchQueryNotification, setSearchQueryNotification] = useState(null);
  const sellectAllRef = useRef();

  useEffect(() => {
    // console.log("herr5466666", props.selectAllSelector);
    fetchCoinCategories();
    fetchCoinList();
  }, []);

  const fetchCoinCategories = async () => {
    try {
      setLoader(true);

      let _categoryList = await API.get(
        "/category/list?coinChainID=" + props.chain.networkId
      );
      // console.log("_categoryList", _categoryList);
      setCategoryList((e) => [...e, ..._categoryList.data.data]);
      setLoader(false);
    } catch (error) {
      // console.log(error);
      setLoader(false);
    }
  };

  const fetchCoinList = async () => {
    try {
      setCoinsLoader(true);
      let _coinList = await API.get(
        "/coin/list?coinChainID=" + props.chain.networkId + "&count=70&page=1"
      );
      // console.log("_coinList", _coinList);
      props.setCoinList(_coinList.data.data);
      setCoinList(_coinList.data.data);
      setCoinsLoader(false);
    } catch (error) {
      // console.log(error);
      setCoinsLoader(false);
    }
  };

  const moveToEditMode = () => {
    props.setSelectAllSelector(false);
    if (!searchCoinMode) {
      sellectAllRef.current.checked = false;
    }
    setTempSelection([]);
    props.setTokenAddModeSection(false);
    props.setEditVaultMode(true);
  };

  const getCategoryList = async (_categoryName) => {
    try {
      let _coinCategoryList = await API.post(
        "/coin/list?coinChainID=" + props.chain.networkId,
        { categoryName: [_categoryName] }
      );
      // console.log("_coinCategoryList", _coinCategoryList);
      setCoinList(_coinCategoryList.data.data);
    } catch (error) {
      // console.log("error", error);
    }
  };

  const setCategory = async (categoryName, index) => {
    if (category !== categoryName) {
      setCoinsLoader(true);
      // setActiveIndex(index)
      // console.log("see", props.selectAllSelector);
      if (props.selectAllSelector) {
        props.setSelectAllSelector(false);
        sellectAllRef.current.checked = false;
        props.setRemoved(!props.removed);
      }
      selectCategory(categoryName);
      if (categoryName === "All") {
        await fetchCoinList();
      } else {
        await getCategoryList(categoryName);
      }
      setCoinsLoader(false);
    }
  };

  function toggleActiveStyles(categoryName) {
    // console.log("test", categoryName, category);
    if (categoryName === category) {
      return "btn btn-light mb-3 me-2 select-tkn-btn activebtn";
    } else {
      return "btn btn-light mb-3 me-2 select-tkn-btn inactivebtn";
    }
  }

  //function to select tokens
  const tokenSelection = (e, index) => {
    // selectToken(e)
    // if(e.detail === 1){
    // // console.log("tim",event.detail)
    let isAlreadypresent = false;
    tempSelection.map((t) => {
      if (t.coinSymbol === e.coinSymbol) {
        isAlreadypresent = true;
      }
    });
    // console.log("getNewToken1", e);
    if (!isAlreadypresent) {
      setTempSelection((t) => [...t, e]);
      checkSelectAllMode(tempSelection.length + 1);
    }
    // }
    // else{

    // }
    // props.setSelectedTokens((t)=>[...t,e])
    // let newLength = tempSelection.length +1
    // let selectAllRequiredLength =  findAllSelectbleToken()
    // // console.log("lengths",newLength,selectAllRequiredLength)
    // if(newLength === selectAllRequiredLength){
    //   props.setSelectAllSelector((!props.selectAllSelector))
    //   // console.log("here123",)
    //   sellectAllRef.current.checked = true
    // }
  };

  const checkSelectAllMode = (newLength = null) => {
    if (!newLength) {
      newLength = tempSelection.length;
    }
    let selectAllRequiredLength = findAllSelectbleToken();
    // console.log("lengths", coinList, newLength, selectAllRequiredLength);
    if (newLength === selectAllRequiredLength) {
      props.setSelectAllSelector(!props.selectAllSelector);
      // console.log("here123", sellectAllRef);
      if (sellectAllRef) {
        sellectAllRef.current.checked = true;
      }
      return true;
    } else {
      return false;
    }
  };

  //function returns appropriate class of the token element
  const checkBoxClass = (e) => {
    let isTokenPresent = findAlreadyPresentToken(e);
    if (isTokenPresent) {
      return "form-check-input select-token-check-input select-token-form-check1";
    } else {
      let check = validateChecked(e);
      // console.log(
      //   "checkBoxClass",
      //   e,
      //   check,
      //   props.selectedTokens,
      //   tempSelection
      // );
      if (check) {
        // console.log("show1", e);
        return "form-check-input select-token-check-input select-token-form-show";
      } else {
        // console.log("drop1", e);
        return "form-check-input select-token-check-input select-token-form-check1";
      }
    }
  };

  //function to check whether token is alreacy present in the user wallet
  const findAlreadyPresentToken = (token) => {
    let _isTokenPresent = props.tokenList.find((t) => {
      if (t.coinSymbol === token.coinSymbol) {
        return true;
      } else {
        return false;
      }
    });
    return _isTokenPresent;
  };

  //function is used to check whether given token is recently selected or not
  const validateChecked = (token) => {
    let _isValid = null;
    // console.log("step0", props.selectedTokens, token);
    if (props.selectedTokens?.length) {
      _isValid = props.selectedTokens.find((t) => {
        if (t.coinSymbol === token.coinSymbol) {
          return t;
        } else {
          return null;
        }
      });
    }
    // console.log("step1", _isValid, props.selectedTokens, tempSelection, token);
    if (!_isValid) {
      _isValid = tempSelection.find((t) => {
        if (t.coinSymbol === token.coinSymbol) {
          return t;
        } else {
          return false;
        }
      });
    }
    // console.log("step1", _isValid);

    return _isValid;
  };

  //function is used to unselect the selected tokens
  const removeSelectedToken = (e) => {
    props.setRemoved(!props.removed);
    let currTokens = tempSelection;
    let alreadySelectedTokens = props.selectedTokens;
    // console.log("hereInRemove", e, currTokens);

    if (props.selectAllSelector) {
      sellectAllRef.current.checked = false;
      props.setSelectAllSelector(!props.selectAllSelector);
    }
    let isRemoved = false;
    currTokens.map((token, i) => {
      if (e.coinSymbol === token.coinSymbol) {
        currTokens.splice(i, 1);
        isRemoved = true;
      }
    });
    // console.log("currTokens", currTokens);
    setTempSelection(currTokens);

    if (!isRemoved) {
      alreadySelectedTokens.map((token, i) => {
        if (e.coinSymbol === token.coinSymbol) {
          alreadySelectedTokens.splice(i, 1);
          isRemoved = true;
        }
      });
      //  console.log(
      //   "hereInRemove2",
      //   alreadySelectedTokens,
      //   alreadySelectedTokens
      // );

      props.setSelectedTokens(alreadySelectedTokens);
    }
    // props.setSelectedTokens(currTokens)
  };

  //function to confirmn and add selected token to edit vault
  const confirmSelection = () => {
    //condition to check whether user has selected the tokens
    if (!tempSelection.length) {
      // console.log("Please select any token.");
    }
    // console.log("tokens", props.selectedTokens);
    let requiredToken = tempSelection;
    let actualTokensToAdd = [];
    //condition to check whether a coin is arady added in addCoin list
    requiredToken.map((coin) => {
      let findStatus = props.addCoin.find((c, i) => {
        if (c.coinAddress == coin.coinAddress) {
          return true;
        } else {
          return false;
        }
      });
      if (!findStatus) {
        actualTokensToAdd.push(coin);
      }
    });

    if (tempSelection.length) {
      actualTokensToAdd.map((coin) => {
        //function to check whether the token is newly added or it is present in current tokens
        let requiredCoin = findToken(
          props.serverResponse.assetList,
          coin.coinAddress
        );
        if (!requiredCoin) {
          requiredCoin = Object.assign({}, coin);
          requiredCoin["coinQuantity"] = 0;
          requiredCoin["coinPerc"] = 0;
          requiredCoin["coinValue"] = 0;
          // requiredCoin['coinDecimal'] = 8
          // requiredCoin.coinSymbol = coin.coinSymbol
          // console.log("pmt1", requiredCoin, coin, props.addCoin);
          props.setSelectedTokens((tokens) => [...tokens, requiredCoin]);
          props.selectAddCoin((tokens) => [...tokens, requiredCoin]);
        }
      });
    }
    moveToEditMode();
  };

  const selectAllFunc = (value) => {
    // console.log("hereValue", value, coinList);
    props.setSelectAllSelector(!props.selectAllSelector);
    if (!props.selectAllSelector === true) {
      coinList.map((token) => {
        let isAlreadyPresent = findAlreadyPresentToken(token);
        let isAlreadySelected = validateChecked(token);
        if (!isAlreadyPresent && !isAlreadySelected) {
          setTempSelection((t) => [...t, token]);
          // props.setSelectedTokens((t)=>[...t,token])
        }
      });
    } else {
      setTempSelection([]);
      // props.setSelectedTokens([])
    }
  };

  const findAllSelectbleToken = () => {
    let selectableTopkenCount = 0;
    coinList.map((token) => {
      let isAlreadyPresent = findAlreadyPresentToken(token);
      if (!isAlreadyPresent) {
        selectableTopkenCount += 1;
      }
    });
    // console.log("selectableTopkenCount", selectableTopkenCount);
    return selectableTopkenCount;
  };

  const searchCoinProcess = async (value) => {
    try {
      // console.log("searchVal", value);
      if (value.length) {
        setSearchCoinMode(true);
        let reqVal = [];
        reqVal.push(value.toString());
        let queryResp = await API.post(
          "/coin/string_filter?coinChainID=" + props.chain.networkId,
          { filter_string: reqVal }
        );
        if (queryResp) {
          if (queryResp.data.data.length) {
            // console.log("resp90", queryResp.data.data, value);
            setSearchResultCoins(queryResp.data.data);
          } else {
            setSearchQueryNotification("No result found");
          }
        }
      } else {
        setSearchCoinMode(false);
        setSearchQueryNotification(null);
        setSearchResultCoins([]);
      }
    } catch (error) {
      // console.log("error", error);
    }
  };

  return (
    <>
      <button
        className="btn btn-light edit-vault-btn edit-vault-not-active-button mobile-stake-token-btn"
        type="button"
        id="button-addon2"
        onClick={handleShow}
      >
        Select Coin
        <RiArrowDownSLine className="mobile-v-nav-wc-btn-icon ms-2" />
      </button>

      <Offcanvas
        show={show}
        onHide={handleClose}
        placement="bottom"
        className="mobile-v-nav-wc-offbox s-walletaddcoin-offbox"
      >
        <div className="mobile-v-nav-wc-top-border"></div>

        {loader ? (
          <Loader />
        ) : (
          <>
            <Offcanvas.Header className="mobile-v-nav-wc-off-header addtoken-mobile-off-h">
              {/* <button className="off-naviagte-btn" onClick={moveToEditMode}> */}
                {/* <NavLink to="/"> */}
                <MdArrowBackIosNew className="modal-back-icon" onClick={handleClose}/>
                {/* </NavLink> */}
              {/* </button> */}
              <Offcanvas.Title className="mobile-v-nav-wc-heading">
                Select a token
              </Offcanvas.Title>
              <div className="seacrhcoin-box">
                <form className="select-token-search-box">
                  <IoSearchOutline className="select-token-search-alpha" />
                  <input
                    className="form-control select-token-seach-plchldr"
                    type="search"
                    onChange={(e) => searchCoinProcess(e.target.value)}
                    placeholder="Search by name"
                    aria-label="Search"
                  />
                  <button
                    type="button"
                    className="btn btn-light section-button mt-3"
                    disabled={
                      tempSelection.length || props.selectedTokens.length
                        ? false
                        : true
                    }
                    onClick={confirmSelection}
                  >
                    SELECT
                  </button>
                </form>
              </div>
              <div className="select-token-filter">
                <p>
                  Filter by Category{" "}
                  <span className="grey">(1/{categoryList.length})</span>
                </p>

                <div className="select-token-filter-button ">
                  {categoryList.length
                    ? categoryList.map((item, i) => {
                        return (
                          <button
                            type="button"
                            // className="btn btn-light mb-3 me-2 select-tkn-btn activebtn"
                            className={toggleActiveStyles(item.categoryName)}
                            onClick={() => setCategory(item.categoryName)}
                            key={item.categoryName}
                          >
                            {item.categoryName}
                          </button>
                        );
                      })
                    : null}
                </div>

                <Accordion>
                  <Accordion.Item eventKey="0" className="filter-collpse-item">
                    <Accordion.Header className="filter-collpse">
                      show all
                    </Accordion.Header>
                    <Accordion.Body className="filter-collpse-body">
                      <button
                        type="button"
                        className="btn btn-light mb-2 mb-sm-3 me-2 select-tkn-btn activebtn"
                      >
                        All
                      </button>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </div>

              {!searchCoinMode ? (
                <div className="form-check select-token-form-check mt-3 ms-1 select-all-check-box">
                  <input
                    className="form-check-input select-token-check-input select-token-form-show"
                    type="checkbox"
                    value="a"
                    // checked
                    id="flexCheckDefault3"
                    ref={sellectAllRef}
                    checked={props.selectAllSelector ? true : false}
                    onClick={(e) => selectAllFunc(e.target.value)}
                  />
                  <label for="flexCheckDefault3" className="select-all-label">
                    Select All
                  </label>
                </div>
              ) : (
                <></>
              )}

              <div className="select-token-heading-label mt-2 mt-sm-3">
                <p className="mb-0 select-token-heading-label-coin-name">
                  coin name
                </p>
                <p className="mb-0">price</p>
              </div>
            </Offcanvas.Header>

            <Offcanvas.Body className="mobile-v-nav-wc-offbody">
              <div className="select-token-details s-t-padding sd-token-body">
                {/* <div className='position-relative'>
                    <div className="form-check select-token-form-check bottom-checkbox">
                       <input className='form-check-input select-token-check-input select-token-form-show'  type="checkbox" value="a" id="flexCheckDefault1"/>
                    </div> 
                    <div  className="d-flex justify-content-between select-token-details-sec-box" >
                      <div className="d-flex select-token-details-sec-box-right-left" >
                         <button className="select-token-d-btn"><img src={eth} alt="" className="me-3 s-addtoken-img"/></button> 
                         <div className="predefined-coins-sec-text">
                            <button className="select-token-d-btn"><h6 className="predefined-coins-sec-name text-capitalize mb-0">Ethereum</h6> </button>
                            <div>
                               <button className="select-token-d-btn"><h6 className="predefined-coins-sec-percent mb-0">ETH</h6></button>  
                            </div> 
                         </div>
                      </div>
    
                      <div className="select-token-details-sec-box-right">
                         <h5>$3,500.78</h5>
                      </div>
                    </div>
                </div>  */}
                {!searchCoinMode ? (
                  coinList.map((e, i) => (
                    <div className="position-relative" key={i}>
                      <div className="form-check select-token-form-check bottom-checkbox">
                        {validateChecked(e) ||
                        validateChecked(e) !== undefined ? (
                          <input
                            //   className='form-check-input select-token-check-input select-token-form-show'  type="checkbox" value="a" id="flexCheckDefault1"
                            className={checkBoxClass(e)}
                            type="checkbox"
                            value="a"
                            id="flexCheckDefault1"
                            defaultChecked={validateChecked(e)}
                            onClick={() => removeSelectedToken(e)}
                          />
                        ) : 
                        null
                        }
                      </div>
                      <div className="d-flex justify-content-between select-token-details-sec-box">
                        <div className="d-flex select-token-details-sec-box-right-left">
                          <button
                            className="select-token-d-btn"
                            onClick={() => tokenSelection(e, i)}
                          >
                            <img
                              src={e.coinLogoUrl}
                              alt=""
                              className="me-3 s-addtoken-img"
                            />
                          </button>
                          <div className="predefined-coins-sec-text">
                            {!findAlreadyPresentToken(e) ? (
                              <button
                                className="select-token-d-btn"
                                onClick={() => tokenSelection(e, i)}
                              >
                                <h6 className="predefined-coins-sec-name text-capitalize">
                                  {e.coinName}
                                </h6>{" "}
                              </button>
                            ) : null}
                            <div>
                              {findAlreadyPresentToken(e) ? (
                                <button className="select-token-d-btn">
                                  <h6 className="predefined-coins-sec-name text-capitalize mb-0">
                                    {e.coinName}
                                  </h6>
                                  <span className="existing-box">
                                    Existing In Edit Vault
                                  </span>{" "}
                                </button>
                              ) : null}
                            </div>
                            <div>
                              <button
                                className="select-token-d-btn"
                                onClick={() => tokenSelection(e, i)}
                              >
                                <h6 className="predefined-coins-sec-percent mb-0">
                                  {e.coinSymbol}
                                </h6>
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="select-token-details-sec-box-right">
                          <h5>${e.coinPrice}</h5>
                        </div>
                      </div>
                    </div>
                  ))
                ) : !searchQueryNotification ? (
                  searchResultCoins.map((e, i) => {
                    return (
                      <div key={i} className="position-relative">
                        <div className="form-check select-token-form-check bottom-checkbox">
                          <input
                            className={checkBoxClass(e)}
                            type="checkbox"
                            value="a"
                            id="flexCheckDefault2"
                            defaultChecked={validateChecked(e)}
                            onClick={() => removeSelectedToken(e)}
                          />
                        </div>
                        <div className="d-flex justify-content-between select-token-details-sec-box">
                          <div className="d-flex select-token-details-sec-box-right-left">
                            <button
                              className="select-token-d-btn"
                              onClick={() => tokenSelection(e, i)}
                            >
                              <img
                                src={e.coinLogoUrl}
                                alt=""
                                className="me-3 s-addtoken-img"
                              />
                            </button>
                            <div className="predefined-coins-sec-text">
                              {!findAlreadyPresentToken(e) ? (
                                <button
                                  className="select-token-d-btn"
                                  onClick={() => tokenSelection(e, i)}
                                >
                                  <h6 className="predefined-coins-sec-name text-capitalize">
                                    {e.coinName}
                                  </h6>{" "}
                                </button>
                              ) : null}
                              <div>
                                {findAlreadyPresentToken(e) ? (
                                  <button className="select-token-d-btn">
                                    <h6 className="predefined-coins-sec-name text-capitalize mb-0">
                                      {e.coinName}
                                    </h6>
                                    <span className="existing-box">
                                      Existing In Edit Vault
                                    </span>{" "}
                                  </button>
                                ) : null}
                              </div>

                              <div>
                                <button
                                  className="select-token-d-btn"
                                  onClick={() => tokenSelection(e, i)}
                                >
                                  <h6 className="predefined-coins-sec-percent mb-0">
                                    {e.coinSymbol}
                                  </h6>
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="select-token-details-sec-box-right">
                            <h5>${e.coinPrice}</h5>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-center">{searchQueryNotification}</p>
                )}
              </div>
            </Offcanvas.Body>
          </>
        )}
      </Offcanvas>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    fetchCoins: () => dispatch(fetchCoins),
    // initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    // fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody))
  };
};

export default connect(
  mapStateToProps,
  mapStateToDispatch
)(TokenAddComponentMobile);
