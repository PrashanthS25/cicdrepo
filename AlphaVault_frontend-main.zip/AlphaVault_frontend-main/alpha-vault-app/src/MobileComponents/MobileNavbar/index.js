/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useState,useEffect } from 'react';
import '../../App.css'
import '../../mobileApp.css';
import '../MobileNavbar/MobileNavbar.css';
import {
  NavLink,useNavigate,useLocation
} from "react-router-dom";
import { initWallet, fetchWalletResponse } from "../../redux/index";
import { connect } from "react-redux";
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { MdArrowBackIosNew } from "react-icons/md";
import Offcanvas from 'react-bootstrap/Offcanvas';
import { BiCheckCircle } from "react-icons/bi";
import { RiArrowDownSLine} from "react-icons/ri";
import { MdArrowForwardIos} from "react-icons/md";
import  home from "../../assets/images/home.svg";
import  mywallet from "../../assets/images/mywallet.svg";
import  setting from "../../assets/images/setting.svg";
import  voting from "../../assets/images/voting.svg";
import  explore from "../../assets/images/explore.svg";
import  metamask from "../../assets/images/MetaMask.svg";
import  walleticon from "../../assets/images/walleticon.png";
import  logo from "../../assets/images/icon.svg";
import walleticonnect from "../../assets/images/walletconnect.svg";
import { formatAddress } from "../../Helper/helperFunctions";
import Emitter from '../../Helper/emitter';

function MobileNavbar(props) {
  let location = useLocation()

  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [wallets, setWallets] = useState([]);
  const [switchWallet, setSwitchWallet] = useState(false);


  useEffect(()=>{
    configWallets()
  },[])

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);
  const handle_switch_close = () => setSwitchWallet(false);
  const handle_switch_show = () => setSwitchWallet(true);
  let navigate = useNavigate();

  const configWallets = (newWalletObj = null) => {
    let existingUser;
    if (newWalletObj) {
      existingUser = newWalletObj;
    } else {
      existingUser = JSON.parse(localStorage.getItem("WalletConnection"));
    }
    let _wallets = [];
    if (existingUser) {
      if (existingUser.metamask.length) {
        _wallets.push(...existingUser.metamask);
      }
      if (existingUser.walletConnect.length) {
        _wallets.push(...existingUser.walletConnect);
      }
    }
    // console.log("_wallets",_wallets)
    setWallets(_wallets);
  };

  const routeInMobile = (navigationRoute) =>{
    // // console.log("route",navigationRoute)
    handleClose1()
    navigate(navigationRoute)
  }

  const getClass = (currentRoute) =>{
    // // console.log("getLocationMobile",location.pathname,currentRoute)
    if(location.pathname === currentRoute){
      return 'mobile-view-s-nav active'     
    }
    else{
      return 'mobile-view-s-nav'
    }
    
  }

  return (

    <>
  <header className='mobile-view-top-header'>
      {[false].map((expand) => (
        <Navbar key={expand} expand={expand} className='mobile-view-navbar position-relative' >
          <Container fluid>
            <Navbar.Brand href="#"><img src={logo} alt="Logo" className='mobile-view-logo me-2' /><span className='mobile-view-logo-txt'>Alpha Vault</span></Navbar.Brand>
            <Navbar.Toggle className='mobile-view-toggle' aria-controls={`offcanvasNavbar-expand-${expand}`} onClick={handleShow1}></Navbar.Toggle>
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
              placement="start"
              backdrop="static"
              show={show1} onHide={handleClose1}
            >

              <Offcanvas.Header closeButton className='mobile-view-off-header'>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                  <img src={logo} alt="Logo" className='mobile-view-logo me-2' />
                  <span className='mobile-view-logo-txt mobile-view-logo-text-off'>Alpha Vault</span>
                </Offcanvas.Title>
              
              </Offcanvas.Header>
              <Offcanvas.Body className='mobile-view-off-body'>
              <div className='mobile-view-off-wallet-sec'>
               {
                props.isWalletConnected?
                <div className='mobile-wallet-connected'>
                 {/* <NavLink  className='mobile-view-s-nav-wc  ms-2'>Connected Wallet <MdArrowForwardIos className='ms-3 purple'/></NavLink> */}
                 <NavLink  className='mobile-view-s-nav-wc  ms-2'>Connected Wallet</NavLink>
                 <div className="mobile-wallet-connection-infor mt-2">

                 {/* <button class="btn mobile-v-nav-wc-btn-wltaddres me-2" type="button" onClick={handleShow}> */}
                 <button class="btn mobile-v-nav-wc-btn-wltaddres me-2" type="button">
                   {props.walletAddress.slice(0,5)+'...'+props.walletAddress.slice(props.walletAddress.length-5,props.walletAddress.length)} <img src={walleticon} alt=""  className="mobile-v-nav-wc-btn-wltimg ms-2" />
                 </button>

                 <Offcanvas show={show} onHide={handleClose} placement="bottom" className='mobile-v-nav-wc-offbox'>
                   <div className='mobile-v-nav-wc-top-border'></div>
                     <div class="offcanvas-header mobile-v-nav-wc-off-header">
                        <button type="button" class="btn-close" aria-label="Close" onClick={handleClose}></button>
                        <div class="offcanvas-title h5 mobile-v-nav-wc-heading">Choose Another Wallet</div>
                     </div>
                     <Offcanvas.Body className='mobile-v-nav-wc-offbody'>
                     {
            wallets.map((wallet, i) => {
              return(  
              <div className="d-flex justify-content-between align-items-center mobile-v-nav-wc-ul-dm-li-div" key={i}>
                <div className="d-flex align-items-center">
                  <img
                    src={walleticon}
                    alt=""
                    className="mobile-v-nav-wc-btn-img"
                  />
                  <div className="mobile-v-nav-wc-li-dm-text">
                    <h6 className="mobile-v-nav-wc-li-dm-1 text-capitalize mb-0">
                      <p className="dropdown-item" >
                      {formatAddress(wallet.accounts[0])}
                      </p>
                    </h6>
                    {/* <h6 className="mobile-v-nav-wc-li-dm-2 text-uppercase mb-0">
                      <p className="dropdown-item" >
                        2.124505 ETH
                      </p>
                    </h6> */}
                  </div>
                </div>
                <div className="d-flex">
                {wallet.accounts[0] === props.walletAddress ?
                  <button className="btn">
                    <BiCheckCircle className="offcheck" />
                  </button>
                 :
                 null
                }
                  
                  {/* <button className="btn">
                    <VscDebugDisconnect className="disconnect-botton"
                    onClick={() => disconnectWallet(wallet)}
                    />
                  </button> */}
                  
                </div>
              </div>
              )})
            }
                      </Offcanvas.Body>
                  </Offcanvas>

                  <button class="btn mobile-v-nav-wc-btn" type="button" >
                    <img src={metamask} alt=""  className="mobile-v-nav-wc-btn-img me-2" />
                    {/* <RiArrowDownSLine className="mobile-v-nav-wc-btn-icon"/> */}
                    {/* <span>MetaMask</span> */}
                  </button>

                  <Offcanvas
            show={switchWallet}
            onHide={handle_switch_close}
            placement="bottom"
            className="mobile-v-nav-wc-offbox"
          >
            <div className="mobile-v-nav-wc-top-border"></div>

            <Offcanvas.Header className="mobile-v-nav-wc-off-header">
              {/* <button className="off-naviagte-btn" onClick={handle_switch_close}> */}
                  <MdArrowBackIosNew className="modal-back-icon"  onClick={handle_switch_close}/>
              {/* </button> */}
              <Offcanvas.Title className="mobile-v-nav-wc-heading">
                Choose Another Wallet
              </Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body className="mobile-v-nav-wc-offbody">
              <div>
                <div
                  // className="dropdown-menu wallets-dropdown alpha-menu-drpdwn"
                  aria-labelledby="navbarDropdownMenuLink"
                  style={{
                    display: "flex",
                    flexDirection: "column",  
                    alignItems: "start",
                    justifyContent: "center",
                    marginTop: 20,
                  }}
                >
                  <div>
                    <button
                      className="dropdown-item"
                      onClick={() => Emitter.emit('metamask')}
                    >
                      <img
                        src={metamask}
                        alt=""
                        className=""
                      
                      />
                      <span>  MetaMask</span>
                    </button>
                  </div>
                  <div>
                    <button
                      className="dropdown-item "
                      onClick={() => Emitter.emit('walletConnect')}
                    >
                      <img
                        className=""
                        src={walleticonnect}
                        alt=""
                        style={{ width: 30, marginTop: 10 }}
                      />
                      <span>  WalletConnect</span>
                    </button>
                  </div>
                </div>
              </div>
            </Offcanvas.Body>
          </Offcanvas>

                  {/* <button class="btn mobile-v-nav-wc-btn" type="button" onClick={handleShow}>
                    <img src={walleticonnect} alt=""  className="mobile-v-nav-wc-btn-img me-2" /><RiArrowDownSLine className="mobile-v-nav-wc-btn-icon"/>
                    <span>Wallet Connect</span>
                  </button> */}

                 </div>
                </div>
                :
                <div className='mobile-wallet-not-connected'>
                <p className='mobile-view-s-nav-wnc mb-2 ms-2'>Wallet not Connected</p>
                <NavLink  to="/connectWallet"> <button type="button" onClick={()=>routeInMobile("/connectWallet")} className="btn btn-light btn-sm mobile-view-off-connect-button">Connect Wallet</button></NavLink>
                </div> 
                }
         
              </div>
              <hr className='mobile-v-off-hr' />
                <Nav className="justify-content-end flex-grow-1 pe-4">
                  <button onClick={()=>routeInMobile("/")} className={getClass("/")}><img className='me-3 mobile-view-nav-icon' src={home} alt="" /> Home</button>
                  <button onClick={()=>routeInMobile("/vaults")}  className={getClass("/vaults")} ><img className='me-3 mobile-view-nav-icon' src={explore} alt="" /> Explore Vaults</button>
                  <button onClick={()=>routeInMobile("/connectWallet")}  className={getClass("/connectWallet")} ><img className='me-3 mobile-view-nav-icon' src={mywallet} alt="" /> My Wallet</button>
                  {/* <button onClick={()=>routeInMobile("/staking")}  className={getClass("/staking")} ><img className='me-3 mobile-view-nav-icon' src={stake} alt="" /> Stake Tokens</button> */}
                  
                  <div className='mobile-view-nav-bottom'>
                  <hr className='mobile-v-off-hr' />
                     <button onClick={()=>routeInMobile("/voting")} className={getClass("/voting")}><img className='me-3 mobile-view-nav-icon' src={voting} alt="" /> Voting</button>
                     <button onClick={()=>routeInMobile("/settings")} className={getClass("/settings")}><img className='me-3' src={setting} alt="" /> Settings</button>
                  </div>
                </Nav>
              </Offcanvas.Body>
            </Navbar.Offcanvas>
          </Container>
        </Navbar>
      ))}
    </header>
    </>
  )
}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(MobileNavbar);
