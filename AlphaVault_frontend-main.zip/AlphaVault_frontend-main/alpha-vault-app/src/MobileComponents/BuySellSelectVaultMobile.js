/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useEffect, useState } from 'react';
import '../App.css'
import '../Components/BuySellVaults/BuySellVaults.css'
import '../mobileApp.css';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Button from 'react-bootstrap/Button';
import { MdArrowForwardIos, MdArrowBackIosNew} from "react-icons/md";
import {NavLink} from "react-router-dom";
import API from '../utils/Api'
import { initWallet, fetchWalletResponse } from "../redux/index";
import { IoSearchOutline } from "react-icons/io5";
import { connect } from "react-redux";


function BuySellSelectVaultMobile(props){

  const [vaultList,setVaultList] = useState([])
  const [loading,setLoading] = useState(false)
  const [vaultListData,setVaultListData] = useState([])
  const [show, setShow] = useState(false);
  const [selectVault,setSelectVault] = useState(null)
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  
  useEffect(()=>{
    if(props.selectionMode==='buy'){
      setLoading(true)
      if(props.chainInfo){
        getVaultList(props.chainInfo)
      }
    }
    else{
      // // console.log("HereForSale",props.serverResponse)
      setVaultList(props.serverResponse?.vaults)      
    }
    
  },[props.serverResponse])

  const getVaultList = async(chainInfo) =>{
    try{
      let reqObj = {
        "count":20,
        "type":"buy/sell",
        "search_query":null
    }
    let vaultList = await API.post('/vault/list?coinChainID='+chainInfo.networkId,reqObj)
    // // console.log("vaultList",vaultList)
    setVaultList(vaultList.data)
    setVaultListData(vaultList.data)
    setLoading(false)
    }
    catch(error){
    setLoading(false)  
    // // console.log("error",error)
    }
    }

    const  handleSelection = (requiredVault) =>{
      handleClose()
      // // console.log("requiredVault",requiredVault)
      setSelectVault(requiredVault)
      if(props.selectionMode === 'buy'){
      props.setRequiredVaultToBuy(requiredVault)
      }
      else{
        props.setRequiredVaultToSell(requiredVault)
      }
    }

    const searchVault = async(searchString,mode) =>{
      if(mode === 'buy'){
      // // console.log("searchString",searchString)
  
      if(searchString.length == 0){
        setVaultList(vaultListData);
        return;
      }
      
  
      // setLoading1(true)
      let reqObj ={
          "count":5,
          "type":"buy/sell",
          "search_query":searchString
      }  
      await API.post('/vault/list',reqObj)
      let searchVaultList = await API.post('/vault/list',reqObj)
      // // console.log("vaultList",searchVaultList)
      setVaultList(searchVaultList.data)
      // setLoading1(false)
      }  
      else{
        // // console.log("searchString",searchString)
  
      let resultarray = [];
  
      if(searchString.length == 0){
        setVaultList(props.serverResponse.vaults);
        return;
      }
      
  
      for(let i=0; i<props.serverResponse.vaults.length; i++){
        if(props.serverResponse.vaults[i].coinName.toLowerCase().startsWith(searchString.toLowerCase())){
          resultarray.push(props.serverResponse.vaults[i])
        }
      }
      // // console.log("resultarray",resultarray)
      setVaultList(resultarray);
      }
    }
  
    return(
       <>
       {
        // console.log("debugCheck",props,!props.requiredVaultToBuy ,!props.requiredVaultToSell)
       }
        {
        !selectVault && !props.requiredVaultToBuy && !props.requiredVaultToSell ?   
        <Button variant="outline-secondary buy-button mobile-stake-token-btn" id="button-addon2" onClick={handleShow}>
          Select a Vault <MdArrowForwardIos className='ms-1'/>
        </Button>
        :
        <Button variant="outline-secondary buy-button mobile-stake-token-btn" id="button-addon2" onClick={handleShow}>
          {
           selectVault? 
          <img
                              src={selectVault?.vaultDetails?selectVault.vaultDetails.coinLogoUrl:selectVault.coinLogo}
                              alt=""
                              className="me-1 exploreVaultTableCoinImage"
               />
           :
           props.selectionMode === 'buy'?
           <img
                              src={props.requiredVaultToBuy?.vaultDetails?.coinLogoUrl? props.requiredVaultToBuy?.vaultDetails?.coinLogoUrl:props.requiredVaultToBuy?.vaultDetails?.coinLogo}
                              alt=""
                              className="me-1 exploreVaultTableCoinImage"
               />    
            :
            <img
                              src={props.requiredVaultToSell?.coinLogo ? props.requiredVaultToSell?.coinLogo :props.requiredVaultToSell?.coinLogoUrl}
                              alt=""
                              className="me-1 exploreVaultTableCoinImage"
               />   
          }     
          <MdArrowForwardIos className='ms-1'/>     
        </Button>
        }

        <Offcanvas show={show} onHide={handleClose} placement="bottom" className='mobile-v-nav-wc-offbox s-token-offbox'>
           <div className='mobile-v-nav-wc-top-border'></div>

           <Offcanvas.Header className='mobile-v-nav-wc-off-header vault-header-off'>
             <MdArrowBackIosNew className='modal-back-icon' onClick={handleClose}/>
             <Offcanvas.Title className='mobile-v-nav-wc-heading'>Select a vault</Offcanvas.Title>
                <div className='seacrhcoin-box'>
                   <form className="select-token-search-box">
                        <IoSearchOutline className="select-token-search-alpha" />
                        <input className="form-control select-token-seach-plchldr" type="search" placeholder="Search by name" aria-label="Search" onChange={(e)=>searchVault(e.target.value,props.selectionMode)}/>
                  </form>
                  
                </div>
           </Offcanvas.Header>
          {/* {
            // // console.log("vaultList",vaultList)
          } */}
           <Offcanvas.Body className='mobile-v-nav-wc-offbody'>
                <div className='select-vault-details s-t-padding'>
                  {
                    vaultList?.length?
                    vaultList.map((vault,index)=>{
                      return(
                      <div key={index} className="d-flex justify-content-between mb-4" onClick={()=>handleSelection(vault)}>
                       <div className="d-flex align-items-center select-vault">
                         <img src={vault.coinLogo ?vault.coinLogo:vault.vaultDetails?.coinLogoUrl} alt="" className="me-3 v-imge" />
                         <div className="select-vault-c">
                           <h5 className="text-capitalize">{vault.coinName?vault.coinName:vault.vaultDetails?.coinName}</h5>
                           <h6 className="grey mb-0">({vault.coinSymbol?vault.coinSymbol:vault.vaultDetails?.coinSymbol})</h6>
                         </div>
                       </div>
                       <div className="select-vault-right">
                         <h5>${vault.coinPrice?vault.coinPrice.toFixed(2):vault.vaultDetails?.coinPrice.toFixed(2)}</h5>
                         {/* <h6 className="grey mb-0">$1,300.78</h6> */}
                       </div>
                     </div>
                      )
                    })
                     :
                     <p className='text-center'>No Data Available</p>
                  }   
                  </div>
           </Offcanvas.Body>
         </Offcanvas>
       </>
    )

}

const mapStateToProps = (state) => {
  return {
    walletAddress: state.wallet.walletAddress,
    chain: state.wallet.chain,
    isWalletConnected: state.wallet.isWalletConnected,
    isPolicyAccepted: state.wallet.isPolicyAccepted,
    assets: state.wallet.assets,
    loader: state.wallet.loader,
    serverResponse: state.wallet.serverResponse,
    error: state.wallet.error,
    coinList: state.coins.coinList,
    coinLoader: state.coins.coinLoader,
    coinError: state.coins.coinError,
    web3InStance: state.wallet.web3InStance,
  };
};

const mapStateToDispatch = (dispatch) => {
  return {
    initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
    fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
  };
};

export default connect(mapStateToProps, mapStateToDispatch)(BuySellSelectVaultMobile);
