/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React, { useState,useEffect } from 'react';
import '../App.css'
import '../Components/BuySellVaults/BuySellVaults.css'
import '../mobileApp.css';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Button from 'react-bootstrap/Button';
import API from '../utils/Api'
import { MdArrowForwardIos, MdArrowBackIosNew} from "react-icons/md";
import {NavLink} from "react-router-dom";
import { connect } from "react-redux";
import { initWallet, fetchWalletResponse } from "../redux/index";
import { IoSearchOutline } from "react-icons/io5";


function BuySellSelectTokenMobile(props){

  const [show, setShow] = useState(false);
  const [assetList,setAssetList] = useState([])
  const [coinAssetListData,setCoinAssetListData] = useState([])
  const [selectCoin,setSelectCoin] = useState(null);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  
  useEffect(()=>{
   setSelectCoin(props.requiredCoinToSell)
  //  // // console.log("Check1",props.serverResponse.assetList)
  if(props.selectionMode==='buy'){
    if(props.serverResponse){
      setAssetList(props.serverResponse.assetList)
      setCoinAssetListData(props.serverResponse.assetList)
       }
  }
  else{
    // // // console.log("HereForSale",props.serverResponse)
    getCoinList()    
  }
    
  },[props.requiredCoinToSell,props.serverResponse?.assetList])

  const getCoinList = async () => {
    try {
      let coinList = await API.get('/coin/list?coinChainID='+ props.networkId+'&count=70&page=1');
      // // console.log("coinList", coinList);
      setAssetList(coinList.data.data);
      setCoinAssetListData(coinList.data.data);
    } catch (error) {
      // setLoading(false);
      // setError(error.message)
      // // console.log("error", error);
    }
  };

  const handleSelection = (requiredToken) =>{
    // console.log("check543")
   handleClose()
   // console.log('handleSelection',requiredToken)
   setSelectCoin(requiredToken)
   if(props.selectionMode === 'buy'){
   props.setRequiredCoinToSell(requiredToken)
   }
   else{
   props.setRequiredCoinToBuy(requiredToken)
   }
  }

  const searchToken = async (searchString, mode) => {
    if (mode === "buy") {
      // // // console.log("searchString", searchString);

      let resultarray = [];

      if (searchString.length == 0) {
        setAssetList(props.serverResponse.assetList);
        return;
      }

      for (let i = 0; i < props.serverResponse.assetList.length; i++) {
        if (
          props.serverResponse.assetList[i].coinName
            .toLowerCase()
            .startsWith(searchString.toLowerCase())
        ) {
          resultarray.push(props.serverResponse.assetList[i]);
        }
      }
      // // console.log("resultarray", resultarray);
      setAssetList(resultarray);
    } else {
      // // console.log("searchString", searchString);

      if (searchString.length == 0) {
        setAssetList(coinAssetListData);
        return;
      }

      // setLoading1(true);
      let searchCoinList = await API.post(
        "/coin/string_filter?coinChainID=" + props.chain.networkId,
        { filter_string: searchString }
      );
      // // console.log("searchCoinList", searchCoinList);
      setAssetList(searchCoinList.data.data);
      // setLoading1(false);
    }
  };

    return(
       <>
       {
        // console.log("debugCheck",!selectCoin,!props.requiredCoinToSell)
       }
       {
       !selectCoin && !props.requiredCoinToSell ?
        <Button variant="outline-secondary buy-button mobile-stake-token-btn" id="button-addon2" onClick={handleShow}>
            Select Token <MdArrowForwardIos className='ms-1'/>                 
        </Button>
        :
        <Button variant="outline-secondary buy-button mobile-stake-token-btn" id="button-addon2" onClick={handleShow}>

          {
           selectCoin? 
          <img
                              src={selectCoin.coinLogo? selectCoin.coinLogo:selectCoin.coinLogoUrl}
                              alt=""
                              className="me-1 exploreVaultTableCoinImage"
               />
           :
           props.selectionMode === 'buy'?
           <img
                              src={props.requiredCoinToSell.coinLogo?props.requiredCoinToSell.coinLogo:props.requiredCoinToSell.coinLogoUrl}
                              alt=""
                              className="me-1 exploreVaultTableCoinImage"
               />
           :
           <img
                              src={props.requiredCoinToBuy.coinLogo?props.requiredCoinToBuy.coinLogo:props.requiredCoinToBuy.coinLogoUrl}
                              alt=""
                              className="me-1 exploreVaultTableCoinImage"
               />
            

          }     
        
        </Button>
        }
        <Offcanvas show={show} onHide={handleClose} placement="bottom" className='mobile-v-nav-wc-offbox s-token-offbox'>
           <div className='mobile-v-nav-wc-top-border'></div>

           <Offcanvas.Header className='mobile-v-nav-wc-off-header'>
             <MdArrowBackIosNew className='modal-back-icon' onClick={handleClose}/>
            
             <Offcanvas.Title className='mobile-v-nav-wc-heading'>Select A Token</Offcanvas.Title>
                <div className='seacrhcoin-box'>
                   <form className="select-token-search-box">
                        <IoSearchOutline className="select-token-search-alpha" />
                        <input className="form-control select-token-seach-plchldr" type="search" placeholder="Search by name" aria-label="Search" onChange={(e) => searchToken(e.target.value, props.selectionMode)} />
                  </form>
                   {/* <p className=' mb-0 seacrhcoin-box-p'>You can only Buy using ETH, USDT & USDC</p> */}
                </div>
           </Offcanvas.Header>

           <Offcanvas.Body className='mobile-v-nav-wc-offbody'>
            
           <div className='select-token-details s-t-padding'>
            
           {
               props.isWalletConnected&& props.serverResponse?.assetList.length?
               assetList.map((asset,index)=>{
                  return(
                  <div className="select-token-details-box mb-3" key={index} onClick={()=>handleSelection(asset)}>
                     <div className="select-token-details-box-left">
                       <button className='selct-token-btn'><img src={asset.coinLogoUrl?asset.coinLogoUrl:asset.coinLogo} alt="" className="me-3 s-token-image" /></button>
                        <div className="select-token-text">
                        <button className='selct-token-btn'> <h6 className="text-capitalize">{asset.coinName}</h6></button>
                         <h6 className="mb-0 grey text-uppercase">{asset.coinSymbol}</h6>
                        </div>
                     </div>
                     <div className="select-token-details-box-right">
                      <h5>${asset.coinPrice.toLocaleString()}</h5>
                      {
                       asset.coinValue? 
                      <h6 className='mb-0 grey'>${asset.coinValue.toLocaleString()}</h6>
                      :
                      <h6 className='mb-0 grey'>${(asset.coinPrice, 2)}</h6>
                      }
                     </div>
                   </div>
                  )
               })
               :
               null
            }
               </div>
           </Offcanvas.Body>
         </Offcanvas>
       </>
    )

}

const mapStateToProps = (state) => {
   return {
     walletAddress: state.wallet.walletAddress,
     chain: state.wallet.chain,
     isWalletConnected: state.wallet.isWalletConnected,
     isPolicyAccepted: state.wallet.isPolicyAccepted,
     assets: state.wallet.assets,
     loader: state.wallet.loader,
     serverResponse: state.wallet.serverResponse,
     error: state.wallet.error,
     coinList: state.coins.coinList,
     coinLoader: state.coins.coinLoader,
     coinError: state.coins.coinError,
     web3InStance: state.wallet.web3InStance,
   };
 };
 
 const mapStateToDispatch = (dispatch) => {
   return {
     initWallet: (walletInfo) => dispatch(initWallet(walletInfo)),
     fetchWalletResponse: (reqBody) => dispatch(fetchWalletResponse(reqBody)),
   };
 };
 
 export default connect(mapStateToProps, mapStateToDispatch)(BuySellSelectTokenMobile);
 