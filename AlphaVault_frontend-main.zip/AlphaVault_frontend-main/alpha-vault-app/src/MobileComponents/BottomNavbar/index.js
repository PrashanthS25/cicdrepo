/*
 *   Copyright (c) 2023 
 *   All rights reserved.
 */
import React,{useState,useEffect} from 'react';
import '../../App.css'
import '../BottomNavbar/BottomNavbar.css';
import '../../mobileApp.css';
import BottomNavigation from '@mui/material/BottomNavigation';
import BottomNavigationAction from '@mui/material/BottomNavigationAction';
import { AiFillHome } from "react-icons/ai";
import { FiActivity } from "react-icons/fi";
import { BsGraphUp } from "react-icons/bs";
import { IoWallet } from "react-icons/io5";
import Paper from '@mui/material/Paper';
import { useNavigate } from 'react-router-dom';


export default function BottomNavbar(props) {
  const [value, setValue] = useState(0);
  let navigate = useNavigate();

  useEffect(()=>{
    switch(props.routePath){
      case '/':
        setValue(0)
        break;
      case '/vaults':
        setValue(1)
        break;    
      case '/connectWallet':
        setValue(2)
        break;
      default:
        setValue(0)      
    }
  },[props.routePath])

  const handleChange = (event, newValue) => {
    // // console.log("tim",newValue)
    setValue(newValue);
    switch(newValue){
        case 0:
            navigate('/')
            break;
        case 1:
          navigate("/vaults")
          break;
        case 2:
          navigate("/connectWallet")
          break
        case 3:
          navigate("/staking")
          break;
        default:
          navigate('/')
            break;
    }
  }

  return (
    <div className='bottom-navbar'>
      <Paper className='bottom-navbar-paper' sx={{ position: 'fixed', bottom: 0, left: 0, right: 0 }} elevation={4}>
        <BottomNavigation
          showLabels
          value={value}
          onChange={handleChange}
        >
          {/* {
            // console.log("valueCheck",value)
          } */}
          <BottomNavigationAction label="Home" icon={<AiFillHome />} className='bottom-navbar-tab'/>  
          <BottomNavigationAction label="Vaults" icon={<BsGraphUp />} className='bottom-navbar-tab'/> 
          <BottomNavigationAction label="My Wallet" icon={<IoWallet />} className='bottom-navbar-tab'/> 
          {/* <BottomNavigationAction label="Stake"  icon={<FiActivity />} className='bottom-navbar-tab'/> */}
        </BottomNavigation>
        
      </Paper>
    </div>
  );
}
