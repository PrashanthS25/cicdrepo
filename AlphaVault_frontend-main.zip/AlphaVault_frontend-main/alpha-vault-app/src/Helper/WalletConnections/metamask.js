import {ethers} from 'ethers'; 

export const connectMetamaskWallet = async(windowObj) => {
    if (windowObj) {
        let res = await windowObj.request({method:"eth_requestAccounts"})
        // console.log(res)
       return await accountsChange(res[0],windowObj);        
    }
    else {
      return new Error("Install Metamask.")
    }
  }

export const accountsChange =async (newAccount,windowObj)=>{
      let balance = await windowObj.request({
        method: "eth_getBalance",
        params: [newAccount.toString(),"latest"]
      }) 
    return {address:newAccount,balance:ethers.utils.formatEther(balance)}
}