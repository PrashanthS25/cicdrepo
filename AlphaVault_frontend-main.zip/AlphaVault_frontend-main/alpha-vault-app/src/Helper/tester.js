    import {formatValue,sendCoinQuanity} from './helperFunctions'
import BigNumber from "bignumber.js";
import {generateMultiSwap} from './txHelper'

let testInput = [[{value:42.13,index:0,isPercMode:true},{value:27.41,index:1,isPercMode:true},{value:19.73,index:2,isPercMode:true},{value:10.70,index:3,isPercMode:true}]]
// [{value:22.88,index:1,isPercMode:true},{value:24.38,index:2,isPercMode:true}], [{value:0,index:1,isPercMode:true},{value:52.72,index:2,isPercMode:true}] ,[{value:0,index:1,isPercMode:true},{value:25.34,index:2,isPercMode:true},{value:33.52,index:3,isPercMode:true}]
// [{value:100,index:0,isPercMode:true},{value:0,index:1,isPercMode:true},{value:0,index:2,isPercMode:true},{value:0,index:3,isPercMode:true}]
// [{value:37.98,index:0,isPercMode:true},{value:26.81,index:1,isPercMode:true},{value:22.45,index:2,isPercMode:true},{value:12.74,index:3,isPercMode:true}]
// [{value:37.99,index:0,isPercMode:true},{value:24.83,index:1,isPercMode:true},{value:22.43,index:2,isPercMode:true},{value:14.73,index:3,isPercMode:true}]
let tokenList,tempTokenList,originalTOkenList,originalTempTokenList, adjtotalSum,totalBal,originalTotalBal,walletAddress,web3InStance
export const startTesting = (_tokenList,_tempTokenList,_totalBal,_walletAddress,_web3InStance)=>{
    tokenList = [..._tokenList]
    tempTokenList = [..._tempTokenList]
    totalBal =_totalBal
    walletAddress = _walletAddress
    web3InStance =  _web3InStance
    originalTOkenList = [..._tokenList]
    originalTotalBal = _totalBal 
    originalTempTokenList = [..._tempTokenList]
    let checkpercData =[]

    testInput.map(async(data)=>{
        await new Promise(resolve => setTimeout(resolve, 5000))
        console.log("dataCheck",data)   
        data.map(async(realData)=>{
            onChangePercentage(realData.value,realData.index,realData.isPercMode)
            // await new Promise(resolve => setTimeout(resolve, 100))
        })
        console.log("testCheck1",tempTokenList)
        checkpercData.push( {totalAmount:totalBal,tokenList,tempTokenList})
        calculateQuantityFromPercentage({totalAmount:totalBal,tokenList,tempTokenList})
        tokenList = [...originalTOkenList]
        tempTokenList = [...originalTempTokenList]
        totalBal =originalTotalBal
        
      })
      

}

const onChangePercentage = (value,index,percentageMode) =>{
    try{
    console.log("value",value,index,percentageMode)
    if(percentageMode){
      if(value==='%'){
        value=0   
     }
      if(value[value.length-1]==='%'){
        value = parseFloat(value.slice(0,-1))
      }
      if(value===''|| value===null){
         value=0   
      }
      if(isNaN(value)){
        throw new Error('Please enter valid number.')
        // setError('Please enter valid value.')
      }       
    }
    else{
      if(value[0]==='~'){
        value = (value.slice(1,value.length))
      }
      if(value[0]==='$'){
        value = (value.slice(1,value.length))
      }
      if(value===''|| value===null){
        value=0   
     }
     if(isNaN(+value)){
      // setError('Please enter valid value.')
      throw new Error('Please enter valid number.')
    }
      value =  parseFloat(value)
    }
  
     let tempVar = [...tempTokenList] 
     console.log("tempVar",tempVar)
     if(percentageMode){
      console.log("test98",tempVar[index])
      let tempOldCoinPerc1 =  +formatValue(tempVar[index].exactCoinPerc,2)
      let tempOldCoinPerc2 = parseFloat(Math.floor(tempVar[index].exactCoinPerc))
      let decimalCheck1 = (new BigNumber(tempOldCoinPerc1).minus(new BigNumber(tempOldCoinPerc2))).toNumber() 
      console.log("checkSum1",tempOldCoinPerc1,tempOldCoinPerc2,decimalCheck1)
      let tempNewCoinPerc1 =  +formatValue(value,2)
      let tempNewCoinPerc2 = +Math.floor(value)  
      let decimalCheck2 = (new BigNumber(tempNewCoinPerc1).minus(new BigNumber(tempNewCoinPerc2))).toNumber() 
      console.log("checkSum2",tempNewCoinPerc1,tempNewCoinPerc2,decimalCheck2)
      console.log("decimalChecks",decimalCheck2,decimalCheck1,tempOldCoinPerc1,tempOldCoinPerc2,tempNewCoinPerc1,tempNewCoinPerc2)
      let checkDiff = (new BigNumber(decimalCheck2).minus(new BigNumber(decimalCheck1))).toNumber()
      if(!checkDiff){
        console.log("here7878",decimalCheck2- decimalCheck1)
        let tempOldCoinPerc12 =  Math.floor(+tempVar[index].exactCoinPerc)
        let requiredDecimals =  new BigNumber(tempVar[index].exactCoinPerc).minus(new BigNumber(tempOldCoinPerc12)).toNumber()
        console.log("here7878",tempVar[index].exactCoinPerc, tempOldCoinPerc12)
        console.log("tim9090",requiredDecimals,tempNewCoinPerc2)
        value = new BigNumber(tempNewCoinPerc2).plus(new BigNumber(requiredDecimals)).toNumber()  
      } 
      console.log("changedValue",value)
    //  if( parseFloat(tempVar[index].exactCoinPerc) >= +value){
      tempVar[index].coinValue = ((new BigNumber(value).multipliedBy(new BigNumber(totalBal)).dividedBy(new BigNumber(100)))).toNumber()
    //  }    
    //  else{
    //   tempVar[index].coinValue = ((value * parseFloat(totalBal)/100))
    //  }
     tempVar[index].coinPerc = value
    //  setChangedToken(value)
     console.log("tempVar",tempVar,value,index,((((value / parseFloat(totalBal)) *100))) )
    }
    else{
      // if( parseFloat(tempVar[index].coinValue) >= value){
        tempVar[index].coinPerc = ((((new BigNumber(value).dividedBy(new BigNumber(totalBal)))).multipliedBy( new BigNumber(100)))).toNumber()
      //  }    
      //  else{
      //   tempVar[index].coinPerc = ((value / parseFloat(totalBal)) *100)
      //  }
     tempVar[index].coinValue = value
    //  setChangedToken(value)
    console.log("tempVar",tempVar,value,index,((((value / parseFloat(totalBal)) *100))) )
    }
     sumPerc(tempVar,true)
     console.log("t321",tempVar)
     tempTokenList = [...tempVar]
    //  setTempTokenList(tempVar)
  }
  catch(error){
     console.log("error",error,error.message) 
    //  setError(error.message)
  }
  }

  const calculateQuantityFromPercentage = async(input) =>{
    try{
    console.log("calculateQuantityFromPercentage func")
       let sum =0
    input.tempTokenList.forEach((e)=>{
      sum = new BigNumber(+e.coinPerc).plus(sum)
    })
    sum = sum.toNumber()
    sum = formatValue(sum,2)
    console.log("sum68",sum)

    if(sum => 99.98){
      sum = 100.00
    }

    if(sum< 100.00 || sum> 100.00){
      // console.log("Total percentage should be 100%.")
      throw new Error("Total percentage should be 100%.") 
    }
    // setTxWaiting(true)      
    // setProgressperc(3)
    let _changedCoins = {increasedCoins:[],reducedCoins:[]}
    console.log("tempTokenList",input.tempTokenList,input.tokenList)
    let totalIncreasedPerc = 0
    let i=0
    for(let token of input.tempTokenList){
      // console.log(token.coinAddress,props.serverResponse.assetList[i].coinAddress,props.serverResponse.assetList.length , i)
      if(input.tokenList.length > i){
       if(token.coinAddress === input.tokenList[i].coinAddress){
            let {requiredCoinQuantity,changedPerc,usedPrice,feeQuantity,totalAmount} = await sendCoinQuanity(+input.tokenList[i].coinPrice,+input.tokenList[i].coinQuantity,(+input.totalAmount),token.coinPerc,+input.tokenList[i].coinPerc,input.tokenList[i].coinSymbol,input.tokenList[i].coinDecimal)
            console.log("nit7878",totalAmount)
            if(+token.coinPerc < +input.tokenList[i].coinPerc){
            _changedCoins.reducedCoins.push({coinAddress:token.coinAddress,
              coinName:input.tokenList[i].coinName,
              requiredCoinQuantity,
              changedPerc,
              usedPrice,
              coinPrice:+input.tokenList[i].coinPrice,
              coinDecimal:input.tokenList[i].coinDecimal,
              sellToken:input.tokenList[i].coinSymbol,
              buyToken:'Wei',
              sellAmount: (requiredCoinQuantity*(10**(+input.tokenList[i].coinDecimal))),feeQuantity,totalAmount})
           } 

           if(+token.coinPerc > +input.tokenList[i].coinPerc){
            console.log("check1",requiredCoinQuantity,changedPerc,usedPrice,feeQuantity,totalAmount)
            _changedCoins.increasedCoins.push({
              coinAddress:token.coinAddress,
              coinName:input.tokenList[i].coinName,
              requiredCoinQuantity,changedPerc,
              usedPrice,coinSymbol:input.tokenList[i].coinSymbol,
              buyAmount:(requiredCoinQuantity*(10**(+input.tokenList[i].coinDecimal))),
              coinDecimal:input.tokenList[i].coinDecimal,
              feeQuantity,
              totalAmount
            })
            totalIncreasedPerc += +changedPerc
           }
           console.log("check2",_changedCoins)
       }
      }
      else{
        console.log("token",input.tempTokenList[i])
        if(token.coinAddress === input.tempTokenList[i].coinAddress){

        let {requiredCoinQuantity,changedPerc,usedPrice,totalAmount} = await sendCoinQuanity(+input.tokenList[i].coinPrice,0,+input.totalAmount,formatValue(+input.tempTokenList[i].coinPerc,2),0,input.tokenList[i].coinSymbol,+input.tokenList[i].coinDecimalPlaces)
        _changedCoins.increasedCoins.push({
          coinAddress:token.coinAddress,
          coinName:input.tokenList[i].coinName,
          requiredCoinQuantity,changedPerc,
          usedPrice,coinSymbol:input.tokenList[i].coinSymbol,
          coinDecimal:input.tokenList[i].coinDecimal,
          buyToken:input.tokenList[i].coinSymbol,
          totalAmount,
          buyAmount: (requiredCoinQuantity*(10**(tokenList[i].coinDecimalPlaces)))})
          totalIncreasedPerc += +changedPerc
        }
      }
      console.log("changes",_changedCoins)
      i+=1
    }
    // if(!_changedCoins.increasedCoins.length && !_changedCoins.reducedCoins.length){
    //   throw new Error('Please make changes in your vault to proceed with transactions.')
    // }
    // setProgressperc(5)     
    console.log("_changedCoins",_changedCoins,totalIncreasedPerc)
    // setChangedCoins(_changedCoins)
    // setShowSuccessModal(true)
    // // console.log("sit99",props,props.web3InStance,web3InstanceforTx)
    await generateMultiSwap(_changedCoins,web3InStance,walletAddress.toString(),totalIncreasedPerc,true)
    }
    catch(error){
      console.log("error",error,error.message)
    //   setShowSuccessModal(false)
    //   setError(error.message)
    //   setTxWaiting(false)
    }
  }


  let sumPerc = (tempListArray,changed=false)=>{
    let sum=new BigNumber(0)
    tempListArray.forEach((item,i)=>{
      console.log("che67",item.coinAddress,item.coinPerc)
      sum = new BigNumber(+item.coinPerc).plus(sum)
    })
    sum = sum.toNumber()
    sum = +formatValue(sum,2)
    console.log("sum",sum,Math.round(sum))
    if(sum => 99.98){
      sum = 100.00
    }
    // setSum(sum)
    adjtotalSum = sum
  }